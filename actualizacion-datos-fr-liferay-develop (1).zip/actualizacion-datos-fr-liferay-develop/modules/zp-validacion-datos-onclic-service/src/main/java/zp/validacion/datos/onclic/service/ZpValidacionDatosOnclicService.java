package zp.validacion.datos.onclic.service;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.CompanyConstants;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.security.auth.session.AuthenticatedSessionManagerUtil;
import com.liferay.portal.kernel.service.GroupLocalServiceUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;

import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.PortletSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import co.com.porvenir.portal.zte.rest.client.api.ZteRestClientApi;
import co.com.porvenir.portal.zte.rest.client.api.config.RestClientApiConfiguration;
import co.com.porvenir.portal.zte.rest.client.api.constant.ZteRestClientApiConstant;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;

/**
 * @author POR12989
 */
@Component(immediate = true, property = {}, service = ZpValidacionDatosOnclicApi.class)
public class ZpValidacionDatosOnclicService implements ZpValidacionDatosOnclicApi {

	@Reference
	private DinamicDatalistApi dataListApi;

	@Reference
	private ZteRestClientApi restApi;

	private static Log log = LogFactoryUtil.getLog(ZpValidacionDatosOnclicService.class);
	private String componente = StringPool.BLANK;
	private String parametrosConsumo = StringPool.BLANK;
	private String parametrosSalida = StringPool.BLANK;
	private String numeroIdentificacion = StringPool.BLANK;
	private String sesionId = StringPool.BLANK;
	private String nitEmpresa = StringPool.BLANK;

	private static volatile RestClientApiConfiguration _restClientApiConfiguration;

	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_restClientApiConfiguration = ConfigurableUtil.createConfigurable(RestClientApiConfiguration.class, properties);
	}

	@Override
	public String capturarParametro(PortletRequest request, String nombreParametro) {
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(request));
		String parametro = (String) httpReq.getSession().getAttribute(nombreParametro);
		if (parametro == null) {
			log.error("No se encuentra " + nombreParametro + " al inicializar el servicio");
		}
		return parametro;
	}

	@Override
	public void inicializarParametro(PortletRequest request, String nombreParametro, String parametro) {
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(request));
		if (nombreParametro != StringPool.BLANK) {
			httpReq.getSession().setAttribute(nombreParametro, parametro);
		} else {
			log.error("Error al inicializar un parametro vacio");
		}
	}

	private String obtenerParametroLista(String nombreLista, String nombreParametro) {
		String parametro = dataListApi.getRecordValue(nombreLista, nombreParametro);
		if (parametro == null || parametro.equals(StringPool.BLANK)) {
			log.error("No se encuentra " + nombreParametro + " en la lista dinamica.");
		}
		return parametro;
	}

	private String obtenerIP(PortletRequest portletRequest) {
		HttpServletRequest httpReqA = PortalUtil.getHttpServletRequest(portletRequest);
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(httpReqA);
		String ip = httpReq.getHeader("X-FORWARDED-FOR");
		if (ip == null || StringPool.BLANK.equals(ip)) {
			ip = PortalUtil.getHttpServletRequest(portletRequest).getRemoteAddr();
			if (ip == null || StringPool.BLANK.equals(ip)) {
				ip = "10.0.0.1";
			}
		}
		if (ip.split(",").length > 1) {
			ip = ip.split(",")[1];
		} else {
			ip = ip.split(",")[0];
		}
		/* IP TEMPORAL AMBIENTES */
		String ipTemp = ip.split(":")[0];
		inicializarParametro(portletRequest, ZpValidacionDatosOnClicApiKeys.IP_TEMP, ipTemp);
		return ip.split(":")[0];
	}

	@Override
	public void capturarSeleccion(PortletRequest request, String seleccionResidencia) {
		boolean residencia = true;
		obtenerIP(request);

		this.parametrosConsumo = "{" + ZpValidacionDatosOnClicApiKeys.PARAMETROS_CONSUMO_RESIDENCIA + "}";

		if (seleccionResidencia.equals(ZpValidacionDatosOnClicApiKeys.PARAMETROS_COL)) {
			this.componente = ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_COLOMBIA;
		} else {
			this.componente = ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_EXTERIOR;
		}
		this.parametrosSalida = seleccionResidencia + "=" + residencia;
		try {
			guardarParametrosLog(request, StringPool.BLANK, numeroIdentificacion,
					ZpValidacionDatosOnClicApiKeys.URL_PAGINA_RESIDENCIA, componente, StringPool.BLANK,
					StringPool.BLANK, parametrosConsumo, parametrosSalida, new Date(),
					String.valueOf(ZteRestClientApiConstant.SC_OK));
		} catch (Exception e) {
			log.error("Error al registrar Log: ", e);
		}
	}

	@Override
	public void guardarParametrosLog(PortletRequest request, String tipoIdUsuario, String numeroIdentificacion,
			String urlPagina, String componente, String navegador, String servicioConsumido, String parametrosConsumo,
			String parametrosSalida, Date dateConsumoServicio, String codigo) {
		Date fechaRespuestaServicio = null;
		String urlLog = dataListApi.getRecordValue(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES_GLOBAL,
				ZteRestClientApiConstant.URL_REST_LOGS);

		this.sesionId = request.getPortletSession().getId();

		try {
			JSONObject logsParams = restApi.createJSONParamLogs(ZpValidacionDatosOnClicApiKeys.APLICACION, urlLog,
					ZpValidacionDatosOnClicApiKeys.USUARIO_ID, tipoIdUsuario, numeroIdentificacion, nitEmpresa,
					ZpValidacionDatosOnClicApiKeys.NOMBRE_PAGINA, urlPagina, componente, sesionId);

			Map<String, String> headers = new LinkedHashMap<>();
			JSONObject jsonHeader = JSONFactoryUtil.createJSONObject();

			jsonHeader.put(ZteRestClientApiConstant.IP_ADDR,
					capturarParametro(request, ZpValidacionDatosOnClicApiKeys.IP_TEMP));
			headers.put(ZteRestClientApiConstant.HEADER_RQU, jsonHeader.toJSONString());

			JSONObject jsonSalida = JSONFactoryUtil.createJSONObject();
			jsonSalida.put(ZteRestClientApiConstant.RESPUESTA, parametrosSalida);
			jsonSalida.put(ZteRestClientApiConstant.CODIGO, codigo);

			if (!Optional.ofNullable(dateConsumoServicio).isPresent()) {
				dateConsumoServicio = new Date();
			}
			fechaRespuestaServicio = new Date();

			restApi.callServiceLog(servicioConsumido, parametrosConsumo, headers, new LinkedHashMap<>(), logsParams,
					jsonSalida, dateConsumoServicio.getTime(), fechaRespuestaServicio.getTime(),
					Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

		} catch (Exception e) {
			log.error("Error registrando en logs: ", e);
		}
	}

	@Override
	public void guardarDatosLogin(PortletRequest request, String tipoDocumento, String numeroDocumento,
			String numeroFormato, String fechaExpedicion, String numeroCelular, String correoElectronico, String jwt,
			String sesion, String descripcionAuth, String datoAuth, String seleccionResidencia) {
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO, tipoDocumento);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO, numeroDocumento);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.NUMBER_FORMAT, numeroFormato);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION, fechaExpedicion);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.NUMERO_CELULAR, numeroCelular);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.CORREO_ELECTRONICO, correoElectronico);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.JWT, jwt);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.INICIO_SESION, sesion);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.NOTIFICACION_CCM,
				ZpValidacionDatosOnClicApiKeys.VALOR_NOTIF_SI);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.DESCRIPCION_AUTH, descripcionAuth);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.DATO_AUTH, datoAuth);
		inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA, seleccionResidencia);
	}

	@Override
	public void guardarDatosPortletSession(PortletRequest request, String tipoDocumento, String numeroDocumento,
			String fechaExpedicion, String numeroCelular, String correoElectronico) {
		PortletSession session = request.getPortletSession();
		session.setAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO, tipoDocumento,
				PortletSession.PORTLET_SCOPE);
		session.setAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO, numeroDocumento,
				PortletSession.PORTLET_SCOPE);
		session.setAttribute(ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION, fechaExpedicion,
				PortletSession.PORTLET_SCOPE);
		session.setAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_CELULAR, numeroCelular,
				PortletSession.PORTLET_SCOPE);
		session.setAttribute(ZpValidacionDatosOnClicApiKeys.CORREO_ELECTRONICO, correoElectronico,
				PortletSession.PORTLET_SCOPE);
	}

	@Override
	public JSONObject obtenerDocumentoTC(PortletRequest request) {
		obtenerIP(request);
		PortletSession session = request.getPortletSession();
		String urlService = obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
				ZpValidacionDatosOnClicApiKeys.URL_OBTENER_DOCUMENTO);

		StringBuilder url = new StringBuilder();
		url.append(urlService).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_TC).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.CANAL_SERVICIO_TC).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.UNDEFINED).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.CODIGO_REFERENCIA_SERVICIO_TC).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.FUNCIONALIDAD_SERVICIO_TC);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();
		JSONObject callResponse = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosConsumo = JSONFactoryUtil.createJSONObject();

		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject headerLogTx = JSONFactoryUtil.createJSONObject();

		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_TC);
		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.PRODUCTO_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.CANAL_SERVICIO_TC);
		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.NOMBRE_REFERENCIA_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.UNDEFINED);
		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.CODIGO_REFERENCIA_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.CODIGO_REFERENCIA_SERVICIO_TC);
		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.FUNCIONALIDAD_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.FUNCIONALIDAD_SERVICIO_TC);

		try {
			headerLogTx = generarParametrosLogTransaccional(request, StringPool.BLANK, StringPool.BLANK,
					ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_RENDER_INICIAR_FORMULARIO, new Date());

			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(request).toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.HEADER_LOG_TX, headerLogTx.toJSONString());

			callResponse = restApi.callRestServiceByGet(url.toString(), headers, new LinkedHashMap<>(),
					parametrosConsumo, Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			if (!callResponse.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO))) {
				guardarParametrosLog(request, StringPool.BLANK, StringPool.BLANK,
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_RENDER_INICIAR_FORMULARIO, StringPool.BLANK,
						url.toString(), parametrosConsumo.toJSONString(), callResponse.toJSONString(), new Date(),
						callResponse.getString(ZteRestClientApiConstant.CODIGO));

				callResponse = callResponse.getJSONObject(ZteRestClientApiConstant.RESPUESTA);
				int idDocumentoTC = callResponse.getJSONArray(ZpValidacionDatosOnClicApiKeys.LISTA_DOCUMENTOS)
						.getJSONObject(0).getInt(ZpValidacionDatosOnClicApiKeys.ID_DOCUMENTO);
				String base64 = callResponse.getJSONArray(ZpValidacionDatosOnClicApiKeys.LISTA_DOCUMENTOS)
						.getJSONObject(0).getString(ZpValidacionDatosOnClicApiKeys.BASE64);
				session.setAttribute(ZpValidacionDatosOnClicApiKeys.ID_DOCUMENTO_TC, String.valueOf(idDocumentoTC),
						PortletSession.PORTLET_SCOPE);

				inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_TC, base64);
				respuesta.put(ZpValidacionDatosOnClicApiKeys.CODE, ZpValidacionDatosOnClicApiKeys.CODE_OK);
				respuesta.put(ZpValidacionDatosOnClicApiKeys.BASE64, base64);
			} else {
				log.error("Error para obtener documento Terminos y Condiciones: " + url + StringPool.SPACE
						+ callResponse.toJSONString());
				guardarParametrosLog(request, StringPool.BLANK, StringPool.BLANK,
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_RENDER_INICIAR_FORMULARIO, StringPool.BLANK,
						url.toString(), parametrosConsumo.toJSONString(), callResponse.toJSONString(), new Date(),
						callResponse.getString(ZteRestClientApiConstant.CODIGO));
				respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error en servicio para obtener documento Terminos y Condiciones: ", e);
			guardarParametrosLog(request, StringPool.BLANK, StringPool.BLANK,
					ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_RENDER_INICIAR_FORMULARIO, StringPool.BLANK,
					url.toString(), parametrosConsumo.toJSONString(), callResponse.toJSONString(), new Date(),
					callResponse.getString(ZteRestClientApiConstant.CODIGO));
			respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
		}
		return respuesta;
	}

	@Override
	public JSONObject obtenerDocumentoHD(PortletRequest request) {
		obtenerIP(request);
		PortletSession session = request.getPortletSession();
		String urlService = obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
				ZpValidacionDatosOnClicApiKeys.URL_OBTENER_DOCUMENTO);

		StringBuilder url = new StringBuilder();
		url.append(urlService).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_HD).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.CANAL_SERVICIO_HD).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.UNDEFINED).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.CODIGO_REFERENCIA_SERVICIO_HD).append(StringPool.FORWARD_SLASH)
				.append(ZpValidacionDatosOnClicApiKeys.FUNCIONALIDAD_SERVICIO_HD);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();
		JSONObject callResponse = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosConsumo = JSONFactoryUtil.createJSONObject();
		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject headerLogTx = JSONFactoryUtil.createJSONObject();

		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_HD);
		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.PRODUCTO_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.CANAL_SERVICIO_HD);
		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.NOMBRE_REFERENCIA_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.UNDEFINED);
		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.CODIGO_REFERENCIA_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.CODIGO_REFERENCIA_SERVICIO_HD);
		parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.FUNCIONALIDAD_PARAMETRO,
				ZpValidacionDatosOnClicApiKeys.FUNCIONALIDAD_SERVICIO_HD);

		try {
			headerLogTx = generarParametrosLogTransaccional(request, StringPool.BLANK, StringPool.BLANK,
					ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_RENDER_INICIAR_FORMULARIO, new Date());

			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(request).toJSONString());
			headers.put(ZteRestClientApiConstant.HEADER_LOG, headerLogTx.toJSONString());

			callResponse = restApi.callRestServiceByGet(url.toString(), headers, new LinkedHashMap<>(),
					parametrosConsumo, Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			if (!callResponse.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO))) {

				guardarParametrosLog(request, StringPool.BLANK, StringPool.BLANK,
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_RENDER_INICIAR_FORMULARIO, StringPool.BLANK,
						url.toString(), parametrosConsumo.toJSONString(), callResponse.toJSONString(), new Date(),
						callResponse.getString(ZteRestClientApiConstant.CODIGO));

				callResponse = callResponse.getJSONObject(ZteRestClientApiConstant.RESPUESTA);
				int idDocumentoHD = callResponse.getJSONArray(ZpValidacionDatosOnClicApiKeys.LISTA_DOCUMENTOS)
						.getJSONObject(0).getInt(ZpValidacionDatosOnClicApiKeys.ID_DOCUMENTO);
				String base64 = callResponse.getJSONArray(ZpValidacionDatosOnClicApiKeys.LISTA_DOCUMENTOS)
						.getJSONObject(0).getString(ZpValidacionDatosOnClicApiKeys.BASE64);
				session.setAttribute(ZpValidacionDatosOnClicApiKeys.ID_DOCUMENTO_HD, String.valueOf(idDocumentoHD),
						PortletSession.PORTLET_SCOPE);

				inicializarParametro(request, ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_HD, base64);
				respuesta.put(ZpValidacionDatosOnClicApiKeys.CODE, ZpValidacionDatosOnClicApiKeys.CODE_OK);
				respuesta.put(ZpValidacionDatosOnClicApiKeys.BASE64, base64);
			} else {
				log.error("Error en servicio para obtener documento: " + url + StringPool.SPACE
						+ callResponse.toJSONString());
				guardarParametrosLog(request, StringPool.BLANK, StringPool.BLANK,
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_RENDER_INICIAR_FORMULARIO, StringPool.BLANK,
						url.toString(), parametrosConsumo.toJSONString(), callResponse.toJSONString(), new Date(),
						callResponse.getString(ZteRestClientApiConstant.CODIGO));
				respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error para obtener documento Habeas Data: ", e);
			guardarParametrosLog(request, StringPool.BLANK, StringPool.BLANK,
					ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_RENDER_INICIAR_FORMULARIO, StringPool.BLANK,
					url.toString(), parametrosConsumo.toJSONString(), callResponse.toJSONString(), new Date(),
					callResponse.getString(ZteRestClientApiConstant.CODIGO));
			respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
		}
		return respuesta;
	}

	@Override
	public JSONObject validarContrase�aZTA(PortletRequest request, PortletResponse response, String pswd) {
		PortletSession session = request.getPortletSession();
		String url = obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
				ZpValidacionDatosOnClicApiKeys.URL_ACTUALIZACION_DATOS_INICIAR_SESION_ZTA);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosConsumo = JSONFactoryUtil.createJSONObject();
		JSONObject responseService = JSONFactoryUtil.createJSONObject();
		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject headerLogTx = JSONFactoryUtil.createJSONObject();

		try {
			headerLogTx = generarParametrosLogTransaccional(request,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_ACTUALIZA_TUS_DATOS_CREDENCIALES_ZTA,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INGRESAR, new Date());

			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(request).toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.HEADER_LOG_TX, headerLogTx.toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.CONTENT_TYPE, ZpValidacionDatosOnClicApiKeys.APPLICATION_JSON);
			JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.TIPO_IDENTIFICACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.IDENTIFICACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.PSWD, pswd);
			parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.TIPO_IDENTIFICACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO));
			parametrosConsumo.put(ZpValidacionDatosOnClicApiKeys.IDENTIFICACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO));

			responseService = restApi.callRestServiceByPost(url, parametrosPeticion.toJSONString(), headers,
					new LinkedHashMap<>(), Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			if (!responseService.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO))) {
				guardarParametrosLog(request,
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_ACTUALIZA_TUS_DATOS_CREDENCIALES_ZTA,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INGRESAR, StringPool.BLANK, url,
						parametrosConsumo.toJSONString(), responseService.toJSONString(), new Date(),
						responseService.getString(ZteRestClientApiConstant.CODIGO));

				responseService = responseService.getJSONObject(ZteRestClientApiConstant.RESPUESTA);
				respuesta.put(ZpValidacionDatosOnClicApiKeys.CODE,
						responseService.get(ZteRestClientApiConstant.CODIGO));
				respuesta.put(ZpValidacionDatosOnClicApiKeys.DESCRIPCION,
						responseService.get(ZpValidacionDatosOnClicApiKeys.DESCRIPCION));
				if (responseService.get(ZteRestClientApiConstant.CODIGO).equals(ZpValidacionDatosOnClicApiKeys.CODE_U)
						&& responseService.get(ZpValidacionDatosOnClicApiKeys.DESCRIPCION)
								.equals(ZpValidacionDatosOnClicApiKeys.DES_AUTE_EXITOSA)) {
					String jwt = generarJWT(request);
					if (jwt.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO))) {
						respuesta.put(ZpValidacionDatosOnClicApiKeys.CODE,
								ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO);
					}
				}
			} else {
				log.error("Error en servicio iniciar sesion ZTA " + url + StringPool.SPACE
						+ responseService.toJSONString());
				guardarParametrosLog(request,
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_ACTUALIZA_TUS_DATOS_CREDENCIALES_ZTA,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INGRESAR, StringPool.BLANK, url,
						parametrosConsumo.toJSONString(), responseService.toJSONString(), new Date(),
						responseService.getString(ZteRestClientApiConstant.CODIGO));
				respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error en servicio iniciar sesion zta: ", e);
			guardarParametrosLog(request,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_ACTUALIZA_TUS_DATOS_CREDENCIALES_ZTA,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INGRESAR, StringPool.BLANK, url,
					parametrosConsumo.toJSONString(), responseService.toJSONString(), new Date(),
					responseService.getString(ZteRestClientApiConstant.CODIGO));
			respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
		}
		return respuesta;
	}

	@Override
	public JSONObject validacionAcceso(PortletRequest request, boolean validacionZTA) {
		boolean seleccionExterior = true;
		PortletSession session = request.getPortletSession();
		if (session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA).toString()
				.equals(ZpValidacionDatosOnClicApiKeys.RESIDE_COL)) {
			seleccionExterior = false;
		}

		String url = obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
				ZpValidacionDatosOnClicApiKeys.URL_VALIDACION_ACCESO_SERVICIO);

		String urlTC = obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
				ZpValidacionDatosOnClicApiKeys.URL_GUARDAR_TC);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();
		JSONObject response = JSONFactoryUtil.createJSONObject();
		JSONObject responseTC = JSONFactoryUtil.createJSONObject();
		JSONObject responseValidacion = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosPeticionTC = JSONFactoryUtil.createJSONObject();
		Map<String, String> headers = new LinkedHashMap<>();

		JSONArray aceptaciones = JSONFactoryUtil.createJSONArray();
		JSONArray aceptacionesTC = JSONFactoryUtil.createJSONArray();

		JSONObject logHeaderTx = generarParametrosLogTransaccional(request,
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
				ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
				ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INICIAR_SOLICITUD, new Date());

		if (ParamUtil.getString(request, ZpValidacionDatosOnClicApiKeys.PARAM_HABEAS_DATA, StringPool.BLANK)
				.equals(ZpValidacionDatosOnClicApiKeys.SI_AUTORIZO)) {
			JSONObject sensible = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.SENSIBLE,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.SENSIBLE_N);
			JSONObject porvMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_MERCADEO,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.PORVE_MERCADEO_N);
			JSONObject porvOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_OPEN_FINANCE,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.PORVE_OPEN_FINANCE_N);
			JSONObject porvPontabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_PORTABILIDAD,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.PORVE_PORTABILIDAD_N);
			JSONObject gaMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_MERCADEO,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.GA_MERCADEO_N);
			JSONObject gaOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_OPEN_FINANCE,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.GA_OPEN_FINANCE_N);
			JSONObject gaPortabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_PORTABILIDAD,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.GA_PORTABILIDAD_N);
			JSONObject gesaMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_MERCADEO,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.GESA_MERCADEO_N);
			JSONObject gesaOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_OPEN_FINANCE,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.GESA_OPEN_FINANCE_N);
			JSONObject gesaPortabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_PORTABILIDAD,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.GESA_PORTABILIDAD_N);

			JSONObject menorEdad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.MENOR_EDAD,
					ZpValidacionDatosOnClicApiKeys.SI, ZpValidacionDatosOnClicApiKeys.MENOR_EDAD_N);

			aceptaciones.put(sensible);
			aceptaciones.put(porvMercadeo);
			aceptaciones.put(porvOpenFinance);
			aceptaciones.put(porvPontabilidad);
			aceptaciones.put(gaMercadeo);
			aceptaciones.put(gaOpenFinance);
			aceptaciones.put(gaPortabilidad);
			aceptaciones.put(gesaMercadeo);
			aceptaciones.put(gesaOpenFinance);
			aceptaciones.put(gesaPortabilidad);
			aceptaciones.put(menorEdad);

		} else if (ParamUtil.getString(request, ZpValidacionDatosOnClicApiKeys.PARAM_HABEAS_DATA, StringPool.BLANK)
				.equals(ZpValidacionDatosOnClicApiKeys.NO_AUTORIZO)) {
			JSONObject sensible = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.SENSIBLE,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.SENSIBLE_N);
			JSONObject porvMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_MERCADEO,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.PORVE_MERCADEO_N);
			JSONObject porvOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_OPEN_FINANCE,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.PORVE_OPEN_FINANCE_N);
			JSONObject porvPontabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_PORTABILIDAD,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.PORVE_PORTABILIDAD_N);
			JSONObject gaMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_MERCADEO,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.GA_MERCADEO_N);
			JSONObject gaOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_OPEN_FINANCE,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.GA_OPEN_FINANCE_N);
			JSONObject gaPortabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_PORTABILIDAD,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.GA_PORTABILIDAD_N);
			JSONObject gesaMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_MERCADEO,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.GESA_MERCADEO_N);
			JSONObject gesaOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_OPEN_FINANCE,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.GESA_OPEN_FINANCE_N);
			JSONObject gesaPortabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_PORTABILIDAD,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.GESA_PORTABILIDAD_N);
			JSONObject menorEdad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.MENOR_EDAD,
					ZpValidacionDatosOnClicApiKeys.NO, ZpValidacionDatosOnClicApiKeys.MENOR_EDAD_N);

			aceptaciones.put(sensible);
			aceptaciones.put(porvMercadeo);
			aceptaciones.put(porvOpenFinance);
			aceptaciones.put(porvPontabilidad);
			aceptaciones.put(gaMercadeo);
			aceptaciones.put(gaOpenFinance);
			aceptaciones.put(gaPortabilidad);
			aceptaciones.put(gesaMercadeo);
			aceptaciones.put(gesaOpenFinance);
			aceptaciones.put(gesaPortabilidad);
			aceptaciones.put(menorEdad);
		} else {
			String uno = (ParamUtil.getString(request, ZpValidacionDatosOnClicApiKeys.UNO, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dosunouno = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_UNO_UNO, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dosunodos = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_UNO_DOS, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dosunotres = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_UNO_TRES, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dosdosuno = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_DOS_UNO, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dosdosdos = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_DOS_DOS, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dosdostres = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_DOS_TRES, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dostresuno = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_TRES_UNO, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dostresdos = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_TRES_DOS, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String dostrestres = (ParamUtil
					.getString(request, ZpValidacionDatosOnClicApiKeys.DOS_TRES_TRES, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;
			String tres = (ParamUtil.getString(request, ZpValidacionDatosOnClicApiKeys.TRES, StringPool.BLANK)
					.equals(ZpValidacionDatosOnClicApiKeys.B_TRUE)) ? ZpValidacionDatosOnClicApiKeys.SI
							: ZpValidacionDatosOnClicApiKeys.NO;

			JSONObject sensible = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.SENSIBLE, uno,
					ZpValidacionDatosOnClicApiKeys.SENSIBLE_N);
			JSONObject porvMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_MERCADEO, dosunouno,
					ZpValidacionDatosOnClicApiKeys.PORVE_MERCADEO_N);
			JSONObject porvOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_OPEN_FINANCE, dosunodos,
					ZpValidacionDatosOnClicApiKeys.PORVE_OPEN_FINANCE_N);
			JSONObject porvPontabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.PORVE_PORTABILIDAD, dosunotres,
					ZpValidacionDatosOnClicApiKeys.PORVE_PORTABILIDAD_N);
			JSONObject gaMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_MERCADEO, dosdosuno,
					ZpValidacionDatosOnClicApiKeys.GA_MERCADEO_N);
			JSONObject gaOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_OPEN_FINANCE, dosdosdos,
					ZpValidacionDatosOnClicApiKeys.GA_OPEN_FINANCE_N);
			JSONObject gaPortabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GA_PORTABILIDAD, dosdostres,
					ZpValidacionDatosOnClicApiKeys.GA_PORTABILIDAD_N);
			JSONObject gesaMercadeo = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_MERCADEO, dostresuno,
					ZpValidacionDatosOnClicApiKeys.GESA_MERCADEO_N);
			JSONObject gesaOpenFinance = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_OPEN_FINANCE, dostresdos,
					ZpValidacionDatosOnClicApiKeys.GESA_OPEN_FINANCE_N);
			JSONObject gesaPortabilidad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.GESA_PORTABILIDAD, dostrestres,
					ZpValidacionDatosOnClicApiKeys.GESA_PORTABILIDAD_N);
			JSONObject menorEdad = aceptacionesHD(ZpValidacionDatosOnClicApiKeys.MENOR_EDAD, tres,
					ZpValidacionDatosOnClicApiKeys.MENOR_EDAD_N);

			aceptaciones.put(sensible);
			aceptaciones.put(porvMercadeo);
			aceptaciones.put(porvOpenFinance);
			aceptaciones.put(porvPontabilidad);
			aceptaciones.put(gaMercadeo);
			aceptaciones.put(gaOpenFinance);
			aceptaciones.put(gaPortabilidad);
			aceptaciones.put(gesaMercadeo);
			aceptaciones.put(gesaOpenFinance);
			aceptaciones.put(gesaPortabilidad);
			aceptaciones.put(menorEdad);
		}

		JSONObject aceptacionTC = aceptaciones(request, ZpValidacionDatosOnClicApiKeys.ID_DOCUMENTO_TC,
				ZpValidacionDatosOnClicApiKeys.PARAMETROS_CONCEPTO_ACEPTACION_TC);
		aceptacionesTC.put(aceptacionTC);

		try {
			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(request).toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.HEADER_LOG_TX, logHeaderTx.toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.CONTENT_TYPE, ZpValidacionDatosOnClicApiKeys.APPLICATION_JSON);

			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.TYPE_ID,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.NO_ID,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.CORREO,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.CORREO_ELECTRONICO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.CELULAR,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_CELULAR));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.EXTERIOR, seleccionExterior);
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.INTENTOS,
					obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS,
							ZpValidacionDatosOnClicApiKeys.INTENTOS_VALIDACION));

			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.CONSENTIMIENTOS, aceptaciones);
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.VALIDACION_ZTA, validacionZTA);

			parametrosPeticionTC.put(ZpValidacionDatosOnClicApiKeys.ACEPTACIONES, aceptacionesTC);

			responseTC = restApi.callRestServiceByPost(urlTC, parametrosPeticionTC.toJSONString(), headers,
					new LinkedHashMap<>(), Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			if (responseTC.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_OK))) {
				response = restApi.callRestServiceByPost(url, parametrosPeticion.toJSONString(), headers,
						new LinkedHashMap<>(), Integer.parseInt(_restClientApiConfiguration.requestTimeout()));
				if (!response.getString(ZteRestClientApiConstant.CODIGO)
						.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO))) {
					guardarParametrosLog(request,
							session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
							session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
							ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
							ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INICIAR_SOLICITUD, StringPool.BLANK, url,
							StringPool.BLANK, response.toJSONString(), new Date(),
							response.getString(ZteRestClientApiConstant.CODIGO));
					JSONObject code = response;
					response = response.getJSONObject(ZteRestClientApiConstant.RESPUESTA);
					if (code.getString(ZpValidacionDatosOnClicApiKeys.CODE)
							.equals(ZpValidacionDatosOnClicApiKeys.CODE_OK)) {
						respuesta.put(ZpValidacionDatosOnClicApiKeys.CODE,
								response.get(ZteRestClientApiConstant.CODIGO));
						respuesta.put(ZpValidacionDatosOnClicApiKeys.DESCRIPCION,
								response.get(ZpValidacionDatosOnClicApiKeys.DESCRIPCION));
						if (response.getString(ZpValidacionDatosOnClicApiKeys.CODE).equals("6")
								|| response.getString(ZpValidacionDatosOnClicApiKeys.CODE).equals("7")
								|| response.getString(ZpValidacionDatosOnClicApiKeys.CODE).equals("10")) {
							response = response.getJSONObject(ZpValidacionDatosOnClicApiKeys.OBJETO);
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.FECHA_EXP_VALIDACION,
									response.getBoolean(ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION));
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.PRIMER_APELLIDO,
									response.getString(ZpValidacionDatosOnClicApiKeys.PRIMER_APELLIDO));
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.PRIMER_NOMBRE,
									response.getString(ZpValidacionDatosOnClicApiKeys.PRIMER_NOMBRE));
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.CORREO_VALIDACION,
									response.getString(ZpValidacionDatosOnClicApiKeys.CORREO).toLowerCase());
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.CELULAR_VALIDACION,
									response.getString(ZpValidacionDatosOnClicApiKeys.CELULAR));
						} else if (response.getString(ZpValidacionDatosOnClicApiKeys.CODE).equals("8")) {
							responseValidacion = response.getJSONObject(ZpValidacionDatosOnClicApiKeys.OBJETO);
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.FECHA_EXP_VALIDACION,
									responseValidacion.getBoolean(ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION));
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.PRIMER_APELLIDO,
									responseValidacion.getString(ZpValidacionDatosOnClicApiKeys.PRIMER_APELLIDO));
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.PRIMER_NOMBRE,
									responseValidacion.getString(ZpValidacionDatosOnClicApiKeys.PRIMER_NOMBRE));

							response = response.getJSONObject(ZpValidacionDatosOnClicApiKeys.OBJETO_OTP);
							String datoSeguro = response.getString(ZpValidacionDatosOnClicApiKeys.DATO_SEGURO);
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.TRANSACTION_ID,
									response.getString(ZpValidacionDatosOnClicApiKeys.TRANSACTION_ID));
							response = response.getJSONObject(ZpValidacionDatosOnClicApiKeys.AUTH_INFO);
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.AUTH_ID,
									response.getString(ZpValidacionDatosOnClicApiKeys.AUTH_ID));
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.AUTH_NAME,
									response.getString(ZpValidacionDatosOnClicApiKeys.AUTH_NAME));
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.CELULAR_VALIDACION, datoSeguro);
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.CORREO_VALIDACION, StringPool.BLANK);
							session.setAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_OTP,
									ZpValidacionDatosOnClicApiKeys.CELULAR_OTP);
						}
					} else if (code.getString(ZteRestClientApiConstant.CODIGO)
							.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_MAX))) {
						response = response.getJSONObject(ZpValidacionDatosOnClicApiKeys.OBJETO_OTP);
						response = response.getJSONObject(ZpValidacionDatosOnClicApiKeys.STATUS_DTO);
						String otpCode = response.getString(ZpValidacionDatosOnClicApiKeys.STATUS_CODE);
						if (otpCode.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_MAX))) {
							respuesta.put(ZteRestClientApiConstant.CODIGO, ZpValidacionDatosOnClicApiKeys.CODE_MAX);
						} else {
							respuesta.put(ZteRestClientApiConstant.CODIGO,
									ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
						}
					} else if (!code.getString(ZteRestClientApiConstant.CODIGO)
							.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_OK))) {
						respuesta.put(ZpValidacionDatosOnClicApiKeys.CODE,
								response.get(ZteRestClientApiConstant.CODIGO));
						respuesta.put(ZpValidacionDatosOnClicApiKeys.DESCRIPCION,
								response.get(ZpValidacionDatosOnClicApiKeys.DESCRIPCION));
					}
				} else {
					log.error("Error en el servicio de validacion " + url + StringPool.SPACE + response.toJSONString());
					guardarParametrosLog(request,
							session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
							session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
							ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
							ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INICIAR_SOLICITUD, StringPool.BLANK, url,
							StringPool.BLANK, response.toJSONString(), new Date(),
							response.getString(ZteRestClientApiConstant.CODIGO));
					respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
				}
			} else {
				log.error("Error en el servicio de guardar tratamiento de Datos " + urlTC + StringPool.SPACE
						+ responseTC.toJSONString());
				guardarParametrosLog(request,
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INICIAR_SOLICITUD, StringPool.BLANK, urlTC,
						StringPool.BLANK, response.toJSONString(), new Date(),
						responseTC.getString(ZteRestClientApiConstant.CODIGO));
				respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);

			}
		} catch (Exception e) {
			log.error("Error al consumir servicio de validaci�n: ", e);
			guardarParametrosLog(request,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
					ZpValidacionDatosOnClicApiKeys.URL_PAGINA_LOG_IN,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_INICIAR_SOLICITUD, StringPool.BLANK, url,
					StringPool.BLANK, response.toJSONString(), new Date(),
					response.getString(ZteRestClientApiConstant.CODIGO));
			respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
		}
		return respuesta;
	}

	@Override
	public String enmascararDato(String dato) {
		char[] arrayDato = dato.toCharArray();
		String datoEnmascarado = StringPool.BLANK;
		for (int i = 0; i < arrayDato.length; i++) {
			if (i % 2 != 0 && (!String.valueOf(arrayDato[i]).equals("@"))
					&& (!String.valueOf(arrayDato[i]).equals("."))) {
				datoEnmascarado += "*";
			} else {
				datoEnmascarado += arrayDato[i];
			}
		}
		return datoEnmascarado;
	}

	private JSONObject generarParametrosLogTransaccional(PortletRequest request, String tipoIdentificacion,
			String numeroIdentificacion, String urlPagina, String componenteId, Date fechaEvento) {
		JSONObject headerLogTx = JSONFactoryUtil.createJSONObject();
		this.sesionId = request.getPortletSession().getId();

		headerLogTx.put(ZteRestClientApiConstant.APLICATIVO, ZpValidacionDatosOnClicApiKeys.APLICACION_ZP);
		headerLogTx.put(ZpValidacionDatosOnClicApiKeys.IP_USUARIO,
				capturarParametro(request, ZpValidacionDatosOnClicApiKeys.IP_TEMP));
		headerLogTx.put(ZteRestClientApiConstant.USUARIO_ID, ZpValidacionDatosOnClicApiKeys.USUARIO_ID);
		headerLogTx.put(ZteRestClientApiConstant.TIPO_ID_AFILIADO, tipoIdentificacion);
		headerLogTx.put(ZteRestClientApiConstant.NUMERO_IDENTIFICACION_AFILIADO, numeroIdentificacion);
		headerLogTx.put(ZteRestClientApiConstant.NIT_EMPRESA, StringPool.BLANK);
		headerLogTx.put(ZteRestClientApiConstant.NOMBRE_PAGINA, ZpValidacionDatosOnClicApiKeys.NOMBRE_PAGINA);
		headerLogTx.put(ZteRestClientApiConstant.URL_PAGINA, urlPagina);
		headerLogTx.put(ZteRestClientApiConstant.COMPONENTE, componenteId);
		headerLogTx.put(ZteRestClientApiConstant.TRANSACCION, StringPool.BLANK);
		headerLogTx.put(ZteRestClientApiConstant.SESSION_ID, sesionId);
		headerLogTx.put(ZteRestClientApiConstant.NAVEGADOR, StringPool.BLANK);
		headerLogTx.put(ZteRestClientApiConstant.FECHA_EVENTO, fechaEvento.getTime());

		return headerLogTx;
	}

	private JSONObject generarHeaderRq(PortletRequest request) {
		JSONObject jsonHeader = JSONFactoryUtil.createJSONObject();
		String fechaRq = parseoFecha(ZpValidacionDatosOnClicApiKeys.DATE_FORMAT_1);
		String fechaClientDt = parseoFecha(ZpValidacionDatosOnClicApiKeys.DATE_FORMAT_2);

		jsonHeader.put(ZteRestClientApiConstant.RQUID, fechaRq + ZpValidacionDatosOnClicApiKeys.NUMBER_FINAL);
		jsonHeader.put(ZteRestClientApiConstant.CHANNEL_ID, ZpValidacionDatosOnClicApiKeys.CHANNEL_ID);
		jsonHeader.put(ZteRestClientApiConstant.CLIENT_ID, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.CLIENT_ID));
		jsonHeader.put(ZteRestClientApiConstant.CLIENT_NAME, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.CLIENT_NAME));
		jsonHeader.put(ZteRestClientApiConstant.SUCURSAL_ID, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.SUCURSAL_ID));
		jsonHeader.put(ZteRestClientApiConstant.SUCURSAL_NAME, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.SUCURSAL_NAME));
		jsonHeader.put(ZteRestClientApiConstant.IP_ADDR,
				capturarParametro(request, ZpValidacionDatosOnClicApiKeys.IP_TEMP));
		jsonHeader.put(ZteRestClientApiConstant.SESS_KEY, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.SESS_KEY));
		jsonHeader.put(ZteRestClientApiConstant.CLIENT_DT, fechaClientDt);
		jsonHeader.put(ZteRestClientApiConstant.USER_ID, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.USER_ID));
		jsonHeader.put(ZteRestClientApiConstant.LOGIN_ID, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.LOGIN_ID));
		jsonHeader.put(ZteRestClientApiConstant.REV_CODE, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.REV_CODE));
		jsonHeader.put(ZteRestClientApiConstant.REV_UID, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.REV_UID));
		jsonHeader.put(ZteRestClientApiConstant.REV_AUTH_ID, obtenerParametroLista(
				ZpValidacionDatosOnClicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.REV_AUTH_ID));

		return jsonHeader;
	}

	private String parseoFecha(String formato) {
		SimpleDateFormat dateFor = new SimpleDateFormat(formato);
		dateFor.setTimeZone(TimeZone.getTimeZone(ZpValidacionDatosOnClicApiKeys.DATE_FORMAT));
		return dateFor.format(new Date());
	}

	private JSONObject aceptacionesHD(String idAcepto, String acepto, String referencia) {
		JSONObject lista = JSONFactoryUtil.createJSONObject();

		lista.put(ZpValidacionDatosOnClicApiKeys.ID_ACEPTO, idAcepto);
		lista.put(ZpValidacionDatosOnClicApiKeys.REFERENCIA, referencia);
		lista.put(ZpValidacionDatosOnClicApiKeys.RESPUESTA_HD, acepto);
		lista.put(ZpValidacionDatosOnClicApiKeys.TRANSACCION_HD, ZpValidacionDatosOnClicApiKeys.TIP_TRANSACCION_HD);
		lista.put(ZpValidacionDatosOnClicApiKeys.VERSION_HD, ZpValidacionDatosOnClicApiKeys.NUM_VERSION_HD);

		return lista;
	}

	private JSONObject aceptaciones(PortletRequest request, String parametroIdDocumento, String conceptoAceptacion) {
		JSONObject lista = JSONFactoryUtil.createJSONObject();
		PortletSession session = request.getPortletSession();
		lista.put(ZpValidacionDatosOnClicApiKeys.ID_DOCUMENTO,
				Long.parseLong(session.getAttribute(parametroIdDocumento).toString()));
		lista.put(ZpValidacionDatosOnClicApiKeys.NOMBRE_PORTAFOLIO, StringPool.BLANK);
		lista.put(ZpValidacionDatosOnClicApiKeys.APLICACION_S, ZpValidacionDatosOnClicApiKeys.APLICACION);
		lista.put(ZpValidacionDatosOnClicApiKeys.IP,
				capturarParametro(request, ZpValidacionDatosOnClicApiKeys.IP_TEMP));
		lista.put(ZpValidacionDatosOnClicApiKeys.TIPO_ID_AFI,
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO));
		lista.put(ZpValidacionDatosOnClicApiKeys.NUMERO_ID_AFIL,
				Long.parseLong(session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString()));
		lista.put(ZpValidacionDatosOnClicApiKeys.NUMERO_CUENTA_PI, StringPool.BLANK);
		lista.put(ZpValidacionDatosOnClicApiKeys.TRANSACCION, ZpValidacionDatosOnClicApiKeys.PARAMETROS_TRANSACCION);
		lista.put(ZpValidacionDatosOnClicApiKeys.CONCEPTO_ACEPTACION, conceptoAceptacion);
		lista.put(ZpValidacionDatosOnClicApiKeys.RESPUESTA,
				ParamUtil.getString(request, ZpValidacionDatosOnClicApiKeys.TERMINOSCONDIONES, StringPool.BLANK).equals(
						ZpValidacionDatosOnClicApiKeys.B_TRUE) ? ZpValidacionDatosOnClicApiKeys.SI : StringPool.BLANK);
		lista.put(ZpValidacionDatosOnClicApiKeys.USUARIO_CREACION,
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO));

		return lista;
	}

	private String getAuthType(String login) {
		String authType = CompanyConstants.AUTH_TYPE_SN;
		if (login.contains(StringPool.AT)) {
			authType = CompanyConstants.AUTH_TYPE_EA;
		}
		return authType;
	}

	@Override
	public boolean registroUsuarioLiferay(PortletRequest portletRequest, PortletResponse portletResponse) {
		try {
			final ThemeDisplay themeDisplay = (ThemeDisplay) portletRequest.getAttribute(WebKeys.THEME_DISPLAY);
			final long idCompany = themeDisplay.getCompanyId();
			String correoElectronico = ZpValidacionDatosOnClicApiKeys.USUARIO_ZP_DATOS_GENERAL;
			if (correoElectronico == null || correoElectronico.isEmpty()) {
				correoElectronico = (new Date()).getTime() + ZpValidacionDatosOnClicApiKeys.ZP_CORREO_LOGIN;
			}
			boolean autoPswd = false;
			String pswd1 = ZpValidacionDatosOnClicApiKeys.CLAVE_LOCK;
			String pswd2 = ZpValidacionDatosOnClicApiKeys.CLAVE_LOCK;
			boolean autoScreenName = false;
			String screenName = ZpValidacionDatosOnClicApiKeys.SCREEN_NAME;
			String emailAddress = correoElectronico;
			Locale locale = new Locale("es", "ES");
			String firstName = ZpValidacionDatosOnClicApiKeys.FIRST_NAME;
			String middleName = StringPool.BLANK;
			String lastName = ZpValidacionDatosOnClicApiKeys.LAST_NAME;
			int prefixId = 0;
			int suffixId = 0;
			boolean male = true;
			Calendar cal = Calendar.getInstance();
			int birthdayMonth = cal.get(Calendar.MONTH);
			int birthdayDay = cal.get(Calendar.DATE);
			int birthdayYear = cal.get(Calendar.YEAR);
			String jobTitle = StringPool.BLANK;
			long[] groupIds = null;
			long[] organizationIds = null;
			long[] userGroupIds = null;
			long[] roleIds = null;
			boolean sendEmail = false;
			ServiceContext serviceContext = new ServiceContext();
			User usLog = UserLocalServiceUtil.addUser(0l, idCompany, autoPswd, pswd1, pswd2, autoScreenName, screenName,
					emailAddress, locale, firstName, middleName, lastName, prefixId, suffixId, male, birthdayMonth,
					birthdayDay, birthdayYear, jobTitle, groupIds, organizationIds, roleIds, userGroupIds, sendEmail,
					serviceContext);

			usLog.setPasswordReset(false);
			usLog.setLoginDate(new Date());
			usLog.setLastLoginDate(new Date());
			UserLocalServiceUtil.updateUser(usLog);
			String capturaIdGrupos = GetterUtil.getString(portletRequest.getPreferences()
					.getValue(ZpValidacionDatosOnClicApiKeys.PREFERENCE_JSON_GRUPOS_ID, StringPool.BLANK));
			String[] parts = capturaIdGrupos.split(",");
			for (String inIdGrupo : parts) {
				GroupLocalServiceUtil.addUserGroup(usLog.getUserId(), Long.parseLong(inIdGrupo));
			}
		} catch (PortalException e) {
			log.error("ZpActDatosInicioSesionPortlet - registroUsuarioLiferay: ", e);
			return false;
		} catch (Exception ex) {
			log.error("ZpActDatosInicioSesionPortlet - registroUsuarioLiferay: ", ex);
			return false;
		}
		return true;
	}

	@Override
	public boolean autenticaUsuarioLiferay(PortletRequest portletRequest, PortletResponse portletResponse) {
		try {
			String login = ZpValidacionDatosOnClicApiKeys.USUARIO_ZP_DATOS_GENERAL;
			String credentials = PropsUtil.get(ZpValidacionDatosOnClicApiKeys.USER_DEFAUL_P);
			boolean rememberMe = false;
			String authType = getAuthType(login);
			HttpServletRequest request = PortalUtil
					.getOriginalServletRequest(PortalUtil.getHttpServletRequest(portletRequest));
			HttpServletResponse response = PortalUtil.getHttpServletResponse(portletResponse);
			AuthenticatedSessionManagerUtil.login(request, response, login, credentials, rememberMe, authType);
			return true;
		} catch (Exception e) {
			log.error("ZpActDatosSesionPortlet - autenticaUsuarioLiferay: ", e);
			return false;
		}
	}

	@Override
	public boolean autenticacionLiferay(PortletRequest portletRequest, PortletResponse portletResponse) {
		try {
			boolean salidaDo = true;
			boolean salidaAutenticacion = true;
			boolean requiereRegistro = true;
			int intentos = 0;
			do {
				if (intentos <= 3 && salidaDo) {
					// inicion de session en Liferay
					if (this.autenticaUsuarioLiferay(portletRequest, portletResponse)) {
						// se autentica el usuario en LifeRay
						salidaDo = false;
					} else {
						// si no existe lo crea
						intentos++;
						if (requiereRegistro) {
							if (this.registroUsuarioLiferay(portletRequest, portletResponse)) {
								requiereRegistro = false;
							}
						}
					}
				} else {
					salidaDo = false;
				}
			} while (salidaDo);
			return salidaAutenticacion;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public String generarJWT(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		String urlService = obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
				ZpValidacionDatosOnClicApiKeys.URL_GENERAR_JWT);

		StringBuilder url = new StringBuilder();
		url.append(urlService).append(StringPool.FORWARD_SLASH)
				.append(session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString())
				.append(StringPool.FORWARD_SLASH)
				.append(session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString());

		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject headerLogTx = generarParametrosLogTransaccional(request,
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
				ZpValidacionDatosOnClicApiKeys.PARAMETROS_INICIO_TRANSACCION,
				ZpValidacionDatosOnClicApiKeys.PARAMETROS_INICIO_TRANSACCION, new Date());

		String jwt = StringPool.BLANK;
		headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(request).toJSONString());
		headers.put(ZpValidacionDatosOnClicApiKeys.HEADER_LOG_TX, headerLogTx.toJSONString());
		headers.put(ZpValidacionDatosOnClicApiKeys.CONTENT_TYPE, ZpValidacionDatosOnClicApiKeys.APPLICATION_JSON);

		JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
		parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.TIPO_IDENTIFICACION,
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString());
		parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO,
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString());

		JSONObject callResponse = restApi.callRestServiceByGet(url.toString(), headers, new LinkedHashMap<>(), parametrosPeticion,
				Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

		if (callResponse.getString(ZpValidacionDatosOnClicApiKeys.CODE)
				.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_OK))
				|| (callResponse.getString(ZpValidacionDatosOnClicApiKeys.CODE)
						.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_OK_E)))) {
			jwt = callResponse.getString(ZteRestClientApiConstant.JWT);
			session.setAttribute(ZteRestClientApiConstant.JWT, jwt);
			guardarParametrosLog(request,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_INICIO_TRANSACCION,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_INICIO_TRANSACCION_JWT, StringPool.BLANK, urlService,
					StringPool.BLANK, StringPool.BLANK, new Date(),
					callResponse.getString(ZpValidacionDatosOnClicApiKeys.CODE));
		} else {
			jwt = String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO);
			guardarParametrosLog(request,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_INICIO_TRANSACCION,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_INICIO_TRANSACCION_JWT, StringPool.BLANK, urlService,
					StringPool.BLANK, StringPool.BLANK, new Date(),
					callResponse.getString(ZpValidacionDatosOnClicApiKeys.CODE));
		}
		return jwt;
	}

	@Override
	public JSONObject generarOTP(PortletRequest portletRequest, PortletResponse portletReponse, String celular,
			String correo) {
		PortletSession session = portletRequest.getPortletSession();
		this.sesionId = portletRequest.getPortletSession().getId();
		String url = obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
				ZpValidacionDatosOnClicApiKeys.URL_GENERAR_OTP);
		String componenteOTP = StringPool.BLANK;

		if (!celular.equals(StringPool.BLANK)) {
			componenteOTP = ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_GENERAR_OTP_CELULAR;
		}
		if (!correo.equals(StringPool.BLANK)) {
			componenteOTP = ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_GENERAR_OTP_CORREO;
		}

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();
		JSONObject response = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
		Map<String, String> headers = new LinkedHashMap<>();

		JSONObject logHeaderTx = generarParametrosLogTransaccional(portletRequest,
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
				ZpValidacionDatosOnClicApiKeys.URL_PAGINA_OTP, componenteOTP, new Date());

		try {
			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(portletRequest).toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.HEADER_LOG_TX, logHeaderTx.toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.CONTENT_TYPE, ZpValidacionDatosOnClicApiKeys.APPLICATION_JSON);

			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.CELULAR, celular);
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.CORREO, correo);
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.FECHA_EXP_VALIDACION));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.NUMERO_IDENTIFICACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.PRIMER_APELLIDO,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.PRIMER_APELLIDO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.PRIMER_NOMBRE,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.PRIMER_NOMBRE));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.TIPO_IDENTIFICACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO));

			response = restApi.callRestServiceByPost(url, parametrosPeticion.toJSONString(), headers,
					new LinkedHashMap<>(), Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			if (!response.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO))) {
				guardarParametrosLog(portletRequest,
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_OTP, componenteOTP, StringPool.BLANK, url,
						parametrosPeticion.toJSONString(), response.toJSONString(), new Date(),
						response.getString(ZteRestClientApiConstant.CODIGO));

				if (response.getInt(ZpValidacionDatosOnClicApiKeys.CODE) == ZteRestClientApiConstant.SC_OK) {
					respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_OK);
					response = response.getJSONObject(ZpValidacionDatosOnClicApiKeys.RESPUESTA);
					session.setAttribute(ZpValidacionDatosOnClicApiKeys.TRANSACTION_ID,
							response.getString(ZpValidacionDatosOnClicApiKeys.TRANSACTION_ID));
					response = response.getJSONObject(ZpValidacionDatosOnClicApiKeys.AUTH_INFO);
					session.setAttribute(ZpValidacionDatosOnClicApiKeys.AUTH_ID,
							response.getString(ZpValidacionDatosOnClicApiKeys.AUTH_ID));
					session.setAttribute(ZpValidacionDatosOnClicApiKeys.AUTH_NAME,
							response.getString(ZpValidacionDatosOnClicApiKeys.AUTH_NAME));
				} else if (response
						.getInt(ZpValidacionDatosOnClicApiKeys.CODE) == ZpValidacionDatosOnClicApiKeys.CODE_MAX) {
					respuesta.put(ZteRestClientApiConstant.CODIGO, ZpValidacionDatosOnClicApiKeys.CODE_MAX);
				} else {
					respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
				}
			} else {
				log.error("Error en el servicio de generaci�n OTP " + response.getInt(ZteRestClientApiConstant.CODIGO));
				respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
				guardarParametrosLog(portletRequest,
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_OTP, componenteOTP, StringPool.BLANK, url,
						parametrosPeticion.toJSONString(), response.toJSONString(), new Date(),
						response.getString(ZteRestClientApiConstant.CODIGO));
			}

		} catch (Exception e) {
			log.error("Error al consumir servicio de generaci�n OTP: ", e);
			guardarParametrosLog(portletRequest, StringPool.BLANK, StringPool.BLANK,
					ZpValidacionDatosOnClicApiKeys.URL_PAGINA_OTP, componente, StringPool.BLANK, url,
					parametrosPeticion.toJSONString(), response.toJSONString(), new Date(),
					response.getString(ZteRestClientApiConstant.CODIGO));
			respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
		}
		return respuesta;
	}

	@Override
	public JSONObject validarOTP(PortletRequest portletRequest, PortletResponse portletResponse, String otp) {
		PortletSession session = portletRequest.getPortletSession();
		this.sesionId = portletRequest.getPortletSession().getId();
		String url = obtenerParametroLista(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
				ZpValidacionDatosOnClicApiKeys.URL_VALIDAR_OTP);

		JSONObject respuesta = JSONFactoryUtil.createJSONObject();
		JSONObject response = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
		Map<String, String> headers = new LinkedHashMap<>();

		JSONObject logHeaderTx = generarParametrosLogTransaccional(portletRequest,
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
				session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
				ZpValidacionDatosOnClicApiKeys.URL_PAGINA_OTP_VALIDAR,
				ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_CONTINUAR, new Date());
		try {
			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(portletRequest).toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.HEADER_LOG_TX, logHeaderTx.toJSONString());
			headers.put(ZpValidacionDatosOnClicApiKeys.CONTENT_TYPE, ZpValidacionDatosOnClicApiKeys.APPLICATION_JSON);

			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.AUTH_ID,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.AUTH_ID));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.AUTH_NAME,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.AUTH_NAME));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.NUMERO_IDENTIFICACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.OTP, otp);
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.TIPO_IDENTIFICACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO));
			parametrosPeticion.put(ZpValidacionDatosOnClicApiKeys.TRANSACTION_ID,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TRANSACTION_ID));

			response = restApi.callRestServiceByPost(url, parametrosPeticion.toJSONString(), headers,
					new LinkedHashMap<>(), Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			if (!response.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO))) {
				guardarParametrosLog(portletRequest,
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_OTP_VALIDAR,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_CONTINUAR, StringPool.BLANK, url,
						parametrosPeticion.toJSONString(), response.toJSONString(), new Date(),
						response.getString(ZteRestClientApiConstant.CODIGO));

				if (response.getInt(ZpValidacionDatosOnClicApiKeys.CODE) == 200) {
					generarJWT(portletRequest);
					respuesta.put(ZteRestClientApiConstant.CODIGO,
							response.getInt(ZpValidacionDatosOnClicApiKeys.CODE));
				} else if (response.getInt(
						ZpValidacionDatosOnClicApiKeys.CODE) == ZpValidacionDatosOnClicApiKeys.CODE_MAX_VALIDACION
						|| response.getInt(ZpValidacionDatosOnClicApiKeys.CODE) == Integer
								.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_OK_E)
						|| response.getInt(ZpValidacionDatosOnClicApiKeys.CODE) == Integer
								.valueOf(ZpValidacionDatosOnClicApiKeys.CODE_BLOQ_OTP)
						|| response.getInt(
								ZpValidacionDatosOnClicApiKeys.CODE) == ZpValidacionDatosOnClicApiKeys.CODE_EXP) {
					respuesta.put(ZteRestClientApiConstant.CODIGO,
							response.getInt(ZpValidacionDatosOnClicApiKeys.CODE));
				} else {
					respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
				}
			} else {
				log.error("Error en el servicio de validacion " + response.getInt(ZteRestClientApiConstant.CODIGO));
				respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
				guardarParametrosLog(portletRequest,
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
						session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
						ZpValidacionDatosOnClicApiKeys.URL_PAGINA_OTP_VALIDAR,
						ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_CONTINUAR, StringPool.BLANK, url,
						parametrosPeticion.toJSONString(), response.toJSONString(), new Date(),
						response.getString(ZteRestClientApiConstant.CODIGO));
			}
		} catch (Exception e) {
			log.error("Error al consumir servicio de validaci�n: ", e);
			guardarParametrosLog(portletRequest,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString(),
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString(),
					ZpValidacionDatosOnClicApiKeys.URL_PAGINA_OTP_VALIDAR,
					ZpValidacionDatosOnClicApiKeys.PARAMETROS_BT_CONTINUAR, StringPool.BLANK, url,
					parametrosPeticion.toJSONString(), response.toJSONString(), new Date(),
					response.getString(ZteRestClientApiConstant.CODIGO));
			respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
		}
		return respuesta;
	}
}