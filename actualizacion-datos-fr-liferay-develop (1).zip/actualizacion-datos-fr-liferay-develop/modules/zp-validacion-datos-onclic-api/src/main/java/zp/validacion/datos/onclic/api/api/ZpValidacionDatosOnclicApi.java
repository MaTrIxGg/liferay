package zp.validacion.datos.onclic.api.api;

import com.liferay.portal.kernel.json.JSONObject;

import java.util.Date;

import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;

import org.osgi.annotation.versioning.ProviderType;

/**
 * @author POR12989
 */
@ProviderType
public interface ZpValidacionDatosOnclicApi {

	void capturarSeleccion(PortletRequest request, String seleccionResidencia);

	void guardarDatosPortletSession(PortletRequest request, String tipoDocumento, String numeroDocumento,
			String fechaExpedicion, String numeroCelular, String correoElectronico);

	public String capturarParametro(PortletRequest request, String nombreParametro);

	void inicializarParametro(PortletRequest request, String nombreParametro, String parametro);

	void guardarParametrosLog(PortletRequest request, String tipoIdUsuario, String numeroIdentificacion,
			String urlPagina, String componente, String navegador, String servicioConsumido, String parametrosConsumo,
			String parametrosSalida, Date dateConsumoServicio, String codigo);

	public JSONObject validacionAcceso(PortletRequest request, boolean validacionZTA);

	public String enmascararDato(String dato);

	public JSONObject obtenerDocumentoHD(PortletRequest request);

	public JSONObject obtenerDocumentoTC(PortletRequest request);

	boolean registroUsuarioLiferay(PortletRequest portletRequest, PortletResponse portletResponse);

	boolean autenticaUsuarioLiferay(PortletRequest portletRequest, PortletResponse portletResponse);

	boolean autenticacionLiferay(PortletRequest portletRequest, PortletResponse portletResponse);

	public JSONObject validarContrase�aZTA(PortletRequest request, PortletResponse response, String pswd);

	void guardarDatosLogin(PortletRequest request, String tipoDocumento, String numeroDocumento, String numeroFormato,
			String fechaExpedicion, String numeroCelular, String correoElectronico, String jwt, String sesionZTA,
			String descripcionAuth, String datoAuth, String seleccionResidencia);

	public JSONObject generarOTP(PortletRequest portletRequest, PortletResponse portletReponse, String celular, String correo);

	public JSONObject validarOTP(PortletRequest portletRequest, PortletResponse portletResponse, String otp);

	public String generarJWT(PortletRequest request);

}