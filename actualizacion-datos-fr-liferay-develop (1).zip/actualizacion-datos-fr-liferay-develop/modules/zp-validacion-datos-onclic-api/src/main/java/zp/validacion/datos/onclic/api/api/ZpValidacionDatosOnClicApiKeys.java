package zp.validacion.datos.onclic.api.api;

public class ZpValidacionDatosOnClicApiKeys {

	private ZpValidacionDatosOnClicApiKeys() {
		super();
	}

	public static final String CODIGO = "codigoRespuesta";
	public static final String CODE = "codigo";
	public static final String DESCRIPCION = "descripcion";
	public static final String STATUS = "status";
	public static final String STATUS_CODE = "statusCode";
	public static final String STATUS_DES = "statusDesc";
	public static final String LISTA_DOCUMENTOS = "listaDocumentos";
	public static final String MENSAJE = "resultadoRegistro";
	public static final String CLAVE_INCORRECTA = "USUARIO_CLAVE_INCORRECTO";
	public static final String USUARIO_BLOQUEADO = "USUARIO_CUENTA_BLOQUEADA";
	public static final String PSWD_EXPIRO = "PSWD_EXPIRO";
	public static final String PSWD_ZTA = "pswd";
	public static final String LISTA_PROPIEDADES = "ZPACTListaPropiedades";
	public static final String LISTA_PARAMETROS_SERVICIOS = "ZPACTListaParametrosServiciosActualizacion";
	public static final String LISTA_PROPIEDADES_GLOBAL = "ListaPropiedadesGlobalPrincipal";
	public static final String APLICACION = "ZP_ACT";
	public static final String USUARIO_ID = "PORTAL_PORVENIR";
	public static final String NOMBRE_PAGINA = "ACTUALIZACION_DATOS_ZONA_PUBLICA";
	public static final String URL_PAGINA_RESIDENCIA = "Actualiza_tus_datos_residencia";
	public static final String URL_PAGINA_LOG_IN = "Actualiza_tus_datos_Log_in";
	public static final String URL_PAGINA_OTP = "Actualiza_tus_datos_OTP";
	public static final String URL_PAGINA_OTP_VALIDAR = "Actualiza_tus_datos_validar_OTP";
	public static final String URL_REST_LOGS = "URL_REST_LOGS";
	public static final String URL_ACTUALIZACION_DATOS_INICIAR_SESION_ZTA = "URL_ACTUALIZACION_DATOS_INICIAR_SESION_ZTA";
	public static final String URL_ACTUALIZACION_DATOS = "URL_ACTUALIZACION_DATOS";
	public static final String URL_VALIDACION_DATOS = "URL_VALIDACION_DATOS";
	public static final String URL_VALIDACION_ACCESO_SERVICIO = "URL_VALIDACION_ACCESO_SERVICIO";
	public static final String URL_GUARDAR_TC = "URL_GUARDAR_TC";	
	public static final String URL_NOTIFICACION_CCM = "URL_NOTIFICACION_CCM";
	public static final String URL_OBTENER_DOCUMENTO = "URL_OBTENER_DOCUMENTO";
	public static final String URL_GENERAR_JWT = "URL_GENERAR_JWT";
	public static final String URL_GENERAR_OTP = "URL_GENERAR_OTP";
	public static final String URL_VALIDAR_OTP = "URL_VALIDAR_OTP";
	public static final String JWT = "jwt";
	public static final String DATE_FORMAT = "America/Bogota";
	public static final String URL_INICIO_TRANSACCION = "INICIO_TRANSACCION";
	public static final String RESIDE_COL = "Col";
	public static final String RESIDE_EXT = "Ext";
	public static final String COMPONENTE_LOGIN = "BT_CONTINUAR";
	public static final String CHANNEL_ID = "ZTA";
	public static final String RQ_UID = "rqUID";
	public static final String CLIENT_DT = "clientDT";
	public static final String OPCIONES_ID = "opcionesId";
	public static final String SELECCION_OTP = "seleccionOTP";
	public static final String CODE_OTP = "codeOTP";
	public static final String FLUJO_OTP = "flujoOTP";

	public static final String TIPO_DOCUMENTO = "tipoDocumento";
	public static final String TIPO_IDENTIFICACION = "tipoIdentificacion";
	public static final String NUMERO_DOCUMENTO = "numeroDocumento";
	public static final String IDENTIFICACION = "identificacion";
	public static final String NUMERO_IDENTIFICACION = "numeroIdentificacion";
	public static final String IDENTIFICACION_N = "Identificacion";
	public static final String IDENTIFICACION_F = "IdentificacionFormato";
	public static final String PSWD = "contrasena";
	public static final String FECHA_EXPEDICION = "fechaExpedicion";
	public static final String NUMERO_CELULAR = "numeroCelular";
	public static final String NUM_CELULAR = "numCelular";
	public static final String NUMBER_FORMAT = "numeroFormato";
	public static final String CELULAR = "celular";
	public static final String CELULAR_OTP = "celularOTP";
	public static final String CORREO_ELECTRONICO = "correoElectronico";
	public static final String CORREO = "correo";
	public static final String CORREO_OTP = "correoOTP";
	public static final String EXTERIOR = "exterior";
	public static final String INTENTOS = "intentos";
	public static final String INTENTOS_VALIDACION = "intentosValidacion";
	public static final String SELECCION_RESIDENCIA = "seleccionResidencia";
	public static final String SELECCION_VALIDACION = "seleccionValidacion";
	public static final String SESION_ZTA = "sesionZTA";
	public static final String SESION_ONBOARDING = "sesionOnboarding";
	public static final String INICIO_SESION = "inicioSesion";
	public static final String TERMINOS_CONDICIONES = "TC";
	public static final String HABEAS_DATA = "HD";	
	public static final String VALIDACION_ZTA = "validadoZTA";
	public static final String SELECT_RESIDENCIA = "selectResidencia";
	public static final String SUCCESSFULL = "Guardada";
	public static final String TIPO_DOCUMENTO_SERVICIO = "tipoDocumentoServicio";

	/* SERVICIO DOCUMENTO TERMINOS Y CONDICIONES */
	public static final String TIPO_DOCUMENTO_SERVICIO_TC = "TERMINOSYCONDICIONES";
	public static final String CANAL_SERVICIO_TC = "USO_PLATAFORMA";
	public static final String UNDEFINED = "undefined";
	public static final String CODIGO_REFERENCIA_SERVICIO_TC = "1005";
	public static final String FUNCIONALIDAD_SERVICIO_TC = "CANAL";
	public static final String BASE64 = "contenidoDocumento";
	public static final String BASE64TC = "base64TC";
	public static final String BASE64HD = "base64HD";
	public static final String ERROR_TECNICO_DESC = "errorTecnico";
	public static final int CODE_ERROR_TECNICO = 500;
	public static final int CODE_ERROR_PETICION = 409;
	public static final String ID_DOCUMENTO = "idDocumento";
	public static final String ID_DOCUMENTO_TC = "idDocumentoTC";

	/* SERVICIO DOCUMENTO HABEAS DATA */
	public static final String TIPO_DOCUMENTO_SERVICIO_HD = "TRATAMIENTODATOS";
	public static final String CANAL_SERVICIO_HD = "HABEAS_DATA";
	public static final String CODIGO_REFERENCIA_SERVICIO_HD = "1004";
	public static final String FUNCIONALIDAD_SERVICIO_HD = "CANAL";
	public static final String ID_DOCUMENTO_HD = "idDocumentoHD";
	public static final String TIPO_DOCUMENTO_PARAMETRO = "tipoDocumento";
	public static final String PRODUCTO_PARAMETRO = "producto";
	public static final String NOMBRE_REFERENCIA_PARAMETRO = "nombreReferencia";
	public static final String CODIGO_REFERENCIA_PARAMETRO = "codigoReferencia";
	public static final String FUNCIONALIDAD_PARAMETRO = "funcionalidad";

	public static final String TYPE_ID = "typeID";
	public static final String TYPE = "typeId";
	public static final String NO_ID = "noID";
	public static final String ACEPTACIONES = "aceptaciones";

	public static final String SERVICE_ID = "serviceID";
	public static final String SERVICE_TRANSACTION = "serviceTransaction";
	public static final String CONTENT_TYPE = "Content-type";
	public static final String APPLICATION_JSON = "application/json";
	public static final String DATE_FORMAT_1 = "yyyyMMddHHmmssSSS";
	public static final String DATE_FORMAT_2 = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	public static final String NUMBER_FINAL = "12";

	public static final String PRESTACION_DEFINIDA = "PRESTACION_DEFINIDA";

	/* ACEPTACIONES */
	public static final String NOMBRE_PORTAFOLIO = "nombrePortafolio";
	public static final String APLICACION_S = "aplicacion";
	public static final String IP = "ip";
	public static final String IP_TEMP = "ipTemp";
	public static final String IP_USUARIO = "ipUsuario";
	public static final String TIPO_ID_AFI = "tipoIdAfil";
	public static final String NUMERO_ID_AFIL = "numeroIdAfil";
	public static final String NUMERO_CUENTA_PI = "numeroCuentaPI";
	public static final String TRANSACCION = "transaccion";
	public static final String CONCEPTO_ACEPTACION = "conceptoAceptacion";
	public static final String RESPUESTA = "respuesta";
	public static final String USUARIO_CREACION = "usuarioCreacion";
	public static final String TIPO_DOCUMENTO_HD = "tipoDocumentoHD";
	/* CODIGOS SERVICIOS */
	public static final int ERROR_TECNICO = 0;
	public static final int FALLECIDO = 1;
	public static final int NO_PRODUCTOS = 2;
	public static final int USUARIO_ZTA = 3;
	public static final int DATOS_INVALIDOS = 4;
	public static final int USER_BLOQUEADO = 5;
	public static final int OTP_CORREO = 6;
	public static final int OTP_SMS = 7;
	public static final int OTP_EXIOSO = 8;
	public static final int NUM_MAXIMO = 9;
	public static final int SELECT_OTP = 10;
	public static final int LISTA_RESTRICTIVA = 11;

	public static final String CODE_U = "1";

	/* DESCRIPCION SERVICIOS */
	public static final String DES_PROBLEMA_TEC = "PROBLEMA TECNICO";
	public static final String DES_FALLECIDO = "FALLECIDO";
	public static final String DES_NO_PRODUCTOS = "NO TIENE PRODUCTOS";
	public static final String DES_USUARIO_ZTA = "USUARIO TIENE ZTA";
	public static final String DES_DATOS_INVALIDO = "DATOS INVALIDO";
	public static final String DES_USER_BLOQUEADO = "USUARIO BLOQUEADO";
	public static final String DES_OTP_CORREO = "OTP SE ENVIA POR CORREO";
	public static final String DES_OTP_SMS = "OTP SE ENVIA POR SMS";
	public static final String DES_OTP_EXITOSO = "OTP GENERADO EXITOSAMENTE";
	public static final String DES_SELECCION_OTP = "SELECCION MEDIO DE CONTACTO OTP";
	public static final String DES_USUARIO_SIN_PROD = "USUARIO SIN PRODUCTOS";
	public static final String DES_LISTA_RESTRICTIVA = "USUARIO ENCONTRADO EN LISTAS RESTRICTIVAS";

	public static final String DES_AUTE_EXITOSA = "AUTENTICACION EXITOSA";
	public static final String DES_USUA_CLAVE_INCORRECTA = "USUARIO O CLAVE INCORRECTA";
	public static final String DES_CUENTA_BLOQUEADA = "CUENTA BLOQUEADA";
	public static final String DES_PSWD_EXPIRO = "PSWD EXPIRO";

	/* HEADER LOG TRANSACCIONAL */
	public static final String APLICACION_ZP = "ZP_ACT";
	public static final String HEADER_LOG_TX = "headerLogTx";
	/* NOTIFICACIONES */
	public static final String CARD_ID = "cardId";
	public static final String VALOR_CARD_ID = "5b2985db1ee9330b258bb05f";
	public static final String DESTINATARIO = "destinatario";
	public static final String MENSAJE_NOTIF = "mensaje";
	public static final String PLANTILLA_NOTIF = "PLANTILLA_CCM";
	public static final String DESTINATARIO_VAL = "Afiliado";
	public static final String DATA = "data";
	public static final String ID_NOTI = "id";
	public static final String TYPE_ID_NOTI = "typeId";
	public static final String CUSTOMERS = "customers";
	public static final String VALOR_NOTIF_SI = "si";
	public static final String VALOR_NOTIF_NO = "no";
	public static final String NOTIFICACION_CCM = "NOTIFICACION_CCM";
	public static final String DESCRIPCION_AUTH = "DESCRIPCION_AUTH";
	public static final String DATO_AUTH = "DATO_AUTH";

	/* CONST REGISTRO LOGS */
	public static final String PARAMETROS_CONSUMO_RESIDENCIA = "VARIABLE:TRUE";
	public static final String PARAMETROS_COL = "Col";
	public static final String PARAMETROS_BT_COLOMBIA = "BT_COLOMBIA";
	public static final String PARAMETROS_BT_EXTERIOR = "BT_EXTERIOR";
	public static final String PARAMETROS_BT_INICIAR_SOLICITUD = "BT_INICIAR_MI_SOLICITUD";
	public static final String PARAMETROS_BT_GENERAR_OTP_CELULAR = "BT_GENERAR_OTP_CELULAR";
	public static final String PARAMETROS_BT_GENERAR_OTP_CORREO = "BT_GENERAR_OTP_CORREO";
	public static final String PARAMETROS_BT_CONTINUAR = "BT_CONTINUAR";
	public static final String PARAMETROS_BT_INGRESAR = "BT_INGRESAR";
	public static final String PARAMETROS_RENDER_INICIAR_FORMULARIO = "RENDER_INICIAR_FORMULARIO";
	public static final String PARAMETROS_TRANSACCION = "INICIAR_SESION";
	public static final String PARAMETROS_CONCEPTO_ACEPTACION_TC = "ACEPTA_TRATAMIENTO_DATOS";
	public static final String PARAMETROS_CONCEPTO_ACEPTACION_HD = "ACEPTA_TERMINOS_CONDICIONES_USO";
	public static final String PARAMETROS_ACEPTA = "si";
	public static final String PARAMETROS_ACTUALIZA_TUS_DATOS_CREDENCIALES_ZTA = "Actualiza_tus_datos_credenciales_ZTA";
	public static final String PARAMETROS_INICIO_TRANSACCION = "INICIO_TRANSACCION";
	public static final String PARAMETROS_INICIO_TRANSACCION_JWT = "INICIO_TRANSACCION_JWT";
	/* SESION LIFERAY */
	public static final String USUARIO_ZP_DATOS_GENERAL = "usuarioactdatos@zpporvenir.com";
	public static final String ZP_CORREO_LOGIN = "@porveniretmatemporal.com";
	public static final String CLAVE_LOCK = "Temporal1234567";
	public static final String SCREEN_NAME = "UsuarioActDatos";
	public static final String FIRST_NAME = "usuario";
	public static final String LAST_NAME = "general";
	public static final String PREFERENCE_JSON_GRUPOS_ID = "PREFERENCE_JSON_GRUPOS_ID";
	public static final String USER_DEFAUL_P = "user.defaul.pwd";
	/* PARAMETROS GENERACION OTP */
	public static final String VALIDACION_IDENTIDAD = "validacionIdentidad";
	public static final String OBJETO = "validacionIdentidadRespuesta";
	public static final String OBJETO_OTP = "generacionOTPRespuesta";
	public static final String FECHA_EXP_VALIDACION = "fechaExpValidacion";
	public static final String PRIMER_APELLIDO = "primerApellido";
	public static final String PRIMER_NOMBRE = "primerNombre";
	public static final String CELULAR_VALIDACION = "celularValidacion";
	public static final String DATO_SEGURO = "datoSeguro";
	public static final String CORREO_VALIDACION = "correoValidacion";
	public static final String DATO = "datoOTP";
	public static final String DESCRIPCION_DATO = "descripcionDatoOTP";
	public static final String STATUS_DTO = "statusDto";
	public static final String TRANSACTION_ID = "transactionId";
	public static final String OTP = "otp";
	public static final String AUTH_NAME = "authName";
	public static final String AUTH_ID = "authId";
	public static final String AUTH_INFO = "authInfo";
	public static final int CODE_MAX = 201;
	public static final int CODE_MAX_VALIDACION = 202;
	public static final int CODE_EXP = 203;
	public static final String CODE_OK = "200";
	public static final String CODE_OK_E = "204";
	public static final String CODE_BLOQ_OTP = "206";
	public static final String TIEMPO_LABEL_OTP = "TIEMPO_LABEL_OTP";
	public static final String TIME_LABEL_OTP = "timeLabel";
	
	
	//Conceptos Habeas Data
	public static final String SENSIBLE = "SENSIBLE";
	public static final String FINALIDADES_COMERCIALES = "FINALIDADES_COMERCIALES";
	public static final String RESPONSABLE_PORVENIR = "RESPONSABLE_PORVENIR";
	public static final String PORVE_MERCADEO = "PORVE_MERCADEO";
	public static final String PORVE_OPEN_FINANCE = "PORVE_OPEN_FINANCE";
	public static final String PORVE_PORTABILIDAD = "PORVE_PORTABILIDAD";
	public static final String ENTIDADES_AVAL = "ENTIDADES_AVAL";
	public static final String GA_MERCADEO = "GA_MERCADEO";
	public static final String GA_OPEN_FINANCE = "GA_OPEN_FINANCE";
	public static final String GA_PORTABILIDAD = "GA_PORTABILIDAD";
	public static final String ENTIDADES_GESA = "ENTIDADES_GESA";
	public static final String GESA_MERCADEO = "GESA_MERCADEO";
	public static final String GESA_OPEN_FINANCE = "GESA_OPEN_FINANCE";
	public static final String GESA_PORTABILIDAD = "GESA_PORTABILIDAD";
	public static final String CALID_RESP_TRATA_DATOS = "CALID_RESP_TRATA_DATOS";
	public static final String MENOR_EDAD = "MENOR_EDAD";
	public static final String OBL_MENOR_EDAD = "OBL_MENOR_EDAD";
	public static final String ESENCIAL = "ESENCIAL";
	public static final String DERECHO_TITULAR = "DERECHO_TITULAR";
	public static final String CANAL_CONTACTO = "CANAL_CONTACTO";
	public static final String SI_AUTORIZO = "siAutorizo";
	public static final String NO_AUTORIZO = "noAutorizo";	
	public static final String UNO = "uno";
	public static final String B_TRUE = "true";
	public static final String DOS_UNO_UNO = "dosunouno";
	public static final String DOS_UNO_DOS = "dosunodos";
	public static final String DOS_UNO_TRES = "dosunotres";
	public static final String DOS_DOS_UNO = "dosdosuno";
	public static final String DOS_DOS_DOS = "dosdosdos";
	public static final String DOS_DOS_TRES = "dosdostres";
	public static final String DOS_TRES_UNO = "dostresuno";
	public static final String DOS_TRES_DOS = "dostresdos";
	public static final String DOS_TRES_TRES = "dostrestres";
	public static final String TRES = "tres";
	
	public static final String SENSIBLE_N = "2";
	public static final String FINALIDADES_COMERCIALES_N = "5.1";
	public static final String RESPONSABLE_PORVENIR_N = "3.1";
	public static final String PORVE_MERCADEO_N = "3.1.1";
	public static final String PORVE_OPEN_FINANCE_N = "3.1.2";
	public static final String PORVE_PORTABILIDAD_N = "3.1.3";
	public static final String ENTIDADES_AVAL_N = "3.2";
	public static final String GA_MERCADEO_N = "3.2.1";
	public static final String GA_OPEN_FINANCE_N = "3.2.2";
	public static final String GA_PORTABILIDAD_N = "3.2.3";
	public static final String ENTIDADES_GESA_N = "3.3";
	public static final String GESA_MERCADEO_N = "3.3.1";
	public static final String GESA_OPEN_FINANCE_N = "3.3.2";
	public static final String GESA_PORTABILIDAD_N = "3.3.3";
	public static final String CALID_RESP_TRATA_DATOS_N = "";
	public static final String MENOR_EDAD_N = "4";
	public static final String OBL_MENOR_EDAD_N = "";
	public static final String ESENCIAL_N = "1";
	public static final String DERECHO_TITULAR_N = "5";
	public static final String CANAL_CONTACTO_N= "6";
	
	public static final String SI= "SI";
	public static final String NO= "NO";
	
	public static final String PARAM_HABEAS_DATA = "habeasDataGroup";
	public static final String CONSENTIMIENTOS = "consentimientos";
	public static final String TERMINOSCONDIONES = "terminosCondiones";
	public static final Integer NUM_DOCUMENTO_TC = 518;
	
	public static final String ID_ACEPTO = "idAcepto";
	public static final String REFERENCIA ="referencia";
	public static final String RESPUESTA_HD ="respuesta";
	public static final String TRANSACCION_HD ="transaccion";
	public static final String TIP_TRANSACCION_HD ="ACTUALIZACION_DATOS";
	public static final String VERSION_HD ="version";
	public static final String NUM_VERSION_HD ="3";
	
}