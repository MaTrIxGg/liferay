package zp.actualizacion.datos.onclic.filter;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.CompanyLocalServiceUtil;
import com.liferay.portal.kernel.service.RoleServiceUtil;
import com.liferay.portal.kernel.servlet.BaseFilter;
import com.liferay.portal.kernel.servlet.HttpHeaders;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.IOException;
import java.net.URL;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;

@Component(immediate = true, property = { "servlet-context-name=", "servlet-filter-name=ZP_ACT Filter",
		"url-pattern=/group/actualizacion-de-datos-a-un-clic/*" }, service = Filter.class)

public class ZpActualizacionDatosOnclicFilter extends BaseFilter {

	@Reference
	private  DinamicDatalistApi dataListApi;

	private static Log log = LogFactoryUtil.getLog(ZpActualizacionDatosOnclicFilter.class);

	@Override
	protected Log getLog() {
		return log;
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {
		try {
			String urlProvider = dataListApi.getRecordValue(ZpActualizacionDatosOnclicFilterKeys.LISTA_PROPIEDADES,
					ZpActualizacionDatosOnclicFilterKeys.URL_PROVIDER);
			String urlOrigen = null;
			String urlDestino = null;
			User user = (User) servletRequest.getAttribute(WebKeys.USER);
			HttpServletResponse httpResponse = (HttpServletResponse) servletResponse;

			urlOrigen = ((HttpServletRequest) servletRequest).getHeader(HttpHeaders.REFERER);

			if (urlOrigen == null) {
				urlDestino = ZpActualizacionDatosOnclicFilterKeys.URL_EXIT;
			} else {
				if (user != null) {
					String uriAddress = new URL(urlOrigen).getPath();
					long companyId = CompanyLocalServiceUtil.getCompanyIdByUserId(user.getUserId());
					boolean userAdmin = RoleServiceUtil.hasUserRole(user.getUserId(), companyId,
							ZpActualizacionDatosOnclicFilterKeys.ROLE_ADMIN, false);
					boolean userOwner = RoleServiceUtil.hasUserRole(user.getUserId(), companyId,
							ZpActualizacionDatosOnclicFilterKeys.ROLE_OWNER, false);

					if ((!userAdmin && !userOwner) && urlProvider.equals(uriAddress)) {
						urlDestino = ZpActualizacionDatosOnclicFilterKeys.URL_EXIT;
					}
				} else {
					String uriAddress = new URL(urlOrigen).getPath();
					if (!urlProvider.equals(uriAddress)) {
						urlDestino = ZpActualizacionDatosOnclicFilterKeys.URL_EXIT;
					}
				}

			}

			if (urlDestino != null) {
				httpResponse.sendRedirect(urlDestino);
				return;
			}
			filterChain.doFilter(servletRequest, servletResponse);
		} catch (Exception e) {
			log.error("Ocurrio un error al realizar filtro de url: " + e);
		}
	}
}
