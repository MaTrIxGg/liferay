package zp.actualizacion.datos.onclic.filter;

public class ZpActualizacionDatosOnclicFilterKeys {

	public static final String LISTA_PROPIEDADES = "ZPACTListaPropiedades";
	public static final String URL_PROVIDER="URL_PROVIDER_FILTER";
	public static final String URL_EXIT="/c/portal/logout";
	public static final String ROLE_ADMIN="Administrator";
	public static final String ROLE_OWNER="Owner";
}
