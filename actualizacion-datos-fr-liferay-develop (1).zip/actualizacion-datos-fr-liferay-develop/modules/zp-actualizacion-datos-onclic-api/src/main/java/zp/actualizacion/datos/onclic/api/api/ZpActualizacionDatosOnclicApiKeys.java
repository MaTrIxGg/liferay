package zp.actualizacion.datos.onclic.api.api;

public class ZpActualizacionDatosOnclicApiKeys {

	private ZpActualizacionDatosOnclicApiKeys() {
		super();
	}

	/* DATOS DE USUARIO */
	public static final String TIPO_DOCUMENTO = "tipoDocumento";
	public static final String NUMERO_DOCUMENTO = "numeroDocumento";
	public static final String NUMERO_FORMATO = "numeroFormato";
	public static final String NUMERO_CELULAR = "numeroCelular";
	public static final String CORREO_ELECTRONICO = "correoElectronico";
	public static final String CORREO_ACTUAL = "correoActual";
	public static final String CELULAR_ACTUAL = "celularActual";
	public static final String CORREO_ELECTRONICO_LOGIN = "correoLogin";
	public static final String DIRECCION = "direccion";
	public static final String URL_NOTIFICACION_CCM = "URL_NOTIFICACION_CCM";
	public static final String URL_NOTIFICACION_EMAIL_CCM = "URL_NOTIFICACION_EMAIL_CCM";
	public static final String DETALLE = "detalle";
	public static final String RESPUESTA = "respuesta";
	public static final String NOTIFICACION_CCM_DATOS = "notificacionCCM";
	public static final String DESCRIPCION_AUTH = "DESCRIPCION_AUTH";
	public static final String DATO_AUTH = "DATO_AUTH";
	public static final String SELECCION_RESIDENCIA = "seleccionResidencia";

	/* NOTIFICACIONES */
	public static final String CARD_ID = "cardId";
	public static final String VALOR_CARD_ID_INICIO = "61e9d41c59a15e0008593d3f";
	public static final String VALOR_CARD_ID_FIN = "61e9d608827a3400088ee119";
	public static final String DESTINATARIO = "destinatario";
	public static final String MENSAJE_NOTIF = "mensaje";
	public static final String TIPO_P_NOTIF = "tipoPersona";
	public static final String TIPO_P_NOTIF_VAL = "Afiliado";
	public static final String VALOR_NOTIF_SI = "si";
	public static final String VALOR_NOTIF_NO = "no";
	public static final String PLANTILLA_NOTIF_INICIO = "PLANTILLA_CCM_INICIO";
	public static final String PLANTILLA_NOTIF_FIN = "PLANTILLA_CCM_FIN";
	public static final String DESTINATARIO_VAL = "Todos";
	public static final String DATA = "data";
	public static final String ID_NOTI = "id";
	public static final String TYPE_ID_NOTI = "typeId";
	public static final String CUSTOMERS = "customers";
	public static final String ID = "Id";
	public static final String FECHA = "fecha";
	public static final String ZONASEGURIDAD = "ZonaSeguridad";
	public static final String PRIMERNOMBRE_EMAIL = "PrimerNombre";
	public static final String NOMBRES_NOT = "nombres";
	public static final String APELLIDO_NOT = "apellidos";
	public static final String PRIMERAPELLIDO_EMAIL = "PrimerApellido";
	public static final String PRIMERNOMBRE = "primerNombre";
	public static final String SEGUNDO_NOMBRE = "segundoNombre";
	public static final String PRIMERAPELLIDO = "primerApellido";
	public static final String SEGUNDO_APELLIDO = "segundoApellido";
	public static final String EMAIL = "email";
	public static final String CELULAR_NOT = "celularNotificacion";
	public static final String CORREO_NOT = "correoNotificacion";
	public static final String SERVICE_ID = "serviceID";
	public static final String SERVICE_TRANSACTION = "serviceTransaction";
	public static final String PLANTILLA_SALUDO = "Reciba un saludo cordial,";
	public static final String PLANTILLA_FELICITACIONES = "Felicitaciones ";

	/* DDL'S */
	public static final String LISTA_PROPIEDADES = "ZPACTListaPropiedades";
	public static final String LISTA_PROPIEDADES_GLOBAL = "ListaPropiedadesGlobalPrincipal";
	public static final String URL_CONSULTA_DATOS_BASICOS = "URL_CONSULTA_DATOS_BASICOS";
	public static final String RENDER_ACTUALIZA_INFORMACION = "RENDER_ACTUALIZA_INFORMACION";
	public static final String LISTA_PARAMETROS_SERVICIOS = "ZPACTListaParametrosServiciosActualizacion";
	public static final String LISTA_TIPOS_DOC_SIEBEL = "listaTiposDocumentoSiebel";

	/* CONSTANTES SERVICIOS */
	public static final String DATE_FORMAT_1 = "yyyyMMddHHmmssSSS";
	public static final String DATE_FORMAT_2 = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	public static final String DATE_FORMAT_3 = "yyyyMMdd";
	public static final String NUMBER_FINAL = "12";
	public static final String DATE_FORMAT = "America/Bogota";
	public static final String HEADER_LOG_TX = "headerLogTx";
	public static final String STATUS_CODE = "statusCode";
	public static final String STATUS = "status";
	public static final String DATOS_BASICOS = "datosBasicos";
	public static final String NOMBRES_COMPLETOS = "nombresApellidosCompletos";
	public static final String FECHA_NACIMIENTO = "fechaNacimiento";
	public static final String FECHA_DE_NACIMIENTO = "fechaDeNacimiento";
	public static final String GENERO = "genero";
	public static final String GENERO_M_I = "M";
	public static final String GENERO_F = "Femenino";
	public static final String GENERO_M = "Masculino";
	public static final String DATOS_CONTACTO = "datosContacto";
	public static final String CODIGO_CIUDAD = "codigoCiudad";
	public static final String CODIGO_DEPARTAMENTO = "codigoDepartamento";
	public static final String CIUDADES = "ciudades";
	public static final String CIUDADES_SELECT = "ciudadesSelect";
	public static final String DEPARTAMENTOS = "departamentos";
	public static final String CONTENT_TYPE = "Content-type";
	public static final String APPLICATION_JSON = "application/json";
	public static final int CODE_OK = 200;
	public static final int CODE_CREATED = 201;
	public static final int SC_CONFLICT = 409;
	public static final int CODE_ERROR = 500;
	public static final String ERROR = "errorTecnico";
	public static final String UNDEFINED = "0";

	/* CODIGOS SERVICIO CONSULTA DATOS BASICOS */
	public static final int CODE_NO_DATOS = 1001;
	public static final int CODE_O_NO_DATOS = 1002;
	public static final String CODIGO = "codigo";
	public static final int ACTUALIZACION = 0;

	/* REGISTRO LOGS */
	public static final String URL_INICIO = "URL_VISTA_INICIO";
	public static final String URL_BT_INGRESAR = "BT_INGRESAR";
	public static final String URL_BT_CONTINUAR = "BT_CONTINUAR";
	public static final String URL_PASO_1 = "Paso 1 Confirma tu informaci�n";
	public static final String URL_PASO_2 = "Paso 2 Confirma tu informaci�n";
	public static final String PROXIMOS_PASOS = "Proximos pasos";
	public static final String BT_VOLVER_PASO_1 = "BT_VOLVER_PASO_1";
	public static final String REGRESAR_PASO_1 = "Regresar al paso 1";
	public static final String BT_SALIR = "BT_SALIR";
	public static final String BT_FINALIZAR = "BT_FINALIZAR";
	public static final String FN_TRANSACCION = "FIN_TRANSACCION";
	public static final String URL_LISTA_RDM = "URL_LISTA_RDM";
	public static final String URL_ACTUALIZA_DATOS = "URL_ACTUALIZA_DATOS";
	public static final String URL_INTERACCION_AUTOMATICA = "URL_INTERACCION_AUTOMATICA";
	public static final String LST_DEPARTAMENTO = "LST_DEPARTAMENTO";
	public static final String LST_CIUDAD = "LST_CIUDAD";
	public static final String TIPO_CONSULTA = "tipoConsulta";
	public static final String LST_DEPARTAMENTO_CIUDAD = "LST_DEPARTAMENTO_CIUDAD";
	public static final String INICIO_NOTF_CCM = "NOTIFICACION_CCM";
	public static final String ZP_ADM_HOME_SESSION = "ZP_ADM_HOME_SESSION";
	public static final String APLICACION = "ZP_ACT";
	public static final String IP_USUARIO = "ipUsuario";
	public static final String USUARIO_ID = "PORTAL_PORVENIR";
	public static final String NOMBRE_PAGINA = "ACTUALIZACION_DATOS_ZONA_PUBLICA";
	public static final String PASO_1 = "Paso 1 Actualiza tu informacion";
	public static final String INICIO_TRANSACCION = "INICIO_TRANSACCION";
	public static final String NOTIFICACION_CCM = "NOTIFICACION_CCM";
	public static final String RQ_UID = "rqUID";
	public static final String CLIENT_DT = "clientDT";
	public static final String CHANNEL_ID = "ZTA";
	public static final String URL_PAGINA = "urlPagina";
	public static final String COMPONENTE_ID = "componenteId";
	public static final String CLIC_URL_ZTA = "CLIC_URL_ZTA";
	public static final String CLIC_URL_CANALES_DIGITALES = "CLIC_URL_CANALES_DIGITALES";
	public static final String CLIC_URL_PORVENIR_PREFERENCIAL = "CLIC_URL_PORVENIR_PREFERENCIAL";
	public static final String URL_BT_CONTINUAR_INTERACCION = "BT_CONTINUAR_INTERACCION_AUTOMATICA";

	/* CONSTANTES SERVICIO RDM */
	public static final String NUM_CONSULTA_DEPARTAMENTOS = "1";
	public static final String NUM_CONSULTA_CIUDADES = "2";
	public static final String NUM_CONSULTA_CYD = "3";
	public static final String LISTA_RDM = "listaRDM";

	/* CONSTANTES ACTUALIZA DATOS */
	public static final String BARRIO_RESIDENCIA = "barrioResidencia";
	public static final String CELULAR = "celular";
	public static final String CIUDAD_RESIDENCIA = "ciudadResidencia";
	public static final String DEPARTAMENTO_RESIDENCIA = "departamentoResidencia";
	public static final String DIRECCION_RESIDENCIA = "direccionResidencia";
	public static final String INDICATIVO_TELEFONO_FIJO = "indicativoTelefonoFijo";
	public static final String NUM_ID_AFILIADO = "numIdAfiliado";
	public static final String TELEFONO_FIJO = "telefonoFijo";
	public static final String TELEFONO_FIJO_SIEBEL = "numero";
	public static final String TELEFONO = "telefono";
	public static final String TIPO_ID_AFILIADO = "tipoIdAfiliado";

	/* CONSTANTES PROXIMOS PASOS */
	public static final String URL_EXIT = "/c/portal/logout";
	public static final String HOME = "home";

	/* Contantes filtro Siebel */
	public static final String ABREVIATURA_CRM = "abreviaturaCRM";
	public static final String ID_SIEBEL = "idSiebel";
	public static final String ID_TELEFONOS = "idTelefonos";
	public static final String ID_CORREOS = "idCorreos";
	public static final String ID_DIRECCIONES = "idDirecciones";
	public static final String CORREOS = "correos";
	public static final String TELEFONOS = "telefonos";
	public static final String TELEFONO_CONTACTO = "telefonoContacto";
		
	/* CONSTANTES SIEBEL */
	public static final String REGISTRO_CELULAR_SIEBEL = "REGISTRO_CELULAR_SIEBEL";
	public static final String REGISTRO_TELEFONO_FIJO_SIEBEL = "REGISTRO_TELEFONO_FIJO_SIEBEL";
	public static final String REGISTRO_PRINCIPAL = "registroPrincipal";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String DIRECCIONES = "direcciones";
	public static final String DIRECCION_SIEBEL = "DIRECCION_SIEBEL";
	public static final String TIPO_TELEFONO = "tipo";
	public static final String TIPO_TELEFONO_CELULAR = "1100009";
	public static final String TIPO_TELEFONO_FIJO = "1100004";
	public static final String ID_AFILIADO_CONSULTA = "id";
	public static final String ID_AFILIADO_ACT = "idAfiliado";
	public static final String UID_AFILIADO = "uidAfiliado";
	public static final String NUMERO_IDENTIFICACION = "numeroIdentificacion";
	public static final String CORREO_SIEBEL = "CORREO_SIEBEL";
	public static final String FORMATO_FECHA_SIEBEL = "MM/dd/yyyy";
	public static final String FORMATO_FECHA_ACT = "dd/MM/yyyy";
	
	/* CONSTANTES SIEBEL ACTUALIZAR DATOS */	
	public static final String DIRRECION_ACT = "direccion";
	public static final String DIRRECION_ALTERNA_ACT = "direccionAlterna";
	public static final String FECHA_INICIO_ACT = "fechaInicio";
	public static final String MEDIO_ACT = "medio";
	public static final String EMAIL_ACT = "Email";
	public static final String TIPO_ACT = "tipo";
	public static final String EMAIL_TIPO = "1200008";
	public static final String CORREOS_VENCIMIENTO = "correosVencimiento";
	public static final String ESTADO_ACT = "estado";
	public static final String CORREOS_A_ACT = "correos";
	public static final String DIRECCIONES_VENCIMIENTO_ACT = "direccionesVencimiento";
	public static final String ID_ACT = "id";
	public static final String BARRIO_ACT = "barrio";
	public static final String CODIGO_PAIS_ACT = "codigoPais";
	public static final String CODIGO_PAIS_COLOMBIA = "1000037";
	public static final String COMPLEMENTO_ACT = "complemento";
	public static final String INDICACIONES_ACT = "indicaciones";
	public static final String DIRECCION_TIPO = "1000002";
	public static final String USO_ACT = "uso";
	public static final String TELEFONOS_VENCIMIENTO_ACT = "telefonosVencimiento";
	public static final String INDICATIVO_COLOMBIA = "57";
	public static final String CODIGO_TIPO_ACT = "codigoTipo";
	public static final String NUMERO_ACT = "numero";
	
	public static final String INTERACCION_INICIO= "Se Registro: ";
	public static final String INTERACCION_CORREO = "correo";
	public static final String INTERACCION_CELULAR = "celular";
	public static final String INTERACCION_DIRECCION = "direcci�n";
	public static final String INTERACCION_TELEFONO = "tel�fono";
	public static final String INTERACCION_MENSAJE = "INTERACCION_MENSAJE";
	public static final String UID_INTERACCION = "uid";
	public static final String COMENTARIO_INTERACCION = "comentario";
	
	public static final String MODAL_NO_DATA = "/modal-no-tenemos-datos.jsp";
	public static final String MODAL_ACT_DATOS = "/actualizacion-datos.jsp";

	/* Constantes de error */
	public static final String ERROR_DATOS_BASICOS = "Error al consumir servicio datos basicos: ";
	public static final String ERROR_CREAR_REQUEST_ACTUALIZAR = "Error al generar request para Actualizar Datos";
	
}
