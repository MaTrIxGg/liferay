package zp.actualizacion.datos.onclic.api.api;

import com.liferay.portal.kernel.json.JSONObject;

import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;

/**
 * @author POR12989
 */
public interface ZpActualizacionDatosOnclicApi {
	public String capturarParametro(PortletRequest request, String nombreParametro);

	public void inicializarParametro(PortletRequest request, String nombreParametro, String parametro);

	public JSONObject consultaDatosBasicos(PortletRequest portletRequest, PortletResponse portletResponse);

	public JSONObject generarParametrosLogTransaccional(PortletRequest request, String tipoIdentificacion,
			String numeroIdentificacion, String urlPagina, String componenteId, Date fechaEvento);

	public JSONObject listaRDM(PortletRequest portletRequest, PortletResponse portletResponse, String tipoConsulta,
			String idDepartamento, String idCiudad);

	public void registroIniciotransaccion(PortletRequest request, PortletResponse response);

	public JSONObject actualizaDatos(PortletRequest request, PortletResponse response, String barrio, String celular,
			String ciudadResidencia, String correoElectronico, String departamento, String direccion,
			String indicativoTelefono, String telefonoFijo, boolean notificacionCCM, String correoActual,
			String celularActual);
	
	public JSONObject crearRequestInteraccionAutomatica(PortletRequest request);

	public void guardarParametrosLog(PortletRequest request, String tipoIdUsuario, String numeroIdentificacion,
			String urlPagina, String componente, String navegador, String servicioConsumido, String parametrosConsumo,
			String parametrosSalida, Date dateConsumoServicio, String codigo);

	public void logOutAction(ActionRequest actionRequest, ActionResponse actionResponse, String url);

}