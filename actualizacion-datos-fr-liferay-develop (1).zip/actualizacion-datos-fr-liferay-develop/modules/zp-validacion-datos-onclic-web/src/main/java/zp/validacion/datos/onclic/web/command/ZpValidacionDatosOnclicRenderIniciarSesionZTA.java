package zp.validacion.datos.onclic.web.command;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, "mvc.command.name="
				+ ZpValidacionDatosOnclicWebPortletKeys.RENDER_INICIAR_SESION_ZTA }, service = MVCRenderCommand.class)

public class ZpValidacionDatosOnclicRenderIniciarSesionZTA implements MVCRenderCommand {

	@Reference
	ZpValidacionDatosOnclicApi validacionDatosApi;
	@Reference
	DinamicDatalistApi dataListApi;

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		try {
			PortletSession session = renderRequest.getPortletSession();
			session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA).toString();
			session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString();

			String actDatos = dataListApi.getRecordValue(ZpValidacionDatosOnclicWebPortletKeys.LISTA_PROPIEDADES,
					ZpValidacionDatosOnClicApiKeys.URL_ACTUALIZACION_DATOS);
			renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.URL_ACTUALIZACION_DATOS, actDatos);
			return "/validacion-iniciar-sesion-zta.jsp";
		} catch (Exception e) {
			return "/validacion-lugar-residencia.jsp";
		}

	}
}
