package zp.validacion.datos.onclic.web.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletPreferencesFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.portlet.PortletPreferences;
import javax.portlet.PortletSession;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, "mvc.command.name="
				+ ZpValidacionDatosOnclicWebPortletKeys.RESOURCE_VALIDAR_MEDIO_OTP }, service = MVCResourceCommand.class)

public class ZpValidacionDatosOnclicResourceValidarOTP extends BaseMVCResourceCommand {

	@Reference
	ZpValidacionDatosOnclicApi zpValidacionApi;
	private static Log log = LogFactoryUtil.getLog(ZpValidacionDatosOnclicResourceSeleccionOTP.class);

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException {
		String codigo = null;
		PortletSession session = resourceRequest.getPortletSession();
		
		try {
			String tipoDocumento = session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString();
			String numeroDocumento = session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString();
			String numeroFormato = session.getAttribute(ZpValidacionDatosOnclicWebPortletKeys.NUMBER_FORMAT).toString();
			String fechaExpedicion = session.getAttribute(ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION).toString();
			String numeroCelular = session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_CELULAR).toString();
			String correoElectronico = session.getAttribute(ZpValidacionDatosOnClicApiKeys.CORREO_ELECTRONICO)
					.toString();
			String otp = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.CODE_OTP);
			String descripcionAuth = session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_OTP).toString();
			String datoAuth = session.getAttribute(ZpValidacionDatosOnClicApiKeys.DATO_AUTH).toString();
			String seleccionResidencia = session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA)
					.toString();
			Boolean flujoOtp = (Boolean) session.getAttribute(ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_FLUJO_OTP);
			
			if (!flujoOtp) {
				String jwt = zpValidacionApi.generarJWT(resourceRequest);
				zpValidacionApi.autenticacionLiferay(resourceRequest, resourceResponse);
				zpValidacionApi.guardarDatosLogin(resourceRequest, tipoDocumento, numeroDocumento, numeroFormato,
						fechaExpedicion, numeroCelular, correoElectronico, jwt,
						ZpValidacionDatosOnClicApiKeys.SESION_ONBOARDING, descripcionAuth, datoAuth,
						seleccionResidencia);
				codigo = ZpValidacionDatosOnClicApiKeys.CODE_OK;
			} else {
				JSONObject response = zpValidacionApi.validarOTP(resourceRequest, resourceResponse, otp);
				codigo = response.getString(ZpValidacionDatosOnClicApiKeys.CODE);

				if (codigo.equals(ZpValidacionDatosOnClicApiKeys.CODE_OK)) {
					String jwt = session.getAttribute(ZpValidacionDatosOnClicApiKeys.JWT).toString();
					zpValidacionApi.autenticacionLiferay(resourceRequest, resourceResponse);
					zpValidacionApi.guardarDatosLogin(resourceRequest, tipoDocumento, numeroDocumento, numeroFormato,
							fechaExpedicion, numeroCelular, correoElectronico, jwt,
							ZpValidacionDatosOnClicApiKeys.SESION_ONBOARDING, descripcionAuth, datoAuth,
							seleccionResidencia);
				}
			}
		} catch (Exception e) {
			log.error("Error guardando variable de seleccion de OTP: ", e);
		}
		JSONObject respuestaService = JSONFactoryUtil.createJSONObject();
		respuestaService.put(ZpValidacionDatosOnClicApiKeys.CODE, codigo);

		byte[] imgBytes = respuestaService.toJSONString().getBytes();
		ByteArrayInputStream inStream = new ByteArrayInputStream(imgBytes);

		resourceResponse.setCharacterEncoding(ZpValidacionDatosOnclicWebPortletKeys.UTF_8);
		resourceResponse.setContentType(ZpValidacionDatosOnclicWebPortletKeys.APPLICATION_JSON);
		PortletResponseUtil.sendFile(resourceRequest, resourceResponse, "", inStream);
	}
}