package zp.validacion.datos.onclic.web.command;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, "mvc.command.name="
				+ ZpValidacionDatosOnclicWebPortletKeys.RENDER_VALIDACION_RESIDENCIA }, service = MVCRenderCommand.class)
public class ZpValidacionDatosOnclicRenderLugarResidencia implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		return "/validacion-lugar-residencia.jsp";
	}
}