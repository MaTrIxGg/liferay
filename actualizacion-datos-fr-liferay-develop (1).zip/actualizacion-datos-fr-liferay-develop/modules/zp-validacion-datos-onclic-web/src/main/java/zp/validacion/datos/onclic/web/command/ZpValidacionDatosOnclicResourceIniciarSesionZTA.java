package zp.validacion.datos.onclic.web.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.ByteArrayInputStream;

import javax.portlet.PortletSession;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, "mvc.command.name="
				+ ZpValidacionDatosOnclicWebPortletKeys.RESOURCE_INICIAR_SESION_ZTA }, service = MVCResourceCommand.class)
public class ZpValidacionDatosOnclicResourceIniciarSesionZTA extends BaseMVCResourceCommand {

	private static Log log = LogFactoryUtil.getLog(ZpValidacionDatosOnclicResourceIniciarSesionZTA.class);

	@Reference
	private ZpValidacionDatosOnclicApi zpValidacionApi;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {
		PortletSession session = resourceRequest.getPortletSession();

		try {
			String tipoDocumento = session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO).toString();
			String numeroDocumento = session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_DOCUMENTO).toString();
			String numeroFormato = session.getAttribute(ZpValidacionDatosOnclicWebPortletKeys.NUMBER_FORMAT).toString();
			String fechaExpedicion = session.getAttribute(ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION).toString();
			String numeroCelular = session.getAttribute(ZpValidacionDatosOnClicApiKeys.NUMERO_CELULAR).toString();
			String correoElectronico = session.getAttribute(ZpValidacionDatosOnClicApiKeys.CORREO_ELECTRONICO)
					.toString();
			String seleccionResidencia = session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA)
					.toString();
			String pswd = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.PSWD_ZTA,
					StringPool.BLANK);

			JSONObject respuestaService = zpValidacionApi.validarContrase�aZTA(resourceRequest, resourceResponse, pswd);

			String codigo = respuestaService.getString(ZpValidacionDatosOnClicApiKeys.CODE);
			String descripcion = respuestaService.getString(ZpValidacionDatosOnClicApiKeys.DESCRIPCION);

			if (codigo.equals(ZpValidacionDatosOnClicApiKeys.CODE_U)
					&& descripcion.equals(ZpValidacionDatosOnClicApiKeys.DES_AUTE_EXITOSA)) {
				String jwt = session.getAttribute(ZpValidacionDatosOnClicApiKeys.JWT).toString();
				zpValidacionApi.autenticacionLiferay(resourceRequest, resourceResponse);
				zpValidacionApi.guardarDatosLogin(resourceRequest, tipoDocumento, numeroDocumento, numeroFormato,
						fechaExpedicion, numeroCelular, correoElectronico, jwt,
						ZpValidacionDatosOnClicApiKeys.SESION_ZTA, ZpValidacionDatosOnClicApiKeys.SESION_ZTA,
						StringPool.BLANK, seleccionResidencia);
			}
			respuestaService.put(ZpValidacionDatosOnClicApiKeys.CODE, codigo);
			respuestaService.put(ZpValidacionDatosOnClicApiKeys.DESCRIPCION, descripcion);

			byte[] resBytes = respuestaService.toJSONString().getBytes();
			ByteArrayInputStream inStream = new ByteArrayInputStream(resBytes);

			resourceResponse.setCharacterEncoding(ZpValidacionDatosOnclicWebPortletKeys.UTF_8);
			resourceResponse.setContentType(ZpValidacionDatosOnclicWebPortletKeys.APPLICATION_JSON);
			PortletResponseUtil.sendFile(resourceRequest, resourceResponse, "", inStream);

		} catch (Exception e) {
			log.error("Error iniciando sesi�n ZTA: ", e);
		}
	}
}