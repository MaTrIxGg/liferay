package zp.validacion.datos.onclic.web.command;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, "mvc.command.name="
				+ ZpValidacionDatosOnclicWebPortletKeys.RENDER_INGRESAR_OTP }, service = MVCRenderCommand.class)

public class ZpValidacionDatosOnclicRenderIngresarOTP implements MVCRenderCommand {

	@Reference
	private ZpValidacionDatosOnclicApi zpValidacionApi;
	
	@Reference
	private DinamicDatalistApi dinamicDataList;

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		PortletSession session = renderRequest.getPortletSession();
		session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA);
		session.getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO);
		String dato = null;
		String datoDescripcion = null;
		try {
			String actDatos = dinamicDataList.getRecordValue(ZpValidacionDatosOnclicWebPortletKeys.LISTA_PROPIEDADES,
					ZpValidacionDatosOnClicApiKeys.URL_ACTUALIZACION_DATOS);
			renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.URL_ACTUALIZACION_DATOS, actDatos);
			String seleccionOTP = session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_OTP).toString();
			String correoValidacion = session.getAttribute(ZpValidacionDatosOnClicApiKeys.CORREO_VALIDACION).toString();
			String celularValidacion = session.getAttribute(ZpValidacionDatosOnClicApiKeys.CELULAR_VALIDACION)
					.toString();
			String tiempoLabel = dinamicDataList.getRecordValue(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
					ZpValidacionDatosOnClicApiKeys.TIEMPO_LABEL_OTP);
			if (seleccionOTP.equals(ZpValidacionDatosOnClicApiKeys.CELULAR_OTP)) {
				session.setAttribute(ZpValidacionDatosOnClicApiKeys.DATO_AUTH, celularValidacion);
				dato = zpValidacionApi.enmascararDato(celularValidacion);
				datoDescripcion = ZpValidacionDatosOnClicApiKeys.CELULAR_OTP;
			} else if (seleccionOTP.equals(ZpValidacionDatosOnClicApiKeys.CORREO_OTP)) {
				session.setAttribute(ZpValidacionDatosOnClicApiKeys.DATO_AUTH, correoValidacion);
				dato = zpValidacionApi.enmascararDato(correoValidacion);
				datoDescripcion = ZpValidacionDatosOnClicApiKeys.CORREO_OTP;
			}

			renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.DATO, dato);
			renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.DESCRIPCION_DATO, datoDescripcion);
			renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.TIME_LABEL_OTP, tiempoLabel);
			return "/validacion-ingresar-otp.jsp";
		} catch (Exception e) {
			return "/validacion-lugar-residencia.jsp";
		}

	}

}
