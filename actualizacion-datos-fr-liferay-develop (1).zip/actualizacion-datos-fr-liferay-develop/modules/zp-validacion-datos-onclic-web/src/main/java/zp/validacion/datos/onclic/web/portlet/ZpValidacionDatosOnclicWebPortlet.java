package zp.validacion.datos.onclic.web.portlet;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletPreferencesFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;

import java.io.IOException;
import java.util.ResourceBundle;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

/**
 * @author POR12989
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=Porvenir",
		"com.liferay.portlet.instanceable=true", "javax.portlet.display-name=ZpValidacionDatosOnclicWeb",
		"javax.portlet.init-param.template-path=/", "javax.portlet.init-param.view-template=/validacion-login.jsp",
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class ZpValidacionDatosOnclicWebPortlet extends MVCPortlet {
	
	private static Log log = LogFactoryUtil.getLog(ZpValidacionDatosOnclicWebPortlet.class);

	@SuppressWarnings("unused")
	private static ResourceBundle rb = ResourceBundle.getBundle("content.Language");

	@Reference
	private DinamicDatalistApi dynamicDataList;

	@Reference
	private ZpValidacionDatosOnclicApi zpValidacionApi;

	@Override
	public void doView(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		
		Boolean flujoOtp = true;
		PortletPreferences portletPreferences;
		try {
			portletPreferences = PortletPreferencesFactoryUtil.getPortletSetup(renderRequest);
			PortletSession session = renderRequest.getPortletSession();
			String flujoOTPAux = portletPreferences.getValue(ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_FLUJO_OTP,
					StringPool.BLANK);
			
			if(flujoOTPAux.equals(ZpValidacionDatosOnclicWebPortletKeys.NO_VALOR)){
				flujoOtp=false;
			}
			
			session.setAttribute(ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_FLUJO_OTP, flujoOtp);
			
		} catch (PortalException e) {
			log.error("Error guardando variable de seleccion de OTP: ", e);
		}

		renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.OPCIONES_ID,
				dynamicDataList.getRecordValue(ZpValidacionDatosOnclicWebPortletKeys.LISTA_TIPOS_IDENTIFICACION,
						ZpValidacionDatosOnclicWebPortletKeys.TIPOS_IDENTIFICACION_VALIDACION_DATOS_ON_CLIC));
		renderRequest.setAttribute(ZpValidacionDatosOnclicWebPortletKeys.APIKEY,
				dynamicDataList.getRecordValue(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES_GLOBAL,
						ZpValidacionDatosOnclicWebPortletKeys.PARAMETRO_GOOGLE_API_PUBLIC));
		renderRequest.setAttribute(ZpValidacionDatosOnclicWebPortletKeys.URL_RECAPTCHA_GOOGLE,
				dynamicDataList.getRecordValue(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
						ZpValidacionDatosOnclicWebPortletKeys.URL_RECAPTCHA_GOOGLE));
		super.doView(renderRequest, renderResponse);
	}
}