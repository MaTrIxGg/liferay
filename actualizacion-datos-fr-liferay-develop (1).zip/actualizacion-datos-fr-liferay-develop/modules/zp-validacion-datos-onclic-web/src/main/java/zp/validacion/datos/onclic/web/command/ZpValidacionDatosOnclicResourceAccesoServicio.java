package zp.validacion.datos.onclic.web.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletResponseUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import co.com.porvenir.portal.util.api.UtilApi;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, "mvc.command.name="
				+ ZpValidacionDatosOnclicWebPortletKeys.RESOURCE_ACCESO_AL_SERVICIO }, service = MVCResourceCommand.class)

public class ZpValidacionDatosOnclicResourceAccesoServicio extends BaseMVCResourceCommand {

	@Reference
	private ZpValidacionDatosOnclicApi zpValidacionApi;

	@Reference
	private DinamicDatalistApi dataListApi;

	@Reference
	private UtilApi utilApi;

	private static Log log = LogFactoryUtil.getLog(ZpValidacionDatosOnclicResourceAccesoServicio.class);

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws ParseException, PortletException, IOException {
		String tipoDocumento = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.TYPE,
				StringPool.BLANK);
		String numeroDocumento = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.IDENTIFICACION_N);
		String numeroFormato = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.IDENTIFICACION_F);
		String fechaExpedicion = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.FECHA_EXPEDICION,
				StringPool.BLANK);
		String numeroCelular = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.NUM_CELULAR,
				StringPool.BLANK);
		String correoElectronico = ParamUtil.getString(resourceRequest,
				ZpValidacionDatosOnClicApiKeys.CORREO_ELECTRONICO, StringPool.BLANK);	
		
		
		
		JSONObject response = JSONFactoryUtil.createJSONObject();

		try {
			String isCaptchaActive = resourceRequest.getPreferences().getValue(
					ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_GRECAPTCHA_ACTIVE,
					ZpValidacionDatosOnclicWebPortletKeys.SI_VALOR);

			if (ZpValidacionDatosOnclicWebPortletKeys.SI_VALOR.equals(isCaptchaActive)) {
				String secret = dataListApi.getRecordValue(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES,
						ZpValidacionDatosOnclicWebPortletKeys.PARAMETRO_GOOGLE_API_SECRET);
				String gRecaptchaResponse = ParamUtil.getString(resourceRequest,
						ZpValidacionDatosOnclicWebPortletKeys.GRECAPTCHA, StringPool.BLANK);

				if (!utilApi.checkCaptcha(gRecaptchaResponse, secret)) {
					throw new PortletException(ZpValidacionDatosOnclicWebPortletKeys.ERROR_VALIDAR_RECAPTCHA_LOG);
				}
			}

			String fechaFormateadaServicio;
			SimpleDateFormat format = new SimpleDateFormat(ZpValidacionDatosOnclicWebPortletKeys.DATE_PICKER_FORMAT);
			Date fechaFormateada = format.parse(fechaExpedicion);
			format.applyPattern(ZpValidacionDatosOnclicWebPortletKeys.SERVICE_FORMAT);
			fechaFormateadaServicio = format.format(fechaFormateada);
			zpValidacionApi.guardarDatosPortletSession(resourceRequest, tipoDocumento, numeroDocumento,
					String.valueOf(fechaFormateadaServicio), numeroCelular, correoElectronico);
			PortletSession session = resourceRequest.getPortletSession();
			session.setAttribute(ZpValidacionDatosOnclicWebPortletKeys.NUMBER_FORMAT, numeroFormato,
					PortletSession.PORTLET_SCOPE);
			session.setAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA, ParamUtil
					.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA, StringPool.BLANK));

			zpValidacionApi.capturarSeleccion(resourceRequest, ParamUtil.getString(resourceRequest,
					ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA, StringPool.BLANK));

			JSONObject respuestaService = zpValidacionApi.validacionAcceso(resourceRequest, false);

			session.setAttribute(ZpValidacionDatosOnClicApiKeys.CORREO_OTP, StringPool.BLANK);
			session.setAttribute(ZpValidacionDatosOnClicApiKeys.CELULAR_OTP, StringPool.BLANK);
			String codigo = respuestaService.getString(ZpValidacionDatosOnClicApiKeys.CODE);
			String descripcion = respuestaService.getString(ZpValidacionDatosOnClicApiKeys.DESCRIPCION);
			response.put(ZpValidacionDatosOnClicApiKeys.CODE, codigo);
			response.put(ZpValidacionDatosOnClicApiKeys.DESCRIPCION, descripcion);
			response.put(ZpValidacionDatosOnClicApiKeys.CELULAR, zpValidacionApi.enmascararDato(numeroCelular));
			response.put(ZpValidacionDatosOnClicApiKeys.CORREO, zpValidacionApi.enmascararDato(correoElectronico));
		} catch (Exception e) {
			response.put(ZpValidacionDatosOnClicApiKeys.CODE, ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO);
			log.error(ZpValidacionDatosOnclicWebPortletKeys.ERROR_PORTLET_EVENT, e);
		}

		byte[] resBytes = response.toJSONString().getBytes();
		ByteArrayInputStream inStream = new ByteArrayInputStream(resBytes);
		resourceResponse.setCharacterEncoding(ZpValidacionDatosOnclicWebPortletKeys.UTF_8);
		resourceResponse.setContentType(ZpValidacionDatosOnclicWebPortletKeys.APPLICATION_JSON);
		PortletResponseUtil.sendFile(resourceRequest, resourceResponse, "", inStream);
	}
}