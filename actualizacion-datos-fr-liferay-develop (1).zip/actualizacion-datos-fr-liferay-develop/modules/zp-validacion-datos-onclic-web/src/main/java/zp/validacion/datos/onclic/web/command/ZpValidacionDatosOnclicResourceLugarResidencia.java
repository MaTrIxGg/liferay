package zp.validacion.datos.onclic.web.command;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;

import javax.portlet.PortletSession;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, "mvc.command.name="
				+ ZpValidacionDatosOnclicWebPortletKeys.RESOURCE_LUGAR_RESIDENCIA }, service = MVCResourceCommand.class)
public class ZpValidacionDatosOnclicResourceLugarResidencia extends BaseMVCResourceCommand {

	private static Log log = LogFactoryUtil.getLog(ZpValidacionDatosOnclicResourceLugarResidencia.class);

	@Reference
	private ZpValidacionDatosOnclicApi zpValidacionApi;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException {
		String respuesta;
		try {
			String seleccion = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.SELECT_RESIDENCIA);
			zpValidacionApi.capturarSeleccion(resourceRequest, seleccion);

			PortletSession session = resourceRequest.getPortletSession();
			session.setAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA, seleccion);

			respuesta = ZpValidacionDatosOnClicApiKeys.SUCCESSFULL;
		} catch (Exception e) {
			log.error("Error guardando variable de lugar residencia en Login: ", e);
			respuesta = "Error";
		}
		JSONObject respuestaService = JSONFactoryUtil.createJSONObject();
		respuestaService.put(ZpValidacionDatosOnClicApiKeys.RESPUESTA, respuesta);

		resourceResponse.getWriter().append(respuestaService.toJSONString());
	}
}