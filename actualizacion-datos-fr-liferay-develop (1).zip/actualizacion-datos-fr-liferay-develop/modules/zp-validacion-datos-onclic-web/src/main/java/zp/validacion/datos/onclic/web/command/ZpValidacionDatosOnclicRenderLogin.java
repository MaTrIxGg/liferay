package zp.validacion.datos.onclic.web.command;

import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, "mvc.command.name="
				+ ZpValidacionDatosOnclicWebPortletKeys.RENDER_VALIDACION_LOGIN }, service = MVCRenderCommand.class)

public class ZpValidacionDatosOnclicRenderLogin implements MVCRenderCommand {
	
	@Reference
	private DinamicDatalistApi dinamicDataList;

	@Reference
	private ZpValidacionDatosOnclicApi zpValidacionApi;

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		try {
			PortletSession session = renderRequest.getPortletSession();
			session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA).toString();

			String typeIdList = dinamicDataList.getRecordValue(
					ZpValidacionDatosOnclicWebPortletKeys.LISTA_TIPOS_IDENTIFICACION,
					ZpValidacionDatosOnclicWebPortletKeys.TIPOS_IDENTIFICACION_VALIDACION_DATOS_ON_CLIC);
			renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.OPCIONES_ID, typeIdList);
			String apiKey = dinamicDataList.getRecordValue(ZpValidacionDatosOnClicApiKeys.LISTA_PROPIEDADES_GLOBAL,
					ZpValidacionDatosOnclicWebPortletKeys.PARAMETRO_GOOGLE_API_PUBLIC);

			boolean errorTecnico = false;

			JSONObject respuestaTC = zpValidacionApi.obtenerDocumentoTC(renderRequest);
			if (respuestaTC
					.getInt(ZpValidacionDatosOnClicApiKeys.CODE) == ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO) {
				errorTecnico = true;
			} else {
				String base64TC = respuestaTC.getString(ZpValidacionDatosOnClicApiKeys.BASE64);
				renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.BASE64TC, base64TC);
			}

			JSONObject respuestaHD = zpValidacionApi.obtenerDocumentoHD(renderRequest);
			if (respuestaTC
					.getInt(ZpValidacionDatosOnClicApiKeys.CODE) == ZpValidacionDatosOnClicApiKeys.CODE_ERROR_TECNICO) {
				errorTecnico = true;
			} else {
				String base64HD = respuestaHD.getString(ZpValidacionDatosOnClicApiKeys.BASE64);
				renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.BASE64HD, base64HD);
			}

			renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.ERROR_TECNICO_DESC, errorTecnico);
			renderRequest.setAttribute(ZpValidacionDatosOnclicWebPortletKeys.APIKEY, apiKey);
			renderRequest.setAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_VALIDACION,
					session.getAttribute(ZpValidacionDatosOnClicApiKeys.SELECCION_RESIDENCIA));
			return "/validacion-login.jsp";

		} catch (Exception e) {
			return "/validacion-lugar-residencia.jsp";
		}
	}
}
