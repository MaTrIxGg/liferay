package zp.validacion.datos.onclic.web.command;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnClicApiKeys;
import zp.validacion.datos.onclic.api.api.ZpValidacionDatosOnclicApi;
import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(
		immediate = true, 
		property = {
				"javax.portlet.name=" + ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB, 
				"mvc.command.name=" + ZpValidacionDatosOnclicWebPortletKeys.RENDER_SELECCION_TIPO_DOCUMENTO },
		service = MVCResourceCommand.class)
public class ZpValidacionDatosOnclicResourceTipoDocumento extends BaseMVCResourceCommand {

	@Reference
	private ZpValidacionDatosOnclicApi zpValidacionApi;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {

		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(resourceRequest));
		String documentTC = null;
		String documentHD = (String) httpReq.getSession().getAttribute(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_HD);
		String documentOption = ParamUtil.getString(resourceRequest, ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO);
		JSONObject serviceResponse = JSONFactoryUtil.createJSONObject();
		
		if (documentOption.equals(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_TC)) {
			
			if(documentTC != null && !documentTC.isEmpty()){
				 serviceResponse.put(ZpValidacionDatosOnClicApiKeys.BASE64, documentTC);
				 serviceResponse.put(ZpValidacionDatosOnClicApiKeys.CODE, ZpValidacionDatosOnClicApiKeys.CODE_OK);
			} else {
				 serviceResponse = zpValidacionApi.obtenerDocumentoTC(resourceRequest);
			}	

		} else if (documentOption.equals(ZpValidacionDatosOnClicApiKeys.TIPO_DOCUMENTO_SERVICIO_HD)) {
			
			if(documentHD != null && !documentHD.isEmpty()){
				serviceResponse.put(ZpValidacionDatosOnClicApiKeys.BASE64, documentHD);
				serviceResponse.put(ZpValidacionDatosOnClicApiKeys.CODE, ZpValidacionDatosOnClicApiKeys.CODE_OK);
			} else {
				serviceResponse = zpValidacionApi.obtenerDocumentoHD(resourceRequest);
			}
			
		}
		
		resourceResponse.getWriter().append(serviceResponse.toJSONString());

	}

}
