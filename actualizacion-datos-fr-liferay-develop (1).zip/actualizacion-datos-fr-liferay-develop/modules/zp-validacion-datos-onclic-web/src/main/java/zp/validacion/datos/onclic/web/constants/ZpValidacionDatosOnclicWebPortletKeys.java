package zp.validacion.datos.onclic.web.constants;

/**
 * @author POR12989
 */
public class ZpValidacionDatosOnclicWebPortletKeys {
	
	private ZpValidacionDatosOnclicWebPortletKeys() {
		super();
	}

	public static final String ZPVALIDACIONDATOSONCLICWEB = "zp_validacion_datos_onclic_web_ZpValidacionDatosOnclicWebPortlet";
	public static final String UTF_8 = "UTF-8";
	public static final String APPLICATION_JSON = "application/json";
	public static final String APIKEY = "apiKey";

	public static final String RENDER_VALIDACION_LOGIN = "/validacion/login/view";
	public static final String RENDER_VALIDACION_RESIDENCIA = "/validacion/lugar-residencia/view";
	public static final String RENDER_SELECCION_MEDIO_OTP = "/validacion/seleccion-medio-otp/view";
	public static final String RENDER_SELECCION_TIPO_DOCUMENTO = "/validacion/seleccion-tipo-documeto/view";

	public static final String RESOURCE_INICIAR_SESION_ZTA = "/validacion/iniciar-sesion-zta";
	public static final String RENDER_INICIAR_SESION_ZTA = "/validacion/login/iniciar-sesion-zta/view";

	public static final String RESOURCE_ACCESO_AL_SERVICIO = "/validacion/acceso-al-servicio";
	public static final String RESOURCE_ACCESO_AL_SERVICIO_ZTA = "/validacion/acceso-al-servicio-zta";
	public static final String RESOURCE_LUGAR_RESIDENCIA = "/validacion/lugar-residencia";
	public static final String RESOURCE_SELECCION_MEDIO_OTP = "/validacion/seleccion-medio-otp";
	public static final String RESOURCE_VALIDAR_MEDIO_OTP = "/validacion/validar-otp";

	public static final String RENDER_INGRESAR_OTP = "/validacion/ingresar-otp";

	public static final String PARAMETRO_GOOGLE_API_SECRET = "GOOGLE_API_SECRET";
	public static final String PARAMETRO_GOOGLE_API_PUBLIC = "GOOGLE_API_PUBLIC";
	public static final String URL_RECAPTCHA_GOOGLE = "URL_RECAPTCHA_GOOGLE";
	public static final String GRECAPTCHA = "gRecaptcha";
	public static final String SI_VALOR = "S";
	public static final String NO_VALOR = "N";
	public static final String PREFERENCE_GRECAPTCHA_ACTIVE = "PREFERENCE_GRECAPTCHA_ACTIVE";
	public static final String ERROR_VALIDAR_RECAPTCHA_LOG = "Fallo al validar Recaptcha";
	public static final String PREFERENCE_CARRUSEL_ACTIVE = "PREFERENCE_CARRUSEL_ACTIVE";
	public static final String PREFERENCE_FLUJO_OTP = "PREFERENCE_FLUJO_OTP";
	public static final String PREFERENCE_URL_SITIO_COLOMBIANO_EXTERIOR = "PREFERENCE_URL_SITIO_COLOMBIANO_EXTERIOR";

	public static final String LISTA_TIPOS_IDENTIFICACION = "ZPACTListaTiposIdentificacion";
	public static final String LISTA_PROPIEDADES = "ZPACTListaPropiedades";
	public static final String TIPOS_IDENTIFICACION_VALIDACION_DATOS_ON_CLIC = "TIPOS_IDENTIFICACION_VALIDACION_DATOS_ON_CLIC";

	public static final String PREFERENCE_JOURNAL_ARTICLE_ID = "PREFERENCE_JOURNAL_ARTICLE_ID";
	public static final String PREFERENCE_SITE_GROUPID = "PREFERENCE_SITE_GROUPID";
	public static final String PREFERENCE_DOMINIO_SITIO = "PREFERENCE_DOMINIO_SITIO";
	public static final String PREFERENCE_CARPETA_IMAGENES_ID = "PREFERENCE_CARPETA_IMAGENES_ID";

	public static final String PREFERENCE_URL_SITIO_PORVENIR = "PREFERENCE_URL_SITIO_PORVENIR";
	public static final String PREFERENCE_URL_SITIO_CLIC_PORVENIR = "PREFERENCE_URL_SITIO_CLIC_PORVENIR";

	public static final String DATE_PICKER_FORMAT = "dd/MM/yyyy";
	public static final String SERVICE_FORMAT = "yyyyMMdd";
	public static final String NUMBER_FORMAT = "numeroFormato";

	public static final String SESSION_LIFERAY = "LIFERAY_SESSION";
	public static final String ZP_ACT_DATOS_SESSION = "ZP_ACT_DATOS_SESSION";
	
	public static final String ERROR_PORTLET_EVENT = "Se ha presentado un error gestionando los eventos del portlet";
	
	public static final String TEXT_SI_AUTO_DATOS_PERSONALES = "TEXT_SI_AUTO_DATOS_PERSONALES";
	public static final String TEXT_NO_AUTO_DATOS_PERSONALES = "TEXT_NO_AUTO_DATOS_PERSONALES";
	public static final String TEXT_POR_FINALIDAD = "TEXT_POR_FINALIDAD";
	
	

}