package zp.validacion.datos.onclic.web.portlet.configuration;

import com.liferay.portal.kernel.portlet.ConfigurationAction;
import com.liferay.portal.kernel.portlet.DefaultConfigurationAction;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;

import zp.validacion.datos.onclic.web.constants.ZpValidacionDatosOnclicWebPortletKeys;

@Component(configurationPolicy = ConfigurationPolicy.OPTIONAL, immediate = true, property = { "javax.portlet.name="
		+ ZpValidacionDatosOnclicWebPortletKeys.ZPVALIDACIONDATOSONCLICWEB }, service = ConfigurationAction.class)
public class ZpValidacionDatosOnclicWebConfiguration extends DefaultConfigurationAction {

	@Override
	public void processAction(PortletConfig portletConfig, ActionRequest actionRequest, ActionResponse actionResponse)
			throws Exception {
		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_JOURNAL_ARTICLE_ID, ParamUtil
				.getString(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_JOURNAL_ARTICLE_ID));

		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_SITE_GROUPID,
				ParamUtil.getString(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_SITE_GROUPID));

		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_CARRUSEL_ACTIVE,
				ParamUtil.getString(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_CARRUSEL_ACTIVE));

		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_FLUJO_OTP,
				ParamUtil.getString(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_FLUJO_OTP));

		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_CARPETA_IMAGENES_ID, ParamUtil
				.getString(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_CARPETA_IMAGENES_ID));

		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_GRECAPTCHA_ACTIVE,
				ParamUtil.getString(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_GRECAPTCHA_ACTIVE));

		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_PORVENIR, ParamUtil
				.getString(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_PORVENIR));

		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_CLIC_PORVENIR, ParamUtil
				.getString(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_CLIC_PORVENIR));

		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_COLOMBIANO_EXTERIOR,
				ParamUtil.getString(actionRequest,
						ZpValidacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_COLOMBIANO_EXTERIOR));
		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.TEXT_SI_AUTO_DATOS_PERSONALES,
				ParamUtil.getString(actionRequest,
						ZpValidacionDatosOnclicWebPortletKeys.TEXT_SI_AUTO_DATOS_PERSONALES));
		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.TEXT_NO_AUTO_DATOS_PERSONALES,
				ParamUtil.getString(actionRequest,
						ZpValidacionDatosOnclicWebPortletKeys.TEXT_NO_AUTO_DATOS_PERSONALES));
		setPreference(actionRequest, ZpValidacionDatosOnclicWebPortletKeys.TEXT_POR_FINALIDAD,
				ParamUtil.getString(actionRequest,
						ZpValidacionDatosOnclicWebPortletKeys.TEXT_POR_FINALIDAD));

		super.processAction(portletConfig, actionRequest, actionResponse);
	}
}