package zp.actualizacion.datos.onclic.service;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.configuration.metatype.bnd.util.ConfigurableUtil;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.security.auth.session.AuthenticatedSessionManagerUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.servlet.http.HttpServletRequest;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import co.com.porvenir.portal.zte.rest.client.api.ZteRestClientApi;
import co.com.porvenir.portal.zte.rest.client.api.config.RestClientApiConfiguration;
import co.com.porvenir.portal.zte.rest.client.api.constant.ZteRestClientApiConstant;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApi;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApiKeys;

/**
 * @author POR12989
 */
@Component(immediate = true, property = {}, service = ZpActualizacionDatosOnclicApi.class)
public class ZpActualizacionDatosOnclicService implements ZpActualizacionDatosOnclicApi {

	@Reference
	private DinamicDatalistApi dataListApi;

	@Reference
	private ZteRestClientApi restApi;

	private String sesionId;

	private static Log log = LogFactoryUtil.getLog(ZpActualizacionDatosOnclicService.class);
	private String nitEmpresa = StringPool.BLANK;

	private static volatile RestClientApiConfiguration _restClientApiConfiguration;

	@Activate
	@Modified
	protected void activate(Map<String, Object> properties) {
		_restClientApiConfiguration = ConfigurableUtil.createConfigurable(RestClientApiConfiguration.class, properties);
	}

	@Override
	public String capturarParametro(PortletRequest request, String nombreParametro) {
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(request));
		String parametro = (String) httpReq.getSession().getAttribute(nombreParametro);
		if (parametro == null) {
			log.error("No se encuentra " + nombreParametro + " al inicializar el servicio");
		}
		return parametro;
	}

	private String obtenerIP(PortletRequest portletRequest) {
		HttpServletRequest httpReqA = PortalUtil.getHttpServletRequest(portletRequest);
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(httpReqA);
		String ip = httpReq.getHeader("X-FORWARDED-FOR");
		if (ip == null || StringPool.BLANK.equals(ip)) {
			ip = PortalUtil.getHttpServletRequest(portletRequest).getRemoteAddr();
			if (ip == null || StringPool.BLANK.equals(ip)) {
				ip = System.getProperty("myapplication.ip");
			}
		}
		if (ip.split(StringPool.COMMA).length > 1) {
			ip = ip.split(StringPool.COMMA)[1];
		} else {
			ip = ip.split(StringPool.COMMA)[0];
		}
		return ip.split(StringPool.COLON)[0];
	}

	@Override
	public void inicializarParametro(PortletRequest request, String nombreParametro, String parametro) {
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(request));
		if (nombreParametro != StringPool.BLANK) {
			httpReq.getSession().setAttribute(nombreParametro, parametro);
		} else {
			log.error("Error al inicializar un parametro vacio");
		}
	}

	public String obtenerParametroLista(String nombreLista, String nombreParametro) {
		String parametro = dataListApi.getRecordValue(nombreLista, nombreParametro);
		if (parametro == null || parametro.equals(StringPool.BLANK)) {
			log.error("No se encuentra " + nombreParametro + " en la lista dinamica.");
		}
		return parametro;
	}

	@Override
	public void guardarParametrosLog(PortletRequest request, String tipoIdUsuario, String numeroIdentificacion,
			String urlPagina, String componente, String navegador, String servicioConsumido, String parametrosConsumo,
			String parametrosSalida, Date dateConsumoServicio, String codigo) {

		Date fechaRespuestaServicio = null;
		String urlLog = dataListApi.getRecordValue(ZpActualizacionDatosOnclicApiKeys.LISTA_PROPIEDADES_GLOBAL,
				ZteRestClientApiConstant.URL_REST_LOGS);

		this.sesionId = request.getPortletSession().getId();

		try {
			JSONObject logsParams = restApi.createJSONParamLogs(ZpActualizacionDatosOnclicApiKeys.APLICACION, urlLog,
					ZpActualizacionDatosOnclicApiKeys.USUARIO_ID, tipoIdUsuario, numeroIdentificacion, nitEmpresa,
					ZpActualizacionDatosOnclicApiKeys.NOMBRE_PAGINA, urlPagina, componente, sesionId);

			Map<String, String> headers = new LinkedHashMap<>();
			JSONObject jsonHeader = JSONFactoryUtil.createJSONObject();

			jsonHeader.put(ZteRestClientApiConstant.IP_ADDR, obtenerIP(request));
			headers.put(ZteRestClientApiConstant.HEADER_RQU, jsonHeader.toJSONString());

			JSONObject jsonSalida = JSONFactoryUtil.createJSONObject();
			jsonSalida.put(ZteRestClientApiConstant.RESPUESTA, parametrosSalida);
			jsonSalida.put(ZteRestClientApiConstant.CODIGO, codigo);

			if (!Optional.ofNullable(dateConsumoServicio).isPresent()) {
				dateConsumoServicio = new Date();
			}

			fechaRespuestaServicio = new Date();

			restApi.callServiceLog(servicioConsumido, parametrosConsumo, headers, new LinkedHashMap<>(), logsParams,
					jsonSalida, dateConsumoServicio.getTime(), fechaRespuestaServicio.getTime(),
					Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

		} catch (Exception e) {
			log.error("Error registrando en logs: ", e);
		}
	}

	@Override
	public void logOutAction(ActionRequest actionRequest, ActionResponse actionResponse, String url) {
		HttpServletRequest httpReq = PortalUtil
				.getOriginalServletRequest(PortalUtil.getHttpServletRequest(actionRequest));
		try {
			actionRequest.getPortletSession().invalidate();
			AuthenticatedSessionManagerUtil.logout(httpReq, PortalUtil.getHttpServletResponse(actionResponse));
			actionRequest.setAttribute(WebKeys.LOGOUT, true);
			actionResponse.sendRedirect(url);
		} catch (Exception e) {
			log.error(e);
		}
	}

	@Override
	public JSONObject consultaDatosBasicos(PortletRequest portletRequest, PortletResponse portletResponse) {
		String urlService = obtenerParametroLista(ZpActualizacionDatosOnclicApiKeys.LISTA_PROPIEDADES,
				ZpActualizacionDatosOnclicApiKeys.URL_CONSULTA_DATOS_BASICOS);
		StringBuilder url = new StringBuilder();
		String tipoDoc = obtenerDatoFiltra(ZpActualizacionDatosOnclicApiKeys.LISTA_TIPOS_DOC_SIEBEL,
				capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO));
		url.append(urlService).append(StringPool.FORWARD_SLASH).append(tipoDoc).append(StringPool.FORWARD_SLASH)
				.append(capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO));

		this.sesionId = portletRequest.getPortletSession().getId();

		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject respuestaService = JSONFactoryUtil.createJSONObject();
		JSONObject callResponse = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
		parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO, tipoDoc);
		parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO,
				capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO));

		try {
			JSONObject headerLogTx = generarParametrosLogTransaccional(portletRequest,
					capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.PASO_1,
					ZpActualizacionDatosOnclicApiKeys.RENDER_ACTUALIZA_INFORMACION, new Date());

			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(portletRequest).toJSONString());
			headers.put(ZpActualizacionDatosOnclicApiKeys.HEADER_LOG_TX, headerLogTx.toJSONString());
			headers.put(ZteRestClientApiConstant.AUTHORIZATION,
					capturarParametro(portletRequest, ZteRestClientApiConstant.JWT));

			callResponse = restApi.callRestServiceByGet(url.toString(), headers, new LinkedHashMap<>(),
					parametrosPeticion, Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			if (callResponse.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_OK))) {

				String jwt = callResponse.getString(ZteRestClientApiConstant.JWT);
				inicializarParametro(portletRequest, ZteRestClientApiConstant.JWT, jwt);
				guardarParametrosLog(portletRequest,
						capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
						capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
						ZpActualizacionDatosOnclicApiKeys.PASO_1,
						ZpActualizacionDatosOnclicApiKeys.RENDER_ACTUALIZA_INFORMACION, StringPool.BLANK, urlService,
						parametrosPeticion.toJSONString(), callResponse.toString(), new Date(),
						callResponse.getString(ZteRestClientApiConstant.CODIGO));

				JSONObject respuesta = callResponse.getJSONObject(ZteRestClientApiConstant.RESPUESTA);
				JSONObject telefonos = gestionarTelefonosSiebel(portletRequest,
						respuesta.getJSONArray(ZpActualizacionDatosOnclicApiKeys.TELEFONOS));

				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.ID_AFILIADO_ACT,
						respuesta.getString(ZpActualizacionDatosOnclicApiKeys.ID_AFILIADO_CONSULTA));
				StringBuilder uIdAfiliado = new StringBuilder();
				uIdAfiliado.append(respuesta.getString(ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO))
						.append(respuesta.getString(ZpActualizacionDatosOnclicApiKeys.NUMERO_IDENTIFICACION));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.UID_AFILIADO,
						uIdAfiliado.toString());
				StringBuilder nombresCompletos = new StringBuilder();
				nombresCompletos.append(respuesta.getString(ZpActualizacionDatosOnclicApiKeys.PRIMERNOMBRE))
						.append(StringPool.SPACE)
						.append(respuesta.getString(ZpActualizacionDatosOnclicApiKeys.SEGUNDO_NOMBRE))
						.append(StringPool.SPACE)
						.append(respuesta.getString(ZpActualizacionDatosOnclicApiKeys.PRIMERAPELLIDO))
						.append(StringPool.SPACE)
						.append(respuesta.getString(ZpActualizacionDatosOnclicApiKeys.SEGUNDO_APELLIDO));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NOMBRES_COMPLETOS,
						nombresCompletos.toString());
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.PRIMERNOMBRE,
						respuesta.getString(ZpActualizacionDatosOnclicApiKeys.PRIMERNOMBRE));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.SEGUNDO_NOMBRE,
						respuesta.getString(ZpActualizacionDatosOnclicApiKeys.SEGUNDO_NOMBRE));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.PRIMERAPELLIDO,
						respuesta.getString(ZpActualizacionDatosOnclicApiKeys.PRIMERAPELLIDO));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.SEGUNDO_APELLIDO,
						respuesta.getString(ZpActualizacionDatosOnclicApiKeys.SEGUNDO_APELLIDO));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CELULAR_NOT,
						telefonos.getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO));

				SimpleDateFormat formatoEntrada = new SimpleDateFormat(
						ZpActualizacionDatosOnclicApiKeys.FORMATO_FECHA_SIEBEL);
				SimpleDateFormat formatoSalida = new SimpleDateFormat(
						ZpActualizacionDatosOnclicApiKeys.FORMATO_FECHA_ACT);
				String fechaNacimiento = StringPool.BLANK;

				if (respuesta.getString(ZpActualizacionDatosOnclicApiKeys.FECHA_DE_NACIMIENTO) != StringPool.BLANK) {
					Date fechaNacimientoSiebel = formatoEntrada
							.parse(respuesta.getString(ZpActualizacionDatosOnclicApiKeys.FECHA_DE_NACIMIENTO));
					fechaNacimiento = formatoSalida.format(fechaNacimientoSiebel);
				}

				String genero = getGenero(respuesta.getString(ZpActualizacionDatosOnclicApiKeys.GENERO));

				JSONObject correo = JSONFactoryUtil.createJSONObject();

				if (respuesta.getJSONArray(ZpActualizacionDatosOnclicApiKeys.CORREOS).length() != 0) {
					correo = respuesta.getJSONArray(ZpActualizacionDatosOnclicApiKeys.CORREOS).getJSONObject(0);
					inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CORREO_NOT,
							correo.getString(ZpActualizacionDatosOnclicApiKeys.DIRECCION));
					inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CORREO_SIEBEL,
							correo.toJSONString());
				}

				registroIniciotransaccion(portletRequest, portletResponse);

				JSONObject direccion = JSONFactoryUtil.createJSONObject();
				if (respuesta.getJSONArray(ZpActualizacionDatosOnclicApiKeys.DIRECCIONES).length() != 0) {
					direccion = respuesta.getJSONArray(ZpActualizacionDatosOnclicApiKeys.DIRECCIONES).getJSONObject(0);
					inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.DIRECCION_SIEBEL,
							direccion.toJSONString());

					if (!direccion.getString(ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO)
							.equals(StringPool.BLANK)
							&& !direccion.getString(ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD)
									.equals(StringPool.BLANK)) {
						inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO,
								direccion.getString(ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO));
						inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD,
								direccion.getString(ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD));
					} else {
						inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD,
								ZpActualizacionDatosOnclicApiKeys.UNDEFINED);
						inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO,
								ZpActualizacionDatosOnclicApiKeys.UNDEFINED);
					}
				} else {
					inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD,
							ZpActualizacionDatosOnclicApiKeys.UNDEFINED);
					inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO,
							ZpActualizacionDatosOnclicApiKeys.UNDEFINED);
				}

				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.NOMBRES_COMPLETOS, nombresCompletos.toString());
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.FECHA_NACIMIENTO, fechaNacimiento);
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.CORREO_ELECTRONICO,
						correo.getString(ZpActualizacionDatosOnclicApiKeys.DIRECCION));
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.DIRECCION,
						direccion.getString(ZpActualizacionDatosOnclicApiKeys.DIRECCION));
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.BARRIO_ACT,
						direccion.getString(ZpActualizacionDatosOnclicApiKeys.BARRIO_ACT));
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.GENERO, genero);
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.STATUS_CODE,
						ZpActualizacionDatosOnclicApiKeys.CODE_OK);
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO,
						telefonos.getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO));

				if (capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NOTIFICACION_CCM)
						.equals(ZpActualizacionDatosOnclicApiKeys.VALOR_NOTIF_SI)) {
					generarNotificacion(portletRequest, ZpActualizacionDatosOnclicApiKeys.VALOR_CARD_ID_INICIO,
							ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_INICIO,
							capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CELULAR_NOT),
							capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.CORREO_NOT));
					inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NOTIFICACION_CCM,
							ZpActualizacionDatosOnclicApiKeys.VALOR_NOTIF_NO);
				}
			} else if (callResponse.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpActualizacionDatosOnclicApiKeys.SC_CONFLICT))) {
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.STATUS_CODE,
						ZpActualizacionDatosOnclicApiKeys.CODE_O_NO_DATOS);
			} else {
				log.error(ZpActualizacionDatosOnclicApiKeys.ERROR_DATOS_BASICOS + url + StringPool.SPACE
						+ callResponse.toJSONString());
				guardarParametrosLog(portletRequest,
						capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
						capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
						ZpActualizacionDatosOnclicApiKeys.PASO_1,
						ZpActualizacionDatosOnclicApiKeys.RENDER_ACTUALIZA_INFORMACION, StringPool.BLANK, urlService,
						parametrosPeticion.toJSONString(), callResponse.toString(), new Date(),
						callResponse.getString(ZteRestClientApiConstant.CODIGO));
				respuestaService.put(ZpActualizacionDatosOnclicApiKeys.STATUS_CODE,
						ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error(ZpActualizacionDatosOnclicApiKeys.ERROR_DATOS_BASICOS, e);
			guardarParametrosLog(portletRequest,
					capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.PASO_1,
					ZpActualizacionDatosOnclicApiKeys.RENDER_ACTUALIZA_INFORMACION, StringPool.BLANK, urlService,
					parametrosPeticion.toJSONString(), callResponse.toString(), new Date(),
					callResponse.getString(ZteRestClientApiConstant.CODIGO));
			respuestaService.put(ZpActualizacionDatosOnclicApiKeys.STATUS_CODE,
					ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
		}
		return respuestaService;
	}

	@Override
	public JSONObject generarParametrosLogTransaccional(PortletRequest request, String tipoIdentificacion,
			String numeroIdentificacion, String urlPagina, String componenteId, Date fechaEvento) {
		JSONObject headerLogTx = JSONFactoryUtil.createJSONObject();
		this.sesionId = request.getPortletSession().getId();

		headerLogTx.put(ZteRestClientApiConstant.APLICATIVO, ZpActualizacionDatosOnclicApiKeys.APLICACION);
		headerLogTx.put(ZpActualizacionDatosOnclicApiKeys.IP_USUARIO, obtenerIP(request));
		headerLogTx.put(ZteRestClientApiConstant.USUARIO_ID, ZpActualizacionDatosOnclicApiKeys.USUARIO_ID);
		headerLogTx.put(ZteRestClientApiConstant.TIPO_ID_AFILIADO, tipoIdentificacion);
		headerLogTx.put(ZteRestClientApiConstant.NUMERO_IDENTIFICACION_AFILIADO, numeroIdentificacion);
		headerLogTx.put(ZteRestClientApiConstant.NIT_EMPRESA, StringPool.BLANK);
		headerLogTx.put(ZteRestClientApiConstant.NOMBRE_PAGINA, ZpActualizacionDatosOnclicApiKeys.NOMBRE_PAGINA);
		headerLogTx.put(ZteRestClientApiConstant.URL_PAGINA, urlPagina);
		headerLogTx.put(ZteRestClientApiConstant.COMPONENTE, componenteId);
		headerLogTx.put(ZteRestClientApiConstant.TRANSACCION, StringPool.BLANK);
		headerLogTx.put(ZteRestClientApiConstant.SESSION_ID, sesionId);
		headerLogTx.put(ZteRestClientApiConstant.NAVEGADOR, StringPool.BLANK);
		headerLogTx.put(ZteRestClientApiConstant.FECHA_EVENTO, fechaEvento.getTime());

		return headerLogTx;
	}

	private JSONObject generarHeaderRq(PortletRequest request) {
		JSONObject jsonHeader = JSONFactoryUtil.createJSONObject();

		String fechaRq = parseoFecha(ZpActualizacionDatosOnclicApiKeys.DATE_FORMAT_1);
		String fechaClientDt = parseoFecha(ZpActualizacionDatosOnclicApiKeys.DATE_FORMAT_2);

		jsonHeader.put(ZteRestClientApiConstant.RQUID, fechaRq + ZpActualizacionDatosOnclicApiKeys.NUMBER_FINAL);
		jsonHeader.put(ZteRestClientApiConstant.CHANNEL_ID, ZpActualizacionDatosOnclicApiKeys.CHANNEL_ID);
		jsonHeader.put(ZteRestClientApiConstant.CLIENT_ID, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.CLIENT_ID));
		jsonHeader.put(ZteRestClientApiConstant.CLIENT_NAME, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.CLIENT_NAME));
		jsonHeader.put(ZteRestClientApiConstant.SUCURSAL_ID, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.SUCURSAL_ID));
		jsonHeader.put(ZteRestClientApiConstant.SUCURSAL_NAME, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.SUCURSAL_NAME));
		jsonHeader.put(ZteRestClientApiConstant.IP_ADDR, obtenerIP(request));
		jsonHeader.put(ZteRestClientApiConstant.SESS_KEY, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.SESS_KEY));
		jsonHeader.put(ZteRestClientApiConstant.CLIENT_DT, fechaClientDt);
		jsonHeader.put(ZteRestClientApiConstant.USER_ID, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.USER_ID));
		jsonHeader.put(ZteRestClientApiConstant.LOGIN_ID, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.LOGIN_ID));
		jsonHeader.put(ZteRestClientApiConstant.REV_CODE, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.REV_CODE));
		jsonHeader.put(ZteRestClientApiConstant.REV_UID, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.REV_UID));
		jsonHeader.put(ZteRestClientApiConstant.REV_AUTH_ID, obtenerParametroLista(
				ZpActualizacionDatosOnclicApiKeys.LISTA_PARAMETROS_SERVICIOS, ZteRestClientApiConstant.REV_AUTH_ID));

		return jsonHeader;
	}

	private String parseoFecha(String formato) {
		SimpleDateFormat dateFor = new SimpleDateFormat(formato);
		dateFor.setTimeZone(TimeZone.getTimeZone(ZpActualizacionDatosOnclicApiKeys.DATE_FORMAT));
		return dateFor.format(new Date());
	}

	@Override
	public JSONObject listaRDM(PortletRequest portletRequest, PortletResponse portletResponse, String idDepartamento,
			String idCiudad, String tipoConsulta) {
		String urlService = obtenerParametroLista(ZpActualizacionDatosOnclicApiKeys.LISTA_PROPIEDADES,
				ZpActualizacionDatosOnclicApiKeys.URL_LISTA_RDM);

		StringBuilder url = new StringBuilder();
		url.append(urlService).append(StringPool.FORWARD_SLASH).append(idDepartamento).append(StringPool.FORWARD_SLASH)
				.append(idCiudad).append(StringPool.FORWARD_SLASH).append(tipoConsulta);

		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject respuestaService = JSONFactoryUtil.createJSONObject();
		JSONObject callResponse = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
		parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO, idDepartamento);
		parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD, idCiudad);
		parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.TIPO_CONSULTA, tipoConsulta);
		String componenteId = StringPool.BLANK;

		if (tipoConsulta.equals(ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_DEPARTAMENTOS)) {
			componenteId = ZpActualizacionDatosOnclicApiKeys.LST_DEPARTAMENTO;
		} else if (tipoConsulta.equals(ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_CIUDADES)) {
			componenteId = ZpActualizacionDatosOnclicApiKeys.LST_CIUDAD;
		} else if (tipoConsulta.equals(ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_CYD)) {
			componenteId = ZpActualizacionDatosOnclicApiKeys.LST_DEPARTAMENTO_CIUDAD;
		}

		try {
			JSONObject headerLogTx = generarParametrosLogTransaccional(portletRequest,
					capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.PASO_1, componenteId, new Date());

			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(portletRequest).toJSONString());
			headers.put(ZpActualizacionDatosOnclicApiKeys.HEADER_LOG_TX, headerLogTx.toJSONString());
			headers.put(ZteRestClientApiConstant.AUTHORIZATION,
					capturarParametro(portletRequest, ZteRestClientApiConstant.JWT));

			callResponse = restApi.callRestServiceByGet(url.toString(), headers, new LinkedHashMap<>(),
					parametrosPeticion, Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			if (!callResponse.getString(ZteRestClientApiConstant.CODIGO)
					.equals(String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_ERROR))) {
				String jwt = callResponse.getString(ZteRestClientApiConstant.JWT);
				inicializarParametro(portletRequest, ZteRestClientApiConstant.JWT, jwt);
				guardarParametrosLog(portletRequest,
						capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
						capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
						ZpActualizacionDatosOnclicApiKeys.PASO_1, componenteId, StringPool.BLANK, url.toString(),
						parametrosPeticion.toJSONString(), callResponse.toJSONString(), new Date(),
						callResponse.getString(ZteRestClientApiConstant.CODIGO));

				JSONObject respuesta = callResponse.getJSONObject(ZteRestClientApiConstant.RESPUESTA);
				if (tipoConsulta.equals(ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_DEPARTAMENTOS)) {
					respuestaService.put(ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTOS,
							respuesta.getJSONArray(ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTOS));
					respuestaService.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_OK);
				} else if (tipoConsulta.equals(ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_CIUDADES)) {
					respuestaService.put(ZpActualizacionDatosOnclicApiKeys.CIUDADES,
							respuesta.getJSONArray(ZpActualizacionDatosOnclicApiKeys.CIUDADES));
					respuestaService.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_OK);
				} else if (tipoConsulta.equals(ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_CYD)) {
					respuesta.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_OK);
					return respuesta;
				}
			} else {
				log.error("Error en el servicio para obtener lista de ciudades y departamentos " + url
						+ StringPool.SPACE + callResponse.toJSONString());
				guardarParametrosLog(portletRequest,
						capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
						capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
						ZpActualizacionDatosOnclicApiKeys.PASO_1, componenteId, StringPool.BLANK, url.toString(),
						parametrosPeticion.toJSONString(), callResponse.toJSONString(), new Date(),
						callResponse.getString(ZteRestClientApiConstant.CODIGO));
				respuestaService.put(ZteRestClientApiConstant.CODIGO,
						ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error al consumir servicio de lista de ciudades y departamentos: ", e);
			guardarParametrosLog(portletRequest,
					capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.PASO_1, componenteId, StringPool.BLANK, urlService,
					parametrosPeticion.toJSONString(), callResponse.toJSONString(), new Date(),
					callResponse.getString(ZteRestClientApiConstant.CODIGO));
			respuestaService.put(ZteRestClientApiConstant.CODIGO, ZteRestClientApiConstant.SC_INTERNAL_SERVER_ERROR);
		}
		return respuestaService;
	}

	@Override
	public void registroIniciotransaccion(PortletRequest request, PortletResponse response) {
		JSONObject parametrosSalida = JSONFactoryUtil.createJSONObject();
		parametrosSalida.put(ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO,
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO));
		parametrosSalida.put(ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO,
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO));
		parametrosSalida.put(ZpActualizacionDatosOnclicApiKeys.NOMBRES_COMPLETOS,
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NOMBRES_COMPLETOS));

		guardarParametrosLog(request, capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
				ZpActualizacionDatosOnclicApiKeys.INICIO_TRANSACCION,
				ZpActualizacionDatosOnclicApiKeys.INICIO_TRANSACCION, StringPool.BLANK,
				ZpActualizacionDatosOnclicApiKeys.INICIO_TRANSACCION, parametrosSalida.toJSONString(),
				"Inicio transaccion", new Date(), String.valueOf(ZteRestClientApiConstant.SC_OK));
	}

	@Override
	public JSONObject actualizaDatos(PortletRequest request, PortletResponse response, String barrio, String celular,
			String ciudadResidencia, String correoElectronico, String departamento, String direccion,
			String indicativoTelefono, String telefonoFijo, boolean notificacionCCM, String correoActual,
			String celularActual) {

		String url = obtenerParametroLista(ZpActualizacionDatosOnclicApiKeys.LISTA_PROPIEDADES,
				ZpActualizacionDatosOnclicApiKeys.URL_ACTUALIZA_DATOS);

		String celularNoti = capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.CELULAR_NOT);
		String emailNoti = capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.CORREO_NOT);

		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject headerLogTx = JSONFactoryUtil.createJSONObject();
		JSONObject callResponse = JSONFactoryUtil.createJSONObject();

		JSONObject parametrosPeticion = crearRequestActualizarDatos(request, barrio, celular, ciudadResidencia,
				correoElectronico, departamento, direccion, telefonoFijo);

		try {
			headerLogTx = generarParametrosLogTransaccional(request,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.URL_PASO_2, ZpActualizacionDatosOnclicApiKeys.URL_BT_CONTINUAR,
					new Date());
			JSONObject headerRqu = generarHeaderRq(request);
			headerRqu.remove(ZpActualizacionDatosOnclicApiKeys.RQ_UID);
			headerRqu.put(ZpActualizacionDatosOnclicApiKeys.RQ_UID,
					parseoFecha(ZpActualizacionDatosOnclicApiKeys.DATE_FORMAT_3));
			headers.put(ZteRestClientApiConstant.HEADER_RQU, headerRqu.toJSONString());
			headers.put(ZpActualizacionDatosOnclicApiKeys.HEADER_LOG_TX, headerLogTx.toJSONString());
			headers.put(ZteRestClientApiConstant.AUTHORIZATION,
					capturarParametro(request, ZteRestClientApiConstant.JWT));
			headers.put(ZpActualizacionDatosOnclicApiKeys.CONTENT_TYPE,
					ZpActualizacionDatosOnclicApiKeys.APPLICATION_JSON);

			callResponse = restApi.callRestServiceByPut(url, parametrosPeticion.toJSONString(), headers,
					new LinkedHashMap<>(), Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			guardarParametrosLog(request, capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.URL_PASO_2, ZpActualizacionDatosOnclicApiKeys.URL_BT_CONTINUAR,
					StringPool.BLANK, url, parametrosPeticion.toJSONString(), callResponse.toJSONString(), new Date(),
					callResponse.getString(ZteRestClientApiConstant.CODIGO));

			if (!callResponse.getString(ZpActualizacionDatosOnclicApiKeys.CODIGO)
					.equals(String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_ERROR)) && notificacionCCM) {
				if (celularNoti.equals(celularActual) && emailNoti.equals(correoActual)) {
					generarNotificacion(request, ZpActualizacionDatosOnclicApiKeys.VALOR_CARD_ID_FIN,
							ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_FIN, celularActual, correoActual);
				} else if (!celularNoti.equals(celularActual) && emailNoti.equals(correoActual)) {
					generarNotificacion(request, ZpActualizacionDatosOnclicApiKeys.VALOR_CARD_ID_FIN,
							ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_FIN, celularNoti, emailNoti);
					generarNotificacion(request, ZpActualizacionDatosOnclicApiKeys.VALOR_CARD_ID_FIN,
							ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_FIN, celularActual, StringPool.BLANK);
				} else if (celularNoti.equals(celularActual) && !emailNoti.equals(correoActual)) {
					generarNotificacion(request, ZpActualizacionDatosOnclicApiKeys.VALOR_CARD_ID_FIN,
							ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_FIN, celularNoti, emailNoti);
					generarNotificacion(request, ZpActualizacionDatosOnclicApiKeys.VALOR_CARD_ID_FIN,
							ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_FIN, StringPool.BLANK, correoActual);
				} else {
					generarNotificacion(request, ZpActualizacionDatosOnclicApiKeys.VALOR_CARD_ID_FIN,
							ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_FIN, celularNoti, emailNoti);
					generarNotificacion(request, ZpActualizacionDatosOnclicApiKeys.VALOR_CARD_ID_FIN,
							ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_FIN, celularActual, correoActual);
				}
			}

		} catch (Exception e) {
			guardarParametrosLog(request, capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.URL_PASO_2, ZpActualizacionDatosOnclicApiKeys.URL_BT_CONTINUAR,
					StringPool.BLANK, url, parametrosPeticion.toJSONString(), callResponse.toJSONString(), new Date(),
					callResponse.getString(ZteRestClientApiConstant.CODIGO));
		}
		return callResponse;
	}

	@Override
	public JSONObject crearRequestInteraccionAutomatica(PortletRequest request) {

		String url = obtenerParametroLista(ZpActualizacionDatosOnclicApiKeys.LISTA_PROPIEDADES,
				ZpActualizacionDatosOnclicApiKeys.URL_INTERACCION_AUTOMATICA);

		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject headerLogTx = JSONFactoryUtil.createJSONObject();
		JSONObject callResponse = JSONFactoryUtil.createJSONObject();
		JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
		parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.UID_INTERACCION,
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.UID_AFILIADO));
		parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.COMENTARIO_INTERACCION,
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.INTERACCION_MENSAJE));

		try {
			headerLogTx = generarParametrosLogTransaccional(request,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.URL_PASO_2,
					ZpActualizacionDatosOnclicApiKeys.URL_BT_CONTINUAR_INTERACCION, new Date());
			JSONObject headerRqu = generarHeaderRq(request);
			headerRqu.remove(ZpActualizacionDatosOnclicApiKeys.RQ_UID);
			headerRqu.put(ZpActualizacionDatosOnclicApiKeys.RQ_UID,
					parseoFecha(ZpActualizacionDatosOnclicApiKeys.DATE_FORMAT_3));
			headers.put(ZteRestClientApiConstant.HEADER_RQU, headerRqu.toJSONString());
			headers.put(ZpActualizacionDatosOnclicApiKeys.HEADER_LOG_TX, headerLogTx.toJSONString());
			headers.put(ZteRestClientApiConstant.AUTHORIZATION,
					capturarParametro(request, ZteRestClientApiConstant.JWT));
			headers.put(ZpActualizacionDatosOnclicApiKeys.CONTENT_TYPE,
					ZpActualizacionDatosOnclicApiKeys.APPLICATION_JSON);

			callResponse = restApi.callRestServiceByPost(url, parametrosPeticion.toJSONString(), headers,
					new LinkedHashMap<>(), Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			guardarParametrosLog(request, capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.URL_PASO_2,
					ZpActualizacionDatosOnclicApiKeys.URL_BT_CONTINUAR_INTERACCION, StringPool.BLANK, url,
					parametrosPeticion.toJSONString(), callResponse.toJSONString(), new Date(),
					callResponse.getString(ZteRestClientApiConstant.CODIGO));

		} catch (Exception e) {
			guardarParametrosLog(request, capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
					ZpActualizacionDatosOnclicApiKeys.URL_PASO_2,
					ZpActualizacionDatosOnclicApiKeys.URL_BT_CONTINUAR_INTERACCION, StringPool.BLANK, url,
					parametrosPeticion.toJSONString(), callResponse.toJSONString(), new Date(),
					callResponse.getString(ZteRestClientApiConstant.CODIGO));
		}

		return callResponse;
	}

	private void generarNotificacion(PortletRequest request, String cardId, String plantilla, String celular,
			String correo) {
		String url = obtenerParametroLista(ZpActualizacionDatosOnclicApiKeys.LISTA_PROPIEDADES,
				ZpActualizacionDatosOnclicApiKeys.URL_NOTIFICACION_CCM);
		String urlPagina = StringPool.BLANK;
		if (plantilla.equals(ZpActualizacionDatosOnclicApiKeys.PLANTILLA_NOTIF_FIN)) {
			urlPagina += ZpActualizacionDatosOnclicApiKeys.URL_PASO_2;
		} else {
			urlPagina += ZpActualizacionDatosOnclicApiKeys.INICIO_TRANSACCION;
		}

		Map<String, String> headers = new LinkedHashMap<>();
		JSONObject headerLogTx = generarParametrosLogTransaccional(request,
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO), urlPagina,
				ZpActualizacionDatosOnclicApiKeys.INICIO_NOTF_CCM, new Date());

		JSONObject parametrosPeticion = JSONFactoryUtil.createJSONObject();
		JSONObject data = JSONFactoryUtil.createJSONObject();
		JSONObject dataObject = JSONFactoryUtil.createJSONObject();
		JSONObject response = JSONFactoryUtil.createJSONObject();
		JSONArray customers = JSONFactoryUtil.createJSONArray();

		try {
			headers.put(ZteRestClientApiConstant.HEADER_RQU, generarHeaderRq(request).toJSONString());
			headers.put(ZpActualizacionDatosOnclicApiKeys.HEADER_LOG_TX, headerLogTx.toJSONString());
			headers.put(ZpActualizacionDatosOnclicApiKeys.CONTENT_TYPE,
					ZpActualizacionDatosOnclicApiKeys.APPLICATION_JSON);

			parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.CARD_ID, cardId);

			dataObject.put(ZpActualizacionDatosOnclicApiKeys.CELULAR, celular);
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.MENSAJE_NOTIF, StringPool.BLANK);
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.DESTINATARIO,
					ZpActualizacionDatosOnclicApiKeys.DESTINATARIO_VAL);
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.TIPO_P_NOTIF,
					ZpActualizacionDatosOnclicApiKeys.TIPO_P_NOTIF_VAL);
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.NOMBRES_NOT,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.PRIMERNOMBRE) + StringPool.SPACE
							+ capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.SEGUNDO_NOMBRE));
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.APELLIDO_NOT,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.PRIMERAPELLIDO));
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.EMAIL, correo);
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.PRIMERNOMBRE_EMAIL,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.PRIMERNOMBRE));
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.PRIMERAPELLIDO_EMAIL,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.PRIMERAPELLIDO));
			dataObject.put(ZpActualizacionDatosOnclicApiKeys.ID,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO));
			data.put(ZpActualizacionDatosOnclicApiKeys.DATA, dataObject);
			data.put(ZpActualizacionDatosOnclicApiKeys.ID_NOTI,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO));
			data.put(ZpActualizacionDatosOnclicApiKeys.TYPE_ID_NOTI,
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO));
			customers.put(data);
			parametrosPeticion.put(ZpActualizacionDatosOnclicApiKeys.CUSTOMERS, customers);

			response = restApi.callRestServiceByPost(url, parametrosPeticion.toJSONString(), headers,
					new LinkedHashMap<>(), Integer.parseInt(_restClientApiConfiguration.requestTimeout()));

			guardarParametrosLog(request, capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO), urlPagina,
					ZpActualizacionDatosOnclicApiKeys.INICIO_NOTF_CCM, StringPool.BLANK, url, StringPool.BLANK,
					response.toJSONString(), new Date(), response.getString(ZteRestClientApiConstant.CODIGO));
		} catch (Exception e) {
			guardarParametrosLog(request, capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
					capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO), urlPagina,
					ZpActualizacionDatosOnclicApiKeys.INICIO_NOTF_CCM, StringPool.BLANK, url, StringPool.BLANK,
					response.toJSONString(), new Date(), response.getString(ZteRestClientApiConstant.CODIGO));
		}
	}

	private String obtenerDatoFiltra(String nombreLista, String datoFiltro) {
		JSONObject listaFiltrada = dataListApi.getFilteredList(nombreLista,
				ZpActualizacionDatosOnclicApiKeys.ABREVIATURA_CRM, datoFiltro,
				new String[] { ZpActualizacionDatosOnclicApiKeys.ID_SIEBEL,
						ZpActualizacionDatosOnclicApiKeys.ABREVIATURA_CRM });
		return listaFiltrada.getString(ZpActualizacionDatosOnclicApiKeys.ID_SIEBEL);
	}

	private String getGenero(String genero) {
		if (genero.equals(ZpActualizacionDatosOnclicApiKeys.GENERO_M_I)) {
			genero = ZpActualizacionDatosOnclicApiKeys.GENERO_M;
		} else {
			genero = ZpActualizacionDatosOnclicApiKeys.GENERO_F;
		}
		return genero;
	}

	private JSONObject gestionarTelefonosSiebel(PortletRequest portletRequest, JSONArray telefonos) {

		JSONObject telefonosUsuario = JSONFactoryUtil.createJSONObject();

		if (telefonos.length() == 0) {
			telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO, StringPool.BLANK);
			telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO, StringPool.BLANK);
		} else if (telefonos.length() == 1) {
			if (telefonos.getJSONObject(0).getString(ZpActualizacionDatosOnclicApiKeys.TIPO_TELEFONO)
					.equals(ZpActualizacionDatosOnclicApiKeys.TIPO_TELEFONO_CELULAR)) {
				telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO,
						telefonos.getJSONObject(0).getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO));
				telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO, StringPool.BLANK);
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.REGISTRO_CELULAR_SIEBEL,
						telefonos.getJSONObject(0).toJSONString());
			} else {
				telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO, StringPool.BLANK);
				telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO,
						telefonos.getJSONObject(0).getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.REGISTRO_TELEFONO_FIJO_SIEBEL,
						telefonos.getJSONObject(0).toJSONString());
			}
		} else {
			if (telefonos.getJSONObject(0).getString(ZpActualizacionDatosOnclicApiKeys.TIPO_TELEFONO)
					.equals(ZpActualizacionDatosOnclicApiKeys.TIPO_TELEFONO_CELULAR)) {
				telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO,
						telefonos.getJSONObject(0).getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO));
				telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO,
						telefonos.getJSONObject(1).getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.REGISTRO_CELULAR_SIEBEL,
						telefonos.getJSONObject(0).toJSONString());
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.REGISTRO_TELEFONO_FIJO_SIEBEL,
						telefonos.getJSONObject(1).toJSONString());
			} else {
				telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO,
						telefonos.getJSONObject(1).getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO));
				telefonosUsuario.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO,
						telefonos.getJSONObject(0).getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO));
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.REGISTRO_CELULAR_SIEBEL,
						telefonos.getJSONObject(1).toJSONString());
				inicializarParametro(portletRequest, ZpActualizacionDatosOnclicApiKeys.REGISTRO_TELEFONO_FIJO_SIEBEL,
						telefonos.getJSONObject(0).toJSONString());
			}
		}

		return telefonosUsuario;
	}

	private JSONObject crearRequestActualizarDatos(PortletRequest request, String barrio, String celular,
			String ciudadResidencia, String correoElectronico, String departamento, String direccion,
			String telefonoFijo) {

		JSONObject requestActualizar = JSONFactoryUtil.createJSONObject();

		requestActualizar.put(ZpActualizacionDatosOnclicApiKeys.ID_AFILIADO_ACT,
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.ID_AFILIADO_ACT));
		requestActualizar.put(ZpActualizacionDatosOnclicApiKeys.UID_AFILIADO,
				capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.UID_AFILIADO));

		try {

			JSONArray correosVencimiento = JSONFactoryUtil.createJSONArray();
			JSONArray correos = JSONFactoryUtil.createJSONArray();
			JSONArray interaccionAutomatica = JSONFactoryUtil.createJSONArray();

			if (correoElectronico != StringPool.BLANK) {
				if (capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.CORREO_SIEBEL) != null) {
					JSONObject correoAntiguoSiebel = JSONFactoryUtil.createJSONObject(
							capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.CORREO_SIEBEL));

					JSONObject correoVencimiento = JSONFactoryUtil.createJSONObject();
					correoVencimiento.put(ZpActualizacionDatosOnclicApiKeys.DIRRECION_ACT,
							correoAntiguoSiebel.get(ZpActualizacionDatosOnclicApiKeys.DIRRECION_ACT));
					correoVencimiento.put(ZpActualizacionDatosOnclicApiKeys.FECHA_INICIO_ACT,
							correoAntiguoSiebel.get(ZpActualizacionDatosOnclicApiKeys.FECHA_INICIO_ACT));
					correoVencimiento.put(ZpActualizacionDatosOnclicApiKeys.MEDIO_ACT,
							ZpActualizacionDatosOnclicApiKeys.EMAIL_ACT);
					correoVencimiento.put(ZpActualizacionDatosOnclicApiKeys.TIPO_ACT,
							ZpActualizacionDatosOnclicApiKeys.EMAIL_TIPO);

					correosVencimiento.put(correoVencimiento);
				}

				JSONObject correoNuevoSiebel = JSONFactoryUtil.createJSONObject();
				correoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.DIRRECION_ACT, correoElectronico);
				correoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.DIRRECION_ALTERNA_ACT, correoElectronico);
				correoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.ESTADO_ACT,
						ZpActualizacionDatosOnclicApiKeys.Y);
				correoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.MEDIO_ACT,
						ZpActualizacionDatosOnclicApiKeys.EMAIL_ACT);
				correoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL,
						ZpActualizacionDatosOnclicApiKeys.Y);
				correoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.TIPO_ACT,
						ZpActualizacionDatosOnclicApiKeys.EMAIL_TIPO);

				correos.put(correoNuevoSiebel);
				interaccionAutomatica.put(ZpActualizacionDatosOnclicApiKeys.INTERACCION_CORREO);
			}

			requestActualizar.put(ZpActualizacionDatosOnclicApiKeys.CORREOS_VENCIMIENTO, correosVencimiento);
			requestActualizar.put(ZpActualizacionDatosOnclicApiKeys.CORREOS_A_ACT, correos);

			JSONArray direccionesVencimiento = JSONFactoryUtil.createJSONArray();
			JSONArray direcciones = JSONFactoryUtil.createJSONArray();

			if (direccion != StringPool.BLANK || barrio != StringPool.BLANK || ciudadResidencia != StringPool.BLANK
					|| departamento != StringPool.BLANK) {

				if (capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.DIRECCION_SIEBEL) != null) {
					JSONObject direccionAntiguaSiebel = JSONFactoryUtil.createJSONObject(
							capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.DIRECCION_SIEBEL));
					direccionesVencimiento
							.put(direccionAntiguaSiebel.getString(ZpActualizacionDatosOnclicApiKeys.ID_ACT));
				}

				JSONObject direccionNuevaSiebel = JSONFactoryUtil.createJSONObject();
				direccionNuevaSiebel.put(ZpActualizacionDatosOnclicApiKeys.BARRIO_ACT, barrio);
				direccionNuevaSiebel.put(ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD, ciudadResidencia);
				direccionNuevaSiebel.put(ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO, departamento);
				direccionNuevaSiebel.put(ZpActualizacionDatosOnclicApiKeys.CODIGO_PAIS_ACT,
						ZpActualizacionDatosOnclicApiKeys.CODIGO_PAIS_COLOMBIA);
				direccionNuevaSiebel.put(ZpActualizacionDatosOnclicApiKeys.DIRECCION, direccion);
				direccionNuevaSiebel.put(ZpActualizacionDatosOnclicApiKeys.ESTADO_ACT,
						ZpActualizacionDatosOnclicApiKeys.Y);
				direccionNuevaSiebel.put(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL,
						ZpActualizacionDatosOnclicApiKeys.Y);
				direccionNuevaSiebel.put(ZpActualizacionDatosOnclicApiKeys.TIPO_ACT,
						ZpActualizacionDatosOnclicApiKeys.DIRECCION_TIPO);

				direcciones.put(direccionNuevaSiebel);
				interaccionAutomatica.put(ZpActualizacionDatosOnclicApiKeys.INTERACCION_DIRECCION);
			}

			requestActualizar.put(ZpActualizacionDatosOnclicApiKeys.DIRECCIONES_VENCIMIENTO_ACT,
					direccionesVencimiento);
			requestActualizar.put(ZpActualizacionDatosOnclicApiKeys.DIRECCIONES, direcciones);

			JSONArray telefonosVencimiento = JSONFactoryUtil.createJSONArray();
			boolean celularAntiguoSiebelPrincipal = false;
			boolean telefonoFijoAntiguoSiebelPrincipal = false;

			JSONObject celularAntiguoSiebel = JSONFactoryUtil.createJSONObject();
			JSONObject telefonoFijoAntiguoSiebel = JSONFactoryUtil.createJSONObject();
			JSONArray telefonos = JSONFactoryUtil.createJSONArray();

			if (capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.REGISTRO_CELULAR_SIEBEL) != null) {
				celularAntiguoSiebel = JSONFactoryUtil.createJSONObject(
						capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.REGISTRO_CELULAR_SIEBEL));

				if (celularAntiguoSiebel.getString(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL)
						.equalsIgnoreCase(ZpActualizacionDatosOnclicApiKeys.Y)) {
					celularAntiguoSiebelPrincipal = true;
				}
			}

			if (capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.REGISTRO_TELEFONO_FIJO_SIEBEL) != null) {
				telefonoFijoAntiguoSiebel = JSONFactoryUtil.createJSONObject(
						capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.REGISTRO_TELEFONO_FIJO_SIEBEL));

				if (telefonoFijoAntiguoSiebel.getString(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL)
						.equalsIgnoreCase(ZpActualizacionDatosOnclicApiKeys.Y)) {
					telefonoFijoAntiguoSiebelPrincipal = true;
				}
			}

			if (celular != StringPool.BLANK) {
				if (celularAntiguoSiebel.length() != 0) {
					telefonosVencimiento.put(celularAntiguoSiebel.getString(ZpActualizacionDatosOnclicApiKeys.ID_ACT));
				}

				JSONObject celularNuevoSiebel = JSONFactoryUtil.createJSONObject();
				celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.CODIGO_PAIS_ACT,
						ZpActualizacionDatosOnclicApiKeys.INDICATIVO_COLOMBIA);
				celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.ESTADO_ACT,
						ZpActualizacionDatosOnclicApiKeys.Y);
				celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.NUMERO_ACT, celular);
				celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO, celular);
				celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.TIPO_ACT,
						ZpActualizacionDatosOnclicApiKeys.TIPO_TELEFONO_CELULAR);

				if (telefonoFijoAntiguoSiebel.length() != 0) {
					if (celularAntiguoSiebelPrincipal) {
						celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL,
								ZpActualizacionDatosOnclicApiKeys.Y);
					} else if (telefonoFijoAntiguoSiebelPrincipal) {
						celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL,
								ZpActualizacionDatosOnclicApiKeys.N);
					} else if (!celularAntiguoSiebelPrincipal && !telefonoFijoAntiguoSiebelPrincipal) {
						celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL,
								ZpActualizacionDatosOnclicApiKeys.Y);
					}
				} else {
					celularNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL,
							ZpActualizacionDatosOnclicApiKeys.Y);
				}

				telefonos.put(celularNuevoSiebel);
				interaccionAutomatica.put(ZpActualizacionDatosOnclicApiKeys.INTERACCION_CELULAR);
			}

			if (telefonoFijo != StringPool.BLANK) {
				if (capturarParametro(request,
						ZpActualizacionDatosOnclicApiKeys.REGISTRO_TELEFONO_FIJO_SIEBEL) != null) {
					telefonosVencimiento
							.put(telefonoFijoAntiguoSiebel.getString(ZpActualizacionDatosOnclicApiKeys.ID_ACT));
				}

				JSONObject telefonoFijoNuevoSiebel = JSONFactoryUtil.createJSONObject();
				telefonoFijoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.CODIGO_PAIS_ACT,
						ZpActualizacionDatosOnclicApiKeys.CODIGO_PAIS_COLOMBIA);
				telefonoFijoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.ESTADO_ACT,
						ZpActualizacionDatosOnclicApiKeys.Y);
				telefonoFijoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.NUMERO_ACT, telefonoFijo);
				telefonoFijoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_CONTACTO, telefonoFijo);
				telefonoFijoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.TIPO_ACT,
						ZpActualizacionDatosOnclicApiKeys.TIPO_TELEFONO_FIJO);

				if (telefonoFijoAntiguoSiebelPrincipal) {
					telefonoFijoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL,
							ZpActualizacionDatosOnclicApiKeys.Y);
				} else {
					telefonoFijoNuevoSiebel.put(ZpActualizacionDatosOnclicApiKeys.REGISTRO_PRINCIPAL,
							ZpActualizacionDatosOnclicApiKeys.N);
				}

				telefonos.put(telefonoFijoNuevoSiebel);
				interaccionAutomatica.put(ZpActualizacionDatosOnclicApiKeys.INTERACCION_TELEFONO);
			}

			requestActualizar.put(ZpActualizacionDatosOnclicApiKeys.TELEFONOS, telefonos);
			requestActualizar.put(ZpActualizacionDatosOnclicApiKeys.TELEFONOS_VENCIMIENTO_ACT, telefonosVencimiento);

			StringBuilder mensajeInteraccionAutomatica = new StringBuilder();

			if (interaccionAutomatica.length() != 0) {
				mensajeInteraccionAutomatica.append(ZpActualizacionDatosOnclicApiKeys.INTERACCION_INICIO);
				for (int i = 0; i < interaccionAutomatica.length(); i++) {
					String elemento = interaccionAutomatica.getString(i);
					mensajeInteraccionAutomatica.append(elemento);
					if (i < interaccionAutomatica.length() - 1) {
						mensajeInteraccionAutomatica.append(StringPool.SEMICOLON).append(StringPool.SPACE);
					}
				}
			} else {
				mensajeInteraccionAutomatica.append(StringPool.BLANK);
			}

			inicializarParametro(request, ZpActualizacionDatosOnclicApiKeys.INTERACCION_MENSAJE,
					mensajeInteraccionAutomatica.toString());

		} catch (JSONException e) {
			log.error(ZpActualizacionDatosOnclicApiKeys.ERROR_CREAR_REQUEST_ACTUALIZAR, e);
		}

		return requestActualizar;
	}

}