package zp.actualizacion.datos.onclic.web.command;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApi;
import zp.actualizacion.datos.onclic.web.constants.ZpActualizacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpActualizacionDatosOnclicWebPortletKeys.ZPACTUALIZACIONDATOSONCLICWEB,
		"mvc.command.name="
				+ ZpActualizacionDatosOnclicWebPortletKeys.RENDER_PROXIMOS_PASOS }, service = MVCRenderCommand.class)
public class ZpActualizacionDatosOnclicRenderProximosPasos implements MVCRenderCommand {

	@Reference
	private ZpActualizacionDatosOnclicApi zpActualizacionApi;

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		String sesion = zpActualizacionApi.capturarParametro(renderRequest,
				ZpActualizacionDatosOnclicWebPortletKeys.INICIO_SESION);

		renderRequest.setAttribute(ZpActualizacionDatosOnclicWebPortletKeys.INICIO_SESION, sesion);
		return "/proximos-pasos.jsp";
	}

}