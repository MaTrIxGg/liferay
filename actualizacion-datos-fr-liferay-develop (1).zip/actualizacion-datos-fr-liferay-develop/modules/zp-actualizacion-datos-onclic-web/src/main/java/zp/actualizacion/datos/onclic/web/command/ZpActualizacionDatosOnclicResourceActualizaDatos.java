package zp.actualizacion.datos.onclic.web.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApi;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApiKeys;
import zp.actualizacion.datos.onclic.web.constants.ZpActualizacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpActualizacionDatosOnclicWebPortletKeys.ZPACTUALIZACIONDATOSONCLICWEB,
		"mvc.command.name="
				+ ZpActualizacionDatosOnclicWebPortletKeys.RESOURCE_ACTUALIZA_DATOS }, service = MVCResourceCommand.class)

public class ZpActualizacionDatosOnclicResourceActualizaDatos extends BaseMVCResourceCommand {

	@Reference
	private ZpActualizacionDatosOnclicApi zpActualizacionApi;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {
		JSONObject respuesta = JSONFactoryUtil.createJSONObject();
		try {
			String barrioResidencia = ParamUtil.getString(resourceRequest,
					ZpActualizacionDatosOnclicApiKeys.BARRIO_RESIDENCIA, StringPool.BLANK);
			String ciudadResidencia = ParamUtil.getString(resourceRequest,
					ZpActualizacionDatosOnclicApiKeys.CIUDAD_RESIDENCIA, StringPool.BLANK);
			String correoElectronico = ParamUtil.getString(resourceRequest,
					ZpActualizacionDatosOnclicApiKeys.CORREO_ELECTRONICO, StringPool.BLANK);
			String correoActual = ParamUtil.getString(resourceRequest, ZpActualizacionDatosOnclicApiKeys.CORREO_ACTUAL,
					StringPool.BLANK);
			String departamentoResidencia = ParamUtil.getString(resourceRequest,
					ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTO_RESIDENCIA, StringPool.BLANK);
			String direccionResidencia = ParamUtil.getString(resourceRequest,
					ZpActualizacionDatosOnclicApiKeys.DIRECCION_RESIDENCIA, StringPool.BLANK);
			String telefonoFijo = ParamUtil.getString(resourceRequest, ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO,
					StringPool.BLANK);
			String celular = ParamUtil.getString(resourceRequest, ZpActualizacionDatosOnclicApiKeys.CELULAR,
					StringPool.BLANK);
			String celularActual = ParamUtil.getString(resourceRequest,
					ZpActualizacionDatosOnclicApiKeys.CELULAR_ACTUAL, StringPool.BLANK);
			Boolean notificacionCCM = ParamUtil.getBoolean(resourceRequest,
					ZpActualizacionDatosOnclicApiKeys.NOTIFICACION_CCM_DATOS);

			JSONObject response = zpActualizacionApi.actualizaDatos(resourceRequest, resourceResponse, barrioResidencia,
					celular, ciudadResidencia, correoElectronico, departamentoResidencia, direccionResidencia,
					StringPool.BLANK, telefonoFijo, notificacionCCM, correoActual, celularActual);
			if (response
					.getInt(ZpActualizacionDatosOnclicApiKeys.CODIGO) == ZpActualizacionDatosOnclicApiKeys.CODE_OK) {
				
				String automaticInteractionMessage = zpActualizacionApi.capturarParametro(resourceRequest, ZpActualizacionDatosOnclicApiKeys.INTERACCION_MENSAJE);
				JSONObject responseInteraction = JSONFactoryUtil.createJSONObject();

				if (!automaticInteractionMessage.equals(StringPool.BLANK)) {
					responseInteraction = zpActualizacionApi.crearRequestInteraccionAutomatica(resourceRequest);
				} 
				
				respuesta.put(ZpActualizacionDatosOnclicApiKeys.CODIGO, ZpActualizacionDatosOnclicApiKeys.CODE_OK);
			} else {
				respuesta.put(ZpActualizacionDatosOnclicApiKeys.CODIGO, ZpActualizacionDatosOnclicApiKeys.CODE_ERROR);
			}
		} catch (Exception e) {

		}
		resourceResponse.getWriter().append(respuesta.toJSONString());
	}
}