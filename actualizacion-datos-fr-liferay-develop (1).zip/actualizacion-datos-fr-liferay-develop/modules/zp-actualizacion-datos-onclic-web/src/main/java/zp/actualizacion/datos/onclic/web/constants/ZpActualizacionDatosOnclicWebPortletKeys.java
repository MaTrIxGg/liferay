package zp.actualizacion.datos.onclic.web.constants;

/**
 * @author POR12989
 */
public class ZpActualizacionDatosOnclicWebPortletKeys {

	public ZpActualizacionDatosOnclicWebPortletKeys() {
		super();
	}

	public static final String ZPACTUALIZACIONDATOSONCLICWEB =
		"zp_actualizacion_datos_onclic_web_ZpActualizacionDatosOnclicWebPortlet";
	
	public static final String PREFERENCE_SITE_GROUPID="PREFERENCE_SITE_GROUPID";

	public static final String PREFERENCE_CARPETA_IMAGENES_ID="PREFERENCE_CARPETA_IMAGENES_ID";
	public static final String PREFERENCE_URL_SITIO_PORVENIR="PREFERENCE_URL_SITIO_PORVENIR";
	public static final String PREFERENCE_URL_SITIO_RECUPERAR_PSWD="PREFERENCE_URL_SITIO_RECUPERAR_PSWD";
	public static final String PREFERENCE_URL_SITIO_CANALES_DIGITALES="PREFERENCE_URL_SITIO_CANALES_DIGITALES";
	public static final String PREFERENCE_URL_SITIO_PORVENIR_PREFERENCIAL="PREFERENCE_URL_SITIO_PORVENIR_PREFERENCIAL";
	public static final String PREFERENCE_URL_FILTER="PREFERENCE_URL_FILTER";
	public static final String RESOURCE_LISTA_CIUDADES="/actualizacion/lista-ciudades";
	public static final String RESOURCE_REGISTRO_LOGS="/actualizacion/registro-transaccion";
	public static final String RESOURCE_ACTUALIZA_DATOS="/actualizacion/actualiza-datos";
	public static final String RENDER_PROXIMOS_PASOS="/actualizacion/proximos-pasos";
	
	public static final String UTF_8="UTF-8";
	public static final String APPLICATION_JSON = "application/json";
	
	public static final String ACTION_LOGOUT="/actualizacion/logout";
	
	public static final String LISTA_DATOS_VIVIENDA="ZPACTListaDatosVivienda";
	public static final String OPCIONES_RURAL="opcionesRural";
	public static final String OPCIONES_URBANO="opcionesUrbano";
	public static final String OPCIONES_VIA_PRINCIPAL="opcionesViaPrincipal";
	public static final String OPCIONES_NUMERO="opcionesNumero";
	public static final String OPCIONES_NOM="opcionesNomNumVia";
	
	public static final String LISTA_CONVENCIONES_RURAL="LISTA_CONVENCIONES_RURAL";
	public static final String LISTA_CONVENCIONES_URBANO="LISTA_CONVENCIONES_URBANO";
	public static final String LISTA_VIA_PRINCIPAL="VIA_PRINCIPAL";
	public static final String LISTA_NOM_NUM_VIA="NOM/NUM_VIA";
	public static final String LISTA_NUMERO="NUMERO";
	
	public static final String INICIO_SESION="inicioSesion";
}