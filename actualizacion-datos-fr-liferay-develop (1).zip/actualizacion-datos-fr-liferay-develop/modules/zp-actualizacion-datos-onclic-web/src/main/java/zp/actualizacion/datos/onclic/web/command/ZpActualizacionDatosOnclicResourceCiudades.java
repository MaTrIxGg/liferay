package zp.actualizacion.datos.onclic.web.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApi;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApiKeys;
import zp.actualizacion.datos.onclic.web.constants.ZpActualizacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpActualizacionDatosOnclicWebPortletKeys.ZPACTUALIZACIONDATOSONCLICWEB,
		"mvc.command.name="
				+ ZpActualizacionDatosOnclicWebPortletKeys.RESOURCE_LISTA_CIUDADES }, service = MVCResourceCommand.class)

public class ZpActualizacionDatosOnclicResourceCiudades extends BaseMVCResourceCommand {
	
	@Reference
	private ZpActualizacionDatosOnclicApi zpActualizacionApi;
	
	private static Log log = LogFactoryUtil.getLog(ZpActualizacionDatosOnclicResourceCiudades.class);

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws Exception {

		String idDepartamento = ParamUtil.getString(resourceRequest,
				ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO, StringPool.BLANK);
		try {

			JSONObject response = JSONFactoryUtil.createJSONObject();
			JSONObject respuesta = zpActualizacionApi.listaRDM(resourceRequest, resourceResponse, idDepartamento,
					ZpActualizacionDatosOnclicApiKeys.UNDEFINED,
					ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_CIUDADES);
			if (respuesta
					.getInt(ZpActualizacionDatosOnclicApiKeys.CODIGO) == ZpActualizacionDatosOnclicApiKeys.CODE_OK) {
				response.put(ZpActualizacionDatosOnclicApiKeys.CODIGO, ZpActualizacionDatosOnclicApiKeys.CODE_OK);
				JSONArray ciudades = respuesta.getJSONArray(ZpActualizacionDatosOnclicApiKeys.CIUDADES);
				response.put(ZpActualizacionDatosOnclicApiKeys.CIUDADES, ciudades);
			} else {
				response.put(ZpActualizacionDatosOnclicApiKeys.CODIGO, ZpActualizacionDatosOnclicApiKeys.CODE_ERROR);
			}
			resourceResponse.getWriter().append(response.toJSONString());

		} catch (Exception e) {
			log.info("Error logica ciudades: " + e);
		}
	}

}