package zp.actualizacion.datos.onclic.web.portlet.configuration;

import com.liferay.portal.kernel.portlet.ConfigurationAction;
import com.liferay.portal.kernel.portlet.DefaultConfigurationAction;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;

import zp.actualizacion.datos.onclic.web.constants.ZpActualizacionDatosOnclicWebPortletKeys;

@Component(configurationPolicy = ConfigurationPolicy.OPTIONAL, immediate = true, property = { "javax.portlet.name="
		+ ZpActualizacionDatosOnclicWebPortletKeys.ZPACTUALIZACIONDATOSONCLICWEB }, service = ConfigurationAction.class)

public class ZpActualizacionDatosOnclicWebConfiguration extends DefaultConfigurationAction {

	@Override
	public void processAction(PortletConfig portletConfig, ActionRequest actionRequest, ActionResponse actionResponse)
			throws Exception {

		String groupId = ParamUtil.getString(actionRequest,
				ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_SITE_GROUPID);
		setPreference(actionRequest, ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_SITE_GROUPID, groupId);

		String carpetaImagenesId = ParamUtil.getString(actionRequest,
				ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_CARPETA_IMAGENES_ID);
		setPreference(actionRequest, ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_CARPETA_IMAGENES_ID,
				carpetaImagenesId);

		String URLSitioPorvenir = ParamUtil.getString(actionRequest,
				ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_PORVENIR);
		setPreference(actionRequest, ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_PORVENIR,
				URLSitioPorvenir);

		String URLSitioRecuperarPswd = ParamUtil.getString(actionRequest,
				ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_RECUPERAR_PSWD);
		setPreference(actionRequest, ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_RECUPERAR_PSWD,
				URLSitioRecuperarPswd);

		String URLSitioCanalesDigitales = ParamUtil.getString(actionRequest,
				ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_CANALES_DIGITALES);
		setPreference(actionRequest, ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_CANALES_DIGITALES,
				URLSitioCanalesDigitales);

		String URLSitioPorvenirPreferencial = ParamUtil.getString(actionRequest,
				ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_PORVENIR_PREFERENCIAL);
		setPreference(actionRequest,
				ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_PORVENIR_PREFERENCIAL,
				URLSitioPorvenirPreferencial);

		super.processAction(portletConfig, actionRequest, actionResponse);
	}

}