package zp.actualizacion.datos.onclic.web.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletPreferences;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApi;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApiKeys;
import zp.actualizacion.datos.onclic.web.constants.ZpActualizacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpActualizacionDatosOnclicWebPortletKeys.ZPACTUALIZACIONDATOSONCLICWEB,
		"mvc.command.name="
				+ ZpActualizacionDatosOnclicWebPortletKeys.ACTION_LOGOUT }, service = MVCActionCommand.class)

public class ZpActualizacionDatosOnclicActionLogout extends BaseMVCActionCommand {

	@Reference
	private ZpActualizacionDatosOnclicApi zpActualizacionApi;
	
	@Reference
	private  DinamicDatalistApi dataListApi;

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		PortletPreferences portletPreference = actionRequest.getPreferences();
		String url = ParamUtil.getString(actionRequest, "urlRedirect");

		if (url.equals(ZpActualizacionDatosOnclicApiKeys.HOME)) {
			url = portletPreference.getValue(ZpActualizacionDatosOnclicWebPortletKeys.PREFERENCE_URL_SITIO_PORVENIR,
					StringPool.BLANK);
		} else {
			url = dataListApi.getRecordValue(ZpActualizacionDatosOnclicApiKeys.LISTA_PROPIEDADES,
					ZpActualizacionDatosOnclicApiKeys.URL_INICIO);
		}
		
		zpActualizacionApi.logOutAction(actionRequest, actionResponse, url);
	}
}