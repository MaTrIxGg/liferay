package zp.actualizacion.datos.onclic.web.portlet;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;

import java.io.IOException;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import co.com.porvenir.portal.api.dinamic.datalist.DinamicDatalistApi;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApi;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApiKeys;
import zp.actualizacion.datos.onclic.web.constants.ZpActualizacionDatosOnclicWebPortletKeys;

/**
 * @author POR12989
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=ZpActualizacionDatosOnclicWeb", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/actualizacion-datos.jsp",
		"javax.portlet.name=" + ZpActualizacionDatosOnclicWebPortletKeys.ZPACTUALIZACIONDATOSONCLICWEB,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)

public class ZpActualizacionDatosOnclicWebPortlet extends MVCPortlet {

	@Reference
	private ZpActualizacionDatosOnclicApi actualizacionDatosApi;

	@Reference
	private DinamicDatalistApi dynamicDataList;

	@Override
	public void doView(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		boolean errorTecnico = true;
		JSONObject respuesta = actualizacionDatosApi.consultaDatosBasicos(renderRequest, renderResponse);

		if (respuesta
				.getInt(ZpActualizacionDatosOnclicApiKeys.STATUS_CODE) == ZpActualizacionDatosOnclicApiKeys.CODE_OK) {

			this.viewTemplate = ZpActualizacionDatosOnclicApiKeys.MODAL_ACT_DATOS;
			errorTecnico = false;

			renderRequest.setAttribute(ZpActualizacionDatosOnclicWebPortletKeys.OPCIONES_RURAL,
					dynamicDataList.getRecordValue(ZpActualizacionDatosOnclicWebPortletKeys.LISTA_DATOS_VIVIENDA,
							ZpActualizacionDatosOnclicWebPortletKeys.LISTA_CONVENCIONES_RURAL));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicWebPortletKeys.OPCIONES_URBANO,
					dynamicDataList.getRecordValue(ZpActualizacionDatosOnclicWebPortletKeys.LISTA_DATOS_VIVIENDA,
							ZpActualizacionDatosOnclicWebPortletKeys.LISTA_CONVENCIONES_URBANO));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicWebPortletKeys.OPCIONES_VIA_PRINCIPAL,
					dynamicDataList.getRecordValue(ZpActualizacionDatosOnclicWebPortletKeys.LISTA_DATOS_VIVIENDA,
							ZpActualizacionDatosOnclicWebPortletKeys.LISTA_VIA_PRINCIPAL));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicWebPortletKeys.OPCIONES_NUMERO,
					dynamicDataList.getRecordValue(ZpActualizacionDatosOnclicWebPortletKeys.LISTA_DATOS_VIVIENDA,
							ZpActualizacionDatosOnclicWebPortletKeys.LISTA_NUMERO));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicWebPortletKeys.OPCIONES_NOM,
					dynamicDataList.getRecordValue(ZpActualizacionDatosOnclicWebPortletKeys.LISTA_DATOS_VIVIENDA,
							ZpActualizacionDatosOnclicWebPortletKeys.LISTA_NOM_NUM_VIA));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.ERROR, errorTecnico);

			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO, actualizacionDatosApi
					.capturarParametro(renderRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO, actualizacionDatosApi
					.capturarParametro(renderRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_FORMATO));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.NUMERO_CELULAR, actualizacionDatosApi
					.capturarParametro(renderRequest, ZpActualizacionDatosOnclicApiKeys.NUMERO_CELULAR));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.CELULAR, actualizacionDatosApi
					.capturarParametro(renderRequest, ZpActualizacionDatosOnclicApiKeys.CELULAR_NOT));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.CORREO_ELECTRONICO_LOGIN, actualizacionDatosApi
					.capturarParametro(renderRequest, ZpActualizacionDatosOnclicApiKeys.CORREO_ELECTRONICO));

			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.NOMBRES_COMPLETOS,
					respuesta.getString(ZpActualizacionDatosOnclicApiKeys.NOMBRES_COMPLETOS));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.FECHA_NACIMIENTO,
					respuesta.get(ZpActualizacionDatosOnclicApiKeys.FECHA_NACIMIENTO));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.CORREO_ELECTRONICO,
					respuesta.getString(ZpActualizacionDatosOnclicApiKeys.CORREO_ELECTRONICO));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.DIRECCION,
					respuesta.getString(ZpActualizacionDatosOnclicApiKeys.DIRECCION));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.BARRIO_ACT,
					respuesta.getString(ZpActualizacionDatosOnclicApiKeys.BARRIO_ACT));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.GENERO,
					respuesta.get(ZpActualizacionDatosOnclicApiKeys.GENERO));
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO,
					respuesta.getString(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO));

			datosAutenticacion(renderRequest);
			if (generarArrayDepartamentos(renderRequest, renderResponse)
					.equals(String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_ERROR))) {
				errorTecnico = true;
				this.viewTemplate = ZpActualizacionDatosOnclicApiKeys.MODAL_NO_DATA;
				renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.ERROR, errorTecnico);
			}
		} else if (respuesta.getInt(
				ZpActualizacionDatosOnclicApiKeys.STATUS_CODE) == ZpActualizacionDatosOnclicApiKeys.CODE_O_NO_DATOS) {
			this.viewTemplate = ZpActualizacionDatosOnclicApiKeys.MODAL_NO_DATA;
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.ERROR, false);
		} else if (respuesta.getInt(
				ZpActualizacionDatosOnclicApiKeys.STATUS_CODE) == ZpActualizacionDatosOnclicApiKeys.CODE_ERROR) {
			this.viewTemplate = ZpActualizacionDatosOnclicApiKeys.MODAL_NO_DATA;
			renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.ERROR, errorTecnico);
		}
		super.doView(renderRequest, renderResponse);
	}

	public String generarArrayDepartamentos(PortletRequest request, PortletResponse response) {
		String codigo = StringPool.BLANK;
		if (actualizacionDatosApi.capturarParametro(request,
				ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO) != ZpActualizacionDatosOnclicApiKeys.UNDEFINED) {
			JSONObject respuestaRDM = actualizacionDatosApi.listaRDM(request, response,
					actualizacionDatosApi.capturarParametro(request,
							ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO),
					actualizacionDatosApi.capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD),
					ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_CYD);
			if (respuestaRDM.getString(ZpActualizacionDatosOnclicApiKeys.CODIGO)
					.equals(String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_OK))) {
				JSONArray departamentos = respuestaRDM.getJSONArray(ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTOS);
				JSONArray ciudadesSelect = respuestaRDM.getJSONArray(ZpActualizacionDatosOnclicApiKeys.CIUDADES);
				request.setAttribute(ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTOS, departamentos);
				request.setAttribute(ZpActualizacionDatosOnclicApiKeys.CIUDADES_SELECT, ciudadesSelect);
			} else {
				codigo = String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_ERROR);
			}
		} else {
			JSONObject respuestaRDM = actualizacionDatosApi.listaRDM(request, response,
					actualizacionDatosApi.capturarParametro(request,
							ZpActualizacionDatosOnclicApiKeys.CODIGO_DEPARTAMENTO),
					actualizacionDatosApi.capturarParametro(request, ZpActualizacionDatosOnclicApiKeys.CODIGO_CIUDAD),
					ZpActualizacionDatosOnclicApiKeys.NUM_CONSULTA_DEPARTAMENTOS);
			if (respuestaRDM.getString(ZpActualizacionDatosOnclicApiKeys.CODIGO)
					.equals(String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_OK))) {
				JSONArray departamentos = respuestaRDM.getJSONArray(ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTOS);
				request.setAttribute(ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTOS, departamentos);
			} else {
				codigo = String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_ERROR);
			}
		}
		return codigo;
	}

	public void datosAutenticacion(RenderRequest renderRequest) {
		String descripcionAuth = actualizacionDatosApi.capturarParametro(renderRequest,
				ZpActualizacionDatosOnclicApiKeys.DESCRIPCION_AUTH);
		String datoAuth = actualizacionDatosApi.capturarParametro(renderRequest,
				ZpActualizacionDatosOnclicApiKeys.DATO_AUTH);
		String lugarResidencia = actualizacionDatosApi.capturarParametro(renderRequest,
				ZpActualizacionDatosOnclicApiKeys.SELECCION_RESIDENCIA);
		renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.DESCRIPCION_AUTH, descripcionAuth);
		renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.DATO_AUTH, datoAuth);
		renderRequest.setAttribute(ZpActualizacionDatosOnclicApiKeys.SELECCION_RESIDENCIA, lugarResidencia);
	}
}