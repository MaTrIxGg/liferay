package zp.actualizacion.datos.onclic.web.command;

import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCResourceCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.util.Date;

import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApi;
import zp.actualizacion.datos.onclic.api.api.ZpActualizacionDatosOnclicApiKeys;
import zp.actualizacion.datos.onclic.web.constants.ZpActualizacionDatosOnclicWebPortletKeys;

@Component(immediate = true, property = {
		"javax.portlet.name=" + ZpActualizacionDatosOnclicWebPortletKeys.ZPACTUALIZACIONDATOSONCLICWEB,
		"mvc.command.name="
				+ ZpActualizacionDatosOnclicWebPortletKeys.RESOURCE_REGISTRO_LOGS }, service = MVCResourceCommand.class)
public class ZpActualizacionDatosOnclicResourceRegistroLogs extends BaseMVCResourceCommand {

	@Reference
	private ZpActualizacionDatosOnclicApi zpActualizacionApi;

	@Override
	protected void doServeResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) {
		String urlPagina = ParamUtil.getString(resourceRequest, ZpActualizacionDatosOnclicApiKeys.URL_PAGINA,
				StringPool.BLANK);
		String componenteId = ParamUtil.getString(resourceRequest, ZpActualizacionDatosOnclicApiKeys.COMPONENTE_ID,
				StringPool.BLANK);
		if (urlPagina.equals("Proximos pasos")) {
			registrarInteraccion(resourceRequest, componenteId, urlPagina);
		} else {
			registrarLogFinal(resourceRequest, urlPagina);
		}
	}

	private void registrarInteraccion(ResourceRequest resourceRequest, String componenteId, String urlPagina) {
		zpActualizacionApi.guardarParametrosLog(resourceRequest,
				zpActualizacionApi.capturarParametro(resourceRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
				zpActualizacionApi.capturarParametro(resourceRequest,
						ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
				urlPagina, componenteId, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK, StringPool.BLANK,
				new Date(), String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_OK));
	}

	private void registrarLogFinal(ResourceRequest resourceRequest, String urlPagina) {
		JSONObject parametros = JSONFactoryUtil.createJSONObject();
		String componenteId = ParamUtil.getString(resourceRequest, ZpActualizacionDatosOnclicApiKeys.COMPONENTE_ID);
		String barrioResidencia = ParamUtil.getString(resourceRequest,
				ZpActualizacionDatosOnclicApiKeys.BARRIO_RESIDENCIA);
		String ciudadResidencia = ParamUtil.getString(resourceRequest,
				ZpActualizacionDatosOnclicApiKeys.CIUDAD_RESIDENCIA);
		String correoElectronico = ParamUtil.getString(resourceRequest,
				ZpActualizacionDatosOnclicApiKeys.CORREO_ELECTRONICO);
		String departamentoResidencia = ParamUtil.getString(resourceRequest,
				ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTO_RESIDENCIA);
		String direccionResidencia = ParamUtil.getString(resourceRequest,
				ZpActualizacionDatosOnclicApiKeys.DIRECCION_RESIDENCIA);
		String telefonoFijo = ParamUtil.getString(resourceRequest, ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO);
		String celular = ParamUtil.getString(resourceRequest, ZpActualizacionDatosOnclicApiKeys.CELULAR);
		Boolean notificacionCCM = ParamUtil.getBoolean(resourceRequest,
				ZpActualizacionDatosOnclicApiKeys.NOTIFICACION_CCM_DATOS);

		parametros.put(ZpActualizacionDatosOnclicApiKeys.CELULAR, celular);
		parametros.put(ZpActualizacionDatosOnclicApiKeys.TELEFONO_FIJO, telefonoFijo);
		parametros.put(ZpActualizacionDatosOnclicApiKeys.DIRECCION_RESIDENCIA, direccionResidencia);
		parametros.put(ZpActualizacionDatosOnclicApiKeys.DEPARTAMENTO_RESIDENCIA, departamentoResidencia);
		parametros.put(ZpActualizacionDatosOnclicApiKeys.CORREO_ELECTRONICO, correoElectronico);
		parametros.put(ZpActualizacionDatosOnclicApiKeys.CIUDAD_RESIDENCIA, ciudadResidencia);
		parametros.put(ZpActualizacionDatosOnclicApiKeys.BARRIO_RESIDENCIA, barrioResidencia);
		parametros.put(ZpActualizacionDatosOnclicApiKeys.NOTIFICACION_CCM, notificacionCCM);

		if (componenteId.equals(ZpActualizacionDatosOnclicApiKeys.BT_VOLVER_PASO_1)) {
			parametros.put(ZpActualizacionDatosOnclicApiKeys.RESPUESTA,
					ZpActualizacionDatosOnclicApiKeys.REGRESAR_PASO_1);
		}
		if (componenteId.equals(ZpActualizacionDatosOnclicApiKeys.BT_FINALIZAR)) {
			parametros.put(ZpActualizacionDatosOnclicApiKeys.RESPUESTA,
					ZpActualizacionDatosOnclicApiKeys.FN_TRANSACCION);
		}
		zpActualizacionApi.guardarParametrosLog(resourceRequest,
				zpActualizacionApi.capturarParametro(resourceRequest, ZpActualizacionDatosOnclicApiKeys.TIPO_DOCUMENTO),
				zpActualizacionApi.capturarParametro(resourceRequest,
						ZpActualizacionDatosOnclicApiKeys.NUMERO_DOCUMENTO),
				urlPagina, componenteId, StringPool.BLANK, StringPool.BLANK,
				urlPagina.equals(ZpActualizacionDatosOnclicApiKeys.URL_PASO_1) ? StringPool.BLANK
						: parametros.toJSONString(),
				StringPool.BLANK, new Date(), String.valueOf(ZpActualizacionDatosOnclicApiKeys.CODE_OK));
	}
}