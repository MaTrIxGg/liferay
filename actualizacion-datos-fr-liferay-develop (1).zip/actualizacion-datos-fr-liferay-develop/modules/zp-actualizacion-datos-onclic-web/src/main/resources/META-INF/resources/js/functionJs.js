window.onload=myTimer;
/*Prevenir cuando se da click al botón atras*/
function myTimer() {
    window.location.hash="no-back";
    window.location.hash="Again-button";//again because google chrome don't insert first hash into history
    window.onhashchange=function(){
    	window.location.hash="no-back";}  
} 