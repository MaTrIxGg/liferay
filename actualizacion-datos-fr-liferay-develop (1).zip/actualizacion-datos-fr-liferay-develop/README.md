# devops-template-repo-git 

[![java](https://img.shields.io/badge/java-v11.0.X-5C4EE5.svg)](https://www.oracle.com/co/java/technologies/javase-jdk11-downloads.html)

[![gradle](https://img.shields.io/badge/gradle-v6.6.X-yellow.svg)](https://gradle.org/install/)
[![maven](https://img.shields.io/badge/maven-v3.6.X-red.svg)](https://maven.apache.org/)



> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis, lacus a pretium euismod, turpis dolor viverra velit, sit amet laoreet justo ante at sem. Pellentesque sollicitudin, mi mollis mollis convallis, felis velit fermentum libero, ut blandit elit mi vel risus. Sed augue metus, scelerisque nec pretium ac, bibendum facilisis massa.

## Tabla de Contenido

- [Pre-Requisitos](#prerequisites)
- [Instalación](#installation)
- [Inicio Rápido](#quickstart)
- [Contribución](#contributing)
- [Lecturas Adicionales / Enlaces de Interés](#further-reading--useful-links)

## Pre-Requisitos

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis, lacus a pretium euismod, turpis dolor viverra velit, sit amet laoreet justo ante at sem. Pellentesque sollicitudin, mi mollis mollis convallis, felis velit fermentum libero, ut blandit elit mi vel risus. Sed augue metus, scelerisque nec pretium ac, bibendum facilisis massa:

* [Lorem ipsum dolor sit amet](http://lorem-ipsum-dolor-sit-amet)
* [Lorem ipsum dolor sit amet](http://lorem-ipsum-dolor-sit-amet)
* [Lorem ipsum dolor sit amet](http://lorem-ipsum-dolor-sit-amet)

## Instalación

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis, lacus a pretium euismod, turpis dolor viverra velit, sit amet laoreet justo ante at sem. Pellentesque sollicitudin, mi mollis mollis convallis, felis velit fermentum libero, ut blandit elit mi vel risus. Sed augue metus, scelerisque nec pretium ac, bibendum facilisis massa.

## Inicio Rápido

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis, lacus a pretium euismod, turpis dolor viverra velit, sit amet laoreet justo ante at sem. Pellentesque sollicitudin, mi mollis mollis convallis, felis velit fermentum libero, ut blandit elit mi vel risus. Sed augue metus, scelerisque nec pretium ac, bibendum facilisis massa.

## Contribución

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis, lacus a pretium euismod, turpis dolor viverra velit, sit amet laoreet justo ante at sem. Pellentesque sollicitudin, mi mollis mollis convallis, felis velit fermentum libero, ut blandit elit mi vel risus. Sed augue metus, scelerisque nec pretium ac, bibendum facilisis massa:

1. Lorem ipsum dolor sit amet, consectetur adipiscing elit
2. Lorem ipsum dolor sit amet, consectetur adipiscing elit

## Lecturas Adicionales / Enlaces de Interés

* Lorem ipsum dolor sit amet, consectetur adipiscing elit.
* Lorem ipsum dolor sit amet, consectetur adipiscing elit.
